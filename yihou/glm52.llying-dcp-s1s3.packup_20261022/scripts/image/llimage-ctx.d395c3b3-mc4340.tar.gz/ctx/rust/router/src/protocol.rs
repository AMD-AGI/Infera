///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2026, Advanced Micro Devices, Inc. All rights reserved.
//
// SPDX-License-Identifier: MIT
///////////////////////////////////////////////////////////////////////////////
//! PD coordination protocol. Covers SGLang bootstrap and vLLM Mooncake, whose
//! legs are POSTed concurrently, and ATOM Mooncake, whose decode body needs the
//! prefill's response (serial pull). Other connectors (vLLM MoRIIO) are served
//! by the Python backend.

use serde_json::{Map, Value};

use crate::pool::Worker;

const SGLANG_BOOTSTRAP: &str = "sglang-bootstrap";
const VLLM_MOONCAKE: &str = "vllm-mooncake";
const ATOM_MOONCAKE: &str = "atom-mooncake";

/// The PD coordination protocol both legs speak. Selects how `disagg::dispatch`
/// shapes the prefill vs decode bodies.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PdProtocol {
    /// SGLang bootstrap: both legs get the same top-level bootstrap fields.
    SglangBootstrap,
    /// vLLM Mooncake: asymmetric `kv_transfer_params` — prefill pushes KV, decode
    /// pulls it via the prefill's bootstrap server.
    VllmMooncake,
    /// ATOM Mooncake: serial pull. The prefill runs first, and its response's
    /// `kv_transfer_params` become the decode's.
    AtomMooncake,
}

/// Resolve the PD protocol from the workers' advertised `disagg_meta.protocol`.
/// Both legs must speak the same supported protocol; errors on an unsupported
/// connector (mori — use the Python backend) or a P/D mismatch.
pub fn resolve_pd_protocol(p: &Worker, d: &Worker) -> anyhow::Result<PdProtocol> {
    let pp = p.disagg_meta.get("protocol").and_then(|v| v.as_str());
    let dp = d.disagg_meta.get("protocol").and_then(|v| v.as_str());
    match (pp, dp) {
        (Some(SGLANG_BOOTSTRAP), Some(SGLANG_BOOTSTRAP)) => Ok(PdProtocol::SglangBootstrap),
        (Some(VLLM_MOONCAKE), Some(VLLM_MOONCAKE)) => Ok(PdProtocol::VllmMooncake),
        (Some(ATOM_MOONCAKE), Some(ATOM_MOONCAKE)) => Ok(PdProtocol::AtomMooncake),
        _ => anyhow::bail!(
            "unsupported or mismatched PD protocol (prefill={pp:?}, decode={dp:?}); \
             rust backend supports sglang-bootstrap, vllm-mooncake and atom-mooncake — \
             use --router-backend python for others (mori)"
        ),
    }
}

/// Both workers must advertise the sglang-bootstrap protocol. Kept for callers
/// that only handle the SGLang path; new code should use `resolve_pd_protocol`.
pub fn require_sglang_bootstrap(p: &Worker, d: &Worker) -> anyhow::Result<()> {
    match resolve_pd_protocol(p, d)? {
        PdProtocol::SglangBootstrap => Ok(()),
        other => anyhow::bail!("expected sglang-bootstrap, got {other:?}"),
    }
}

/// Inject SGLang's bootstrap fields (from the prefill worker's advertised
/// address) into a leg body. Decode and prefill legs get identical fields.
pub fn annotate_sglang(
    body: &mut Map<String, Value>,
    prefill: &Worker,
    path: &str,
    room: u64,
) -> anyhow::Result<()> {
    let addr = prefill
        .disagg_meta
        .get("params")
        .and_then(|v| v.get("bootstrap_addr"))
        .and_then(|v| v.as_str())
        .ok_or_else(|| {
            anyhow::anyhow!(
                "prefill {} missing disagg_meta.params.bootstrap_addr",
                prefill.worker_id
            )
        })?;
    let (host, port) = addr
        .rsplit_once(':')
        .ok_or_else(|| anyhow::anyhow!("bad bootstrap_addr {addr:?} (want host:port)"))?;
    let port: i64 = port
        .parse()
        .map_err(|_| anyhow::anyhow!("bad bootstrap port in {addr:?}"))?;
    body.insert("bootstrap_host".into(), Value::from(host));
    body.insert("bootstrap_port".into(), Value::from(port));
    body.insert("bootstrap_room".into(), Value::from(room));
    // SGLang /abort_request matches this rid; both legs share it.
    let rid = sglang_rid(room);
    body.insert("rid".into(), Value::from(rid.clone()));
    if path == "/v1/responses" {
        body.insert("request_id".into(), Value::from(rid));
    }
    Ok(())
}

/// Request id posted to SGLang ``/abort_request`` for this bootstrap room.
pub fn sglang_rid(room: u64) -> String {
    format!("infera-{room}")
}

// --- vLLM Mooncake ---------------------------------------------------------
// Mirrors `infera/router/disagg_protocols/vllm_mooncake.py`: a concurrent push
// where the prefill worker runs prefill (+1 token) and pushes KV over Mooncake,
// and the decode worker discovers the prefill via its bootstrap server and
// generates the rest. The two legs get ASYMMETRIC bodies (unlike SGLang).

/// Deterministic transfer_id from the room so the concurrently-dispatched
/// prefill/decode legs agree without threading state (mirrors the reference
/// proxy's `xfer-<id>`).
fn transfer_id_for_room(room: u64) -> String {
    format!("xfer-{room:032x}")
}

fn required_param<'a>(w: &'a Worker, key: &str) -> anyhow::Result<&'a str> {
    w.disagg_meta
        .get("params")
        .and_then(|v| v.get(key))
        .and_then(|v| v.as_str())
        .ok_or_else(|| anyhow::anyhow!("worker {} missing disagg_meta.params.{key}", w.worker_id))
}

/// The fields that cap generated tokens, for one endpoint, primary first.
///
/// A Responses body defines none of the chat fields -- its cap is
/// `max_output_tokens` -- and getting this wrong fails silently in the worst
/// direction. vLLM ignores the unknown key rather than rejecting it, so the
/// prefill leg that was supposed to stop after one token runs the whole
/// generation, at full prefill cost, and the decode leg then generates it a
/// second time from the transferred KV.
fn output_cap_fields(path: &str) -> &'static [&'static str] {
    if path == "/v1/responses" {
        &["max_output_tokens"]
    } else {
        &["max_tokens", "max_completion_tokens"]
    }
}

/// Cap a prefill leg at one token, non-streaming: just enough to fill the KV.
fn prefill_one_token(body: &mut Map<String, Value>, path: &str) {
    // The primary cap is set whether or not the client sent it -- an uncapped
    // prefill leg generates the whole completion twice -- while the aliases are
    // only rewritten where they already appear, so the engine is never taught
    // about a field this request did not use.
    let caps = output_cap_fields(path);
    body.insert(caps[0].into(), Value::from(1));
    body.insert("stream".into(), Value::from(false));
    // Not remove(): preserve_order redefines it as a swap, which would reorder
    // the forwarded body. shift_remove is gated on that feature, so dropping it
    // breaks the build rather than silently changing what we send.
    body.shift_remove("stream_options");
    for k in &caps[1..] {
        if body.contains_key(*k) {
            body.insert((*k).into(), Value::from(1));
        }
    }
}

/// Prefill leg: prefill only (one token, non-streaming) plus the
/// `kv_transfer_params` that tell vLLM to push its KV to a remote decode.
pub fn annotate_vllm_prefill(body: &mut Map<String, Value>, path: &str, room: u64) {
    prefill_one_token(body, path);
    let mut kv = Map::new();
    kv.insert("do_remote_decode".into(), Value::Bool(true));
    kv.insert("do_remote_prefill".into(), Value::Bool(false));
    kv.insert(
        "transfer_id".into(),
        Value::from(transfer_id_for_room(room)),
    );
    body.insert("kv_transfer_params".into(), Value::Object(kv));
}

/// Decode leg: generate the remaining tokens, pulling the prefilled KV from the
/// prefill's Mooncake bootstrap. For a DP>1 prefill, address the steered rank's
/// engine (`engine_id_dp{room % dp_size}`, recovered the same way vLLM does).
pub fn annotate_vllm_decode(
    body: &mut Map<String, Value>,
    prefill: &Worker,
    path: &str,
    room: u64,
) -> anyhow::Result<()> {
    // Prefill already produced 1 token; decode does the rest (floor 1).
    for k in output_cap_fields(path) {
        if let Some(n) = body.get(*k).and_then(Value::as_i64) {
            body.insert((*k).into(), Value::from((n - 1).max(1)));
        }
    }
    let mut engine_id = required_param(prefill, "engine_id")?.to_string();
    let dp_size = prefill.dp_size.unwrap_or(1);
    if dp_size > 1 {
        engine_id = format!("{engine_id}_dp{}", room % dp_size as u64);
    }
    let bootstrap_addr = required_param(prefill, "bootstrap_addr")?.to_string();
    let mut kv = Map::new();
    kv.insert("do_remote_decode".into(), Value::Bool(false));
    kv.insert("do_remote_prefill".into(), Value::Bool(true));
    kv.insert("remote_bootstrap_addr".into(), Value::from(bootstrap_addr));
    kv.insert("remote_engine_id".into(), Value::from(engine_id));
    kv.insert(
        "transfer_id".into(),
        Value::from(transfer_id_for_room(room)),
    );
    body.insert("kv_transfer_params".into(), Value::Object(kv));
    Ok(())
}

// --- ATOM Mooncake ---------------------------------------------------------
// Mirrors `infera/router/disagg_protocols/atom_mooncake.py`, which replays the
// body shaping of ATOM's own PD proxy. The prefill runs for one token and pushes
// its KV to the decode named in its body; its response's `kv_transfer_params`
// (transfer_id, first_token_id, block ids, the DP rank that holds the KV, ...)
// are passed to the decode verbatim, plus the producer's parallelism.

/// A required `disagg_meta.params` value of an ATOM worker.
fn atom_param<'a>(w: &'a Worker, key: &str) -> anyhow::Result<&'a Value> {
    w.disagg_meta
        .get("params")
        .and_then(|v| v.get(key))
        .filter(|v| !v.is_null())
        .ok_or_else(|| anyhow::anyhow!("worker {} missing disagg_meta.params.{key}", w.worker_id))
}

/// Prefill leg: one token, non-streaming, told which decode to push its KV to.
pub fn annotate_atom_prefill(
    body: &mut Map<String, Value>,
    decode: &Worker,
    path: &str,
) -> anyhow::Result<()> {
    let mut kv = Map::new();
    kv.insert(
        "remote_dp_size".into(),
        atom_param(decode, "dp_size")?.clone(),
    );
    kv.insert(
        "remote_tp_size".into(),
        atom_param(decode, "tp_size")?.clone(),
    );
    kv.insert("do_remote_decode".into(), Value::Bool(true));
    kv.insert("do_remote_prefill".into(), Value::Bool(false));
    kv.insert(
        "remote_handshake_port".into(),
        atom_param(decode, "handshake_port")?.clone(),
    );
    kv.insert("remote_engine_id".into(), Value::Null);
    kv.insert("remote_block_ids".into(), Value::Null);
    kv.insert("remote_host".into(), atom_param(decode, "host")?.clone());
    kv.insert(
        "remote_port".into(),
        atom_param(decode, "http_port")?.clone(),
    );
    prefill_one_token(body, path);
    body.insert("kv_transfer_params".into(), Value::Object(kv));
    Ok(())
}

/// The hand-off the decode needs: the prefill response's `kv_transfer_params`.
pub fn atom_handoff(prefill_reply: &Value) -> anyhow::Result<Map<String, Value>> {
    let kv = prefill_reply
        .get("kv_transfer_params")
        .and_then(Value::as_object)
        .ok_or_else(|| anyhow::anyhow!("atom prefill response has no kv_transfer_params"))?;
    if !kv.contains_key("transfer_id") {
        anyhow::bail!("atom prefill kv_transfer_params has no transfer_id");
    }
    Ok(kv.clone())
}

/// Decode leg: the prefill's hand-off plus the producer's parallelism, which the
/// consumer needs to dial the right rank's handshake port
/// (`remote_handshake_port + remote_dp_rank * tp_size + tp_rank`). `max_tokens`
/// stays as sent: ATOM's decode re-predicts the first token and counts it.
pub fn annotate_atom_decode(
    body: &mut Map<String, Value>,
    prefill: &Worker,
    mut handoff: Map<String, Value>,
) -> anyhow::Result<()> {
    let tp_size = atom_param(prefill, "tp_size")?.clone();
    handoff.insert(
        "remote_dp_size".into(),
        atom_param(prefill, "dp_size")?.clone(),
    );
    handoff.insert("remote_tp_size".into(), tp_size.clone());
    handoff.entry("tp_size").or_insert(tp_size);
    // The rank the prefill stored the KV on; a bool is not a rank.
    if let Some(rank) = handoff.get("dp_rank").and_then(Value::as_i64) {
        handoff.insert("remote_dp_rank".into(), Value::from(rank));
    }
    body.insert("kv_transfer_params".into(), Value::Object(handoff));
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn worker(meta: Value) -> Worker {
        serde_json::from_value(json!({
            "worker_id": "w", "url": "http://x", "disagg_meta": meta
        }))
        .unwrap()
    }

    fn sglang() -> Value {
        json!({"protocol": "sglang-bootstrap", "params": {"bootstrap_addr": "10.0.0.1:9000"}})
    }

    fn vllm(dp_size: i64) -> Worker {
        serde_json::from_value(json!({
            "worker_id": "p", "url": "http://x", "dp_size": dp_size,
            "disagg_meta": {
                "protocol": "vllm-mooncake",
                "params": {"engine_id": "eng-42", "bootstrap_addr": "http://10.0.0.1:8998"}
            }
        }))
        .unwrap()
    }

    #[test]
    fn resolve_protocol_dispatches_by_tag() {
        let sp = worker(sglang());
        let sd = worker(json!({"protocol": "sglang-bootstrap"}));
        assert_eq!(
            resolve_pd_protocol(&sp, &sd).unwrap(),
            PdProtocol::SglangBootstrap
        );

        let vp = vllm(1);
        let vd = worker(json!({"protocol": "vllm-mooncake"}));
        assert_eq!(
            resolve_pd_protocol(&vp, &vd).unwrap(),
            PdProtocol::VllmMooncake
        );

        // mismatched P/D protocols and unsupported connectors error out.
        assert!(resolve_pd_protocol(&sp, &vd).is_err());
        assert!(resolve_pd_protocol(&worker(json!({"protocol": "mori"})), &vd).is_err());
    }

    #[test]
    fn vllm_prefill_leg_is_prefill_only_and_pushes_kv() {
        let mut body = Map::new();
        body.insert("max_tokens".into(), Value::from(128));
        body.insert("max_completion_tokens".into(), Value::from(128));
        body.insert("stream_options".into(), json!({"include_usage": true}));
        annotate_vllm_prefill(&mut body, "/v1/chat/completions", 42);
        assert_eq!(body["max_tokens"], 1);
        assert_eq!(body["max_completion_tokens"], 1);
        assert_eq!(body["stream"], false);
        assert!(!body.contains_key("stream_options"));
        let kv = &body["kv_transfer_params"];
        assert_eq!(kv["do_remote_decode"], true);
        assert_eq!(kv["do_remote_prefill"], false);
        assert_eq!(kv["transfer_id"], format!("xfer-{:032x}", 42));
    }

    /// A Responses body caps with `max_output_tokens` and nothing else.
    ///
    /// `/v1/responses` reaches the vLLM PD path like any other route, but it
    /// defines neither `max_tokens` nor `max_completion_tokens`. Writing
    /// `max_tokens: 1` into it is not an error vLLM reports -- the key is
    /// simply ignored -- so the prefill leg ran the whole generation and the
    /// decode leg then ran it again from the transferred KV.
    #[test]
    fn a_responses_prefill_leg_is_capped_by_the_field_that_body_defines() {
        let mut body = Map::new();
        body.insert("max_output_tokens".into(), Value::from(128));
        annotate_vllm_prefill(&mut body, "/v1/responses", 42);
        assert_eq!(body["max_output_tokens"], 1);
        assert!(
            !body.contains_key("max_tokens"),
            "a field this body does not define must not be invented: {body:?}"
        );

        // Capped even when the client set no ceiling of its own.
        let mut open = Map::new();
        annotate_vllm_prefill(&mut open, "/v1/responses", 42);
        assert_eq!(open["max_output_tokens"], 1);

        let mut d = Map::new();
        d.insert("max_output_tokens".into(), Value::from(128));
        annotate_vllm_decode(&mut d, &vllm(1), "/v1/responses", 42).unwrap();
        assert_eq!(d["max_output_tokens"], 127, "prefill did 1");
    }

    #[test]
    fn vllm_decode_leg_pulls_kv_and_decrements_tokens() {
        let p = vllm(1);
        let mut body = Map::new();
        body.insert("max_tokens".into(), Value::from(128));
        annotate_vllm_decode(&mut body, &p, "/v1/chat/completions", 42).unwrap();
        assert_eq!(body["max_tokens"], 127); // prefill did 1
        let kv = &body["kv_transfer_params"];
        assert_eq!(kv["do_remote_prefill"], true);
        assert_eq!(kv["do_remote_decode"], false);
        assert_eq!(kv["remote_bootstrap_addr"], "http://10.0.0.1:8998");
        assert_eq!(kv["remote_engine_id"], "eng-42"); // dp_size=1 -> base engine_id
        assert_eq!(kv["transfer_id"], format!("xfer-{:032x}", 42));
    }

    #[test]
    fn vllm_decode_addresses_steered_dp_rank() {
        let p = vllm(4);
        let mut body = Map::new();
        // room % dp_size selects the prefill rank (3) -> engine_id_dp3
        annotate_vllm_decode(&mut body, &p, "/v1/chat/completions", 7).unwrap();
        assert_eq!(body["kv_transfer_params"]["remote_engine_id"], "eng-42_dp3");
        // floor: with no/max_tokens=1 decode stays >= 1
        let mut b2 = Map::new();
        b2.insert("max_tokens".into(), Value::from(1));
        annotate_vllm_decode(&mut b2, &p, "/v1/chat/completions", 7).unwrap();
        assert_eq!(b2["max_tokens"], 1);
    }

    #[test]
    fn vllm_decode_errors_on_missing_params() {
        let bad: Worker =
            serde_json::from_value(json!({"worker_id": "p", "url": "http://x", "dp_size": 1,
                "disagg_meta": {"protocol": "vllm-mooncake", "params": {}}}))
            .unwrap();
        let mut body = Map::new();
        assert!(annotate_vllm_decode(&mut body, &bad, "/v1/chat/completions", 1).is_err());
    }

    #[test]
    fn require_bootstrap_matches_both_legs() {
        let p = worker(sglang());
        let d = worker(json!({"protocol": "sglang-bootstrap"}));
        assert!(require_sglang_bootstrap(&p, &d).is_ok());

        let other = worker(json!({"protocol": "mooncake"}));
        assert!(require_sglang_bootstrap(&other, &d).is_err());
        assert!(require_sglang_bootstrap(&p, &worker(json!({}))).is_err());
    }

    #[test]
    fn annotate_injects_bootstrap_fields() {
        let p = worker(sglang());
        let mut body = Map::new();
        annotate_sglang(&mut body, &p, "/v1/chat/completions", 42).unwrap();
        assert_eq!(body["bootstrap_host"], "10.0.0.1");
        assert_eq!(body["bootstrap_port"], 9000);
        assert_eq!(body["bootstrap_room"], 42);
        assert_eq!(body["rid"], "infera-42");
        assert!(!body.contains_key("request_id"));

        let mut responses = Map::new();
        annotate_sglang(&mut responses, &p, "/v1/responses", 42).unwrap();
        assert_eq!(responses["rid"], "infera-42");
        assert_eq!(responses["request_id"], responses["rid"]);
    }

    #[test]
    fn annotate_rejects_bad_addr() {
        // missing addr entirely
        let mut b = Map::new();
        assert!(annotate_sglang(
            &mut b,
            &worker(json!({"protocol": "sglang-bootstrap"})),
            "/v1/chat/completions",
            1
        )
        .is_err());
        // no host:port separator
        let mut b = Map::new();
        let w =
            worker(json!({"protocol": "sglang-bootstrap", "params": {"bootstrap_addr": "noport"}}));
        assert!(annotate_sglang(&mut b, &w, "/v1/chat/completions", 1).is_err());
        // non-numeric port
        let mut b = Map::new();
        let w =
            worker(json!({"protocol": "sglang-bootstrap", "params": {"bootstrap_addr": "h:abc"}}));
        assert!(annotate_sglang(&mut b, &w, "/v1/chat/completions", 1).is_err());
    }

    fn atom(role: &str, handshake_port: i64) -> Worker {
        serde_json::from_value(json!({
            "worker_id": role, "url": "http://x", "engine": "atom",
            "disagg_meta": {"protocol": "atom-mooncake", "params": {
                "host": "10.0.0.1", "http_port": 19002, "handshake_port": handshake_port,
                "tp_size": 4, "dp_size": 1
            }}
        }))
        .unwrap()
    }

    #[test]
    fn atom_pair_resolves_to_atom_mooncake() {
        let (p, d) = (atom("p", 21301), atom("d", 21311));
        assert_eq!(
            resolve_pd_protocol(&p, &d).unwrap(),
            PdProtocol::AtomMooncake
        );
        assert!(resolve_pd_protocol(&p, &worker(sglang())).is_err());
    }

    #[test]
    fn atom_prefill_leg_runs_one_token_and_names_the_decode() {
        let mut body = Map::new();
        body.insert("max_tokens".into(), Value::from(128));
        body.insert("stream".into(), Value::Bool(true));
        body.insert("stream_options".into(), json!({"include_usage": true}));
        annotate_atom_prefill(&mut body, &atom("d", 21311), "/v1/completions").unwrap();
        assert_eq!(body["max_tokens"], 1);
        assert_eq!(body["stream"], false);
        assert!(!body.contains_key("stream_options"));
        // What ATOM's own proxy sends, field for field.
        assert_eq!(
            body["kv_transfer_params"],
            json!({
                "remote_dp_size": 1, "remote_tp_size": 4,
                "do_remote_decode": true, "do_remote_prefill": false,
                "remote_handshake_port": 21311,
                "remote_engine_id": null, "remote_block_ids": null,
                "remote_host": "10.0.0.1", "remote_port": 19002
            })
        );
    }

    #[test]
    fn atom_prefill_needs_the_decode_addressing() {
        let bare = worker(json!({"protocol": "atom-mooncake"}));
        assert!(annotate_atom_prefill(&mut Map::new(), &bare, "/v1/completions").is_err());
    }

    #[test]
    fn atom_decode_reuses_the_handoff_and_dials_its_rank() {
        let reply = json!({"choices": [], "kv_transfer_params": {
            "do_remote_prefill": true, "do_remote_decode": false, "transfer_id": "t-1",
            "first_token_id": 7, "remote_block_ids": [1, 2], "dp_rank": 3
        }});
        let handoff = atom_handoff(&reply).unwrap();
        let mut body = Map::new();
        body.insert("max_tokens".into(), Value::from(128));
        annotate_atom_decode(&mut body, &atom("p", 21301), handoff).unwrap();
        // Not decremented: ATOM's decode counts the re-predicted first token.
        assert_eq!(body["max_tokens"], 128);
        let kv = &body["kv_transfer_params"];
        assert_eq!(kv["transfer_id"], "t-1");
        assert_eq!(kv["first_token_id"], 7);
        assert_eq!(kv["remote_block_ids"], json!([1, 2]));
        assert_eq!(kv["remote_dp_size"], 1);
        assert_eq!(kv["remote_tp_size"], 4);
        assert_eq!(kv["tp_size"], 4);
        assert_eq!(kv["remote_dp_rank"], 3);
    }

    #[test]
    fn atom_handoff_needs_a_transfer_id() {
        assert!(atom_handoff(&json!({"choices": []})).is_err());
        assert!(atom_handoff(&json!({"kv_transfer_params": {"dp_rank": 0}})).is_err());
        let mut body = Map::new();
        let handoff = atom_handoff(&json!({"kv_transfer_params": {"transfer_id": "t"}})).unwrap();
        annotate_atom_decode(&mut body, &atom("p", 21301), handoff).unwrap();
        assert!(!body["kv_transfer_params"]
            .as_object()
            .unwrap()
            .contains_key("remote_dp_rank"));
    }
}
