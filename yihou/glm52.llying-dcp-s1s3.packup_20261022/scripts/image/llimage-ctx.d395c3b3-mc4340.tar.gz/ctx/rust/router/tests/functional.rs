///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2026, Advanced Micro Devices, Inc. All rights reserved.
//
// SPDX-License-Identifier: MIT
///////////////////////////////////////////////////////////////////////////////
//! Router functional tests: drive real HTTP requests through the assembled
//! axum app against mock upstream workers, so one case exercises the whole
//! path (handlers → proxy/disagg → policy → pool → protocol/dp) at once.

use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use arc_swap::ArcSwap;
use axum::body::{Body, Bytes};
use axum::extract::{DefaultBodyLimit, State};
use axum::http::header::CONTENT_TYPE;
use axum::http::{HeaderMap, StatusCode, Uri};
use axum::response::{IntoResponse, Response};
use axum::routing::post;
use axum::{Json, Router};
use serde_json::{json, Value};

use futures::StreamExt;
use infera_router::block_hasher::BlockHasher;
use infera_router::breaker::CircuitBreaker;
use infera_router::handlers::{app, AppState};
use infera_router::kv_event::KvEventClient;
use infera_router::policy::{KvEventAwarePolicy, RoundRobin};
use infera_router::pool::{Snapshot, Worker};
use infera_router::proxy;

// ---------------------------------------------------------------------------
// Mock upstream worker
// ---------------------------------------------------------------------------

struct Hit {
    body: Value,
    dp_rank: Option<String>,
    path: String,
}

struct MockState {
    status: u16,
    sse: bool,
    reply: Value,
    hits: Mutex<Vec<Hit>>,
    abort_rids: Mutex<Vec<String>>,
    hang: bool,
    hang_stream: bool,
    /// End the SSE body after one event, with no `data: [DONE]`.
    truncated_sse: bool,
    /// Pause after accepting the request, before the status is returned.
    delay: Duration,
}

impl MockState {
    fn hit_count(&self) -> usize {
        self.hits.lock().unwrap().len()
    }
}

async fn mock_handle(
    State(s): State<Arc<MockState>>,
    uri: Uri,
    headers: HeaderMap,
    raw: Bytes,
) -> Response {
    let body: Value = serde_json::from_slice(&raw).unwrap_or(Value::Null);
    let dp_rank = headers
        .get(infera_router::dp::DP_RANK_HEADER)
        .and_then(|h| h.to_str().ok())
        .map(str::to_string);
    let path = uri.path().to_string();
    let is_responses = path == "/v1/responses";
    if path == "/abort_request" {
        let rid = body
            .get("rid")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        s.abort_rids.lock().unwrap().push(rid);
        return StatusCode::OK.into_response();
    }
    s.hits.lock().unwrap().push(Hit {
        body,
        dp_rank,
        path,
    });

    if s.hang {
        std::future::pending::<()>().await;
    }
    if !s.delay.is_zero() {
        tokio::time::sleep(s.delay).await;
    }

    if s.status != 200 {
        return (StatusCode::from_u16(s.status).unwrap(), "upstream error").into_response();
    }
    if s.sse {
        let first =
            Bytes::from_static(b"data: {\"choices\":[{\"delta\":{\"content\":\"hi\"}}]}\n\n");
        if s.hang_stream {
            let s = futures::stream::once(async move { Ok::<_, std::io::Error>(first) })
                .chain(futures::stream::pending());
            return Response::builder()
                .status(StatusCode::OK)
                .header(CONTENT_TYPE, "text/event-stream")
                .body(Body::from_stream(s))
                .unwrap();
        }
        if s.truncated_sse {
            return Response::builder()
                .status(StatusCode::OK)
                .header(CONTENT_TYPE, "text/event-stream")
                .body(Body::from(first))
                .unwrap();
        }
        let terminal = if is_responses {
            b"event: response.completed\ndata: {\"type\":\"response.completed\"}\n\n".as_ref()
        } else {
            b"data: [DONE]\n\n".as_ref()
        };
        let sse = [first.as_ref(), terminal].concat();
        return Response::builder()
            .status(StatusCode::OK)
            .header(CONTENT_TYPE, "text/event-stream")
            .body(Body::from(sse))
            .unwrap();
    }
    (StatusCode::OK, Json(s.reply.clone())).into_response()
}

/// Spawn a mock worker on a random port. Returns (base_url, shared state).
async fn spawn_mock(status: u16, sse: bool, reply: Value) -> (String, Arc<MockState>) {
    let state = Arc::new(MockState {
        status,
        sse,
        reply,
        hits: Mutex::new(Vec::new()),
        abort_rids: Mutex::new(Vec::new()),
        hang: false,
        hang_stream: false,
        truncated_sse: false,
        delay: Duration::ZERO,
    });
    let router = Router::new()
        .route("/v1/chat/completions", post(mock_handle))
        .route("/v1/completions", post(mock_handle))
        .route("/v1/responses", post(mock_handle))
        .route("/abort_request", post(mock_handle))
        // Stand in for a real engine, which caps a prompt by context length
        // rather than by request bytes.
        .layer(DefaultBodyLimit::disable())
        .with_state(state.clone());
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    tokio::spawn(async move {
        axum::serve(listener, router).await.unwrap();
    });
    (format!("http://127.0.0.1:{port}"), state)
}

async fn spawn_mock_cfg(
    status: u16,
    sse: bool,
    reply: Value,
    hang: bool,
    hang_stream: bool,
) -> (String, Arc<MockState>) {
    let state = Arc::new(MockState {
        status,
        sse,
        reply,
        hits: Mutex::new(Vec::new()),
        abort_rids: Mutex::new(Vec::new()),
        hang,
        hang_stream,
        truncated_sse: false,
        delay: Duration::ZERO,
    });
    serve_mock(state).await
}

/// A worker whose SSE body ends cleanly one event in, the way an engine that
/// dies mid-generation looks to the router.
async fn spawn_mock_truncated_sse() -> (String, Arc<MockState>) {
    let state = Arc::new(MockState {
        status: 200,
        sse: true,
        reply: json!(null),
        hits: Mutex::new(Vec::new()),
        abort_rids: Mutex::new(Vec::new()),
        hang: false,
        hang_stream: false,
        truncated_sse: true,
        delay: Duration::ZERO,
    });
    serve_mock(state).await
}

async fn serve_mock(state: Arc<MockState>) -> (String, Arc<MockState>) {
    let router = Router::new()
        .route("/v1/chat/completions", post(mock_handle))
        .route("/v1/completions", post(mock_handle))
        .route("/v1/responses", post(mock_handle))
        .route("/abort_request", post(mock_handle))
        .layer(DefaultBodyLimit::disable())
        .with_state(state.clone());
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    tokio::spawn(async move {
        axum::serve(listener, router).await.unwrap();
    });
    (format!("http://127.0.0.1:{port}"), state)
}

// ---------------------------------------------------------------------------
// Router under test
// ---------------------------------------------------------------------------

fn worker(spec: Value) -> Arc<Worker> {
    Arc::new(serde_json::from_value(spec).expect("worker json"))
}

fn make_state(workers: Vec<Arc<Worker>>, retries: usize) -> AppState {
    AppState {
        sessions: Arc::new(infera_router::session_affinity::Sessions::default()),
        pool: Arc::new(ArcSwap::from_pointee(Snapshot::build(workers))),
        policy: Arc::new(RoundRobin::new()),
        http: proxy::build_upstream_client(0.0).unwrap(),
        started: Instant::now(),
        retries,
        breaker: Arc::new(CircuitBreaker::default()),
        nats: None,
        pd_prefill_guard_release: infera_router::config::PrefillGuardRelease::Decode,
        pd_prefill_drain_timeout: Duration::from_secs(300),
        stream_stall_warn: infera_router::proxy::StallWarn {
            before_first_byte: Duration::from_secs(240),
            mid_stream: Duration::from_secs(60),
        },
    }
}

async fn spawn_router(state: AppState) -> String {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    tokio::spawn(async move {
        axum::serve(listener, app(state)).await.unwrap();
    });
    format!("http://127.0.0.1:{port}")
}

fn client() -> reqwest::Client {
    reqwest::Client::new()
}

// ---------------------------------------------------------------------------
// Mixed (non-PD) dispatch
// ---------------------------------------------------------------------------

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn mixed_unary_ok() {
    let (url, mock) = spawn_mock(200, false, json!({"answer": 42})).await;
    let state = make_state(
        vec![worker(json!({
            "worker_id": "w1", "url": url, "model_name": "m", "disagg_mode": "mixed"
        }))],
        0,
    );
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": false}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(resp.json::<Value>().await.unwrap()["answer"], 42);
    assert_eq!(mock.hit_count(), 1);
}

/// The Codex CLI/SDK speaks the OpenAI Responses API, not chat completions, so
/// an unregistered `/v1/responses` is a 404 raised by the route table before
/// any policy runs — a whole client family locked out with no worker-side trace.
/// The dispatch chain is path-generic, so registering the route is all it takes.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn mixed_responses_forwards_verbatim() {
    let (url, mock) = spawn_mock(200, false, json!({"object": "response"})).await;
    let state = make_state(
        vec![worker(json!({
            "worker_id": "w1", "url": url, "model_name": "m", "disagg_mode": "mixed"
        }))],
        0,
    );
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/responses"))
        .json(&json!({"model": "m", "input": "1+1=?", "store": false}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(resp.json::<Value>().await.unwrap()["object"], "response");

    let hit = &mock.hits.lock().unwrap()[0];
    // Forwarded to the same path, not rewritten onto the chat endpoint.
    assert_eq!(hit.path, "/v1/responses");
    // A Responses body carries `input`, never `messages`; nothing may rewrite it.
    assert_eq!(hit.body["input"], "1+1=?");
    assert!(hit.body.get("messages").is_none());
}

/// A long-context prompt is a normal request, not an oversized one: axum's
/// default 2 MiB body cap used to 413 it before it reached a worker.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn mixed_forwards_body_over_axum_default_limit() {
    let (url, mock) = spawn_mock(200, false, json!({"answer": 42})).await;
    let state = make_state(
        vec![worker(json!({
            "worker_id": "w1", "url": url, "model_name": "m", "disagg_mode": "mixed"
        }))],
        0,
    );
    let router = spawn_router(state).await;
    let prompt = "x".repeat((2 << 20) + 4096);

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "prompt": prompt}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    let hits = mock.hits.lock().unwrap();
    assert_eq!(hits[0].body["prompt"].as_str().unwrap().len(), prompt.len());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn mixed_round_robin_spreads_load() {
    let (url_a, a) = spawn_mock(200, false, json!({"w": "a"})).await;
    let (url_b, b) = spawn_mock(200, false, json!({"w": "b"})).await;
    let state = make_state(
        vec![
            worker(
                json!({"worker_id": "a", "url": url_a, "model_name": "m", "disagg_mode": "mixed"}),
            ),
            worker(
                json!({"worker_id": "b", "url": url_b, "model_name": "m", "disagg_mode": "mixed"}),
            ),
        ],
        0,
    );
    let router = spawn_router(state).await;

    for _ in 0..4 {
        let r = client()
            .post(format!("{router}/v1/chat/completions"))
            .json(&json!({"model": "m"}))
            .send()
            .await
            .unwrap();
        assert_eq!(r.status(), 200);
    }
    // 4 requests, round-robin over 2 workers → 2 each.
    assert_eq!(a.hit_count(), 2);
    assert_eq!(b.hit_count(), 2);
}

// ---------------------------------------------------------------------------
// Multimodal image-affinity routing (engine-agnostic: same OpenAI vision body
// that both sglang and vLLM receive flows the full path handlers → parse →
// extract_image_keys → KvEventAwarePolicy affinity → upstream).
// ---------------------------------------------------------------------------

fn make_kv_state(workers: Vec<Arc<Worker>>, retries: usize) -> AppState {
    AppState {
        sessions: Arc::new(infera_router::session_affinity::Sessions::default()),
        pool: Arc::new(ArcSwap::from_pointee(Snapshot::build(workers))),
        policy: Arc::new(KvEventAwarePolicy::new(
            Arc::new(KvEventClient::new()),
            BlockHasher::disabled(),
            20.0,
            None,
            None,
        )),
        http: proxy::build_upstream_client(0.0).unwrap(),
        started: Instant::now(),
        retries,
        breaker: Arc::new(CircuitBreaker::default()),
        nats: None,
        pd_prefill_guard_release: infera_router::config::PrefillGuardRelease::Decode,
        pd_prefill_drain_timeout: Duration::from_secs(300),
        stream_stall_warn: infera_router::proxy::StallWarn {
            before_first_byte: Duration::from_secs(240),
            mid_stream: Duration::from_secs(60),
        },
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn mm_affinity_colocates_repeat_image() {
    let (url_a, a) = spawn_mock(200, false, json!({"w": "a"})).await;
    let (url_b, b) = spawn_mock(200, false, json!({"w": "b"})).await;
    let state = make_kv_state(
        vec![
            worker(json!({"worker_id": "a", "url": url_a, "model_name": "m",
                          "disagg_mode": "mixed", "kv_block_size": 16})),
            worker(json!({"worker_id": "b", "url": url_b, "model_name": "m",
                          "disagg_mode": "mixed", "kv_block_size": 16})),
        ],
        0,
    );
    let router = spawn_router(state).await;

    // Standard OpenAI vision request — the identical body an OpenAI client sends
    // to either sglang or vLLM. The router keys affinity off the image URL.
    let img = json!({"model": "m", "stream": false, "messages": [{
        "role": "user",
        "content": [
            {"type": "text", "text": "what is in this image?"},
            {"type": "image_url", "image_url": {"url": "https://cdn.example/cat.png"}}
        ]
    }]});

    for _ in 0..5 {
        let r = client()
            .post(format!("{router}/v1/chat/completions"))
            .json(&img)
            .send()
            .await
            .unwrap();
        assert_eq!(r.status(), 200);
    }

    // All five identical-image requests land on ONE worker (its warm vision
    // cache), instead of round-robining across both.
    let (ha, hb) = (a.hit_count(), b.hit_count());
    assert_eq!(ha + hb, 5, "all requests served");
    assert!(
        ha == 5 || hb == 5,
        "image affinity co-locates repeats: a={ha} b={hb}"
    );

    // The image survived the hop to the upstream (routing didn't strip content).
    let winner = if ha == 5 { &a } else { &b };
    let body = &winner.hits.lock().unwrap()[0].body;
    assert_eq!(
        body["messages"][0]["content"][1]["image_url"]["url"],
        "https://cdn.example/cat.png"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn mixed_failover_to_healthy_worker() {
    // First candidate 500s; with retries=1 the router must fail over to the
    // second and return its 200. RoundRobin picks index 0 first (fresh counter).
    let (url_bad, bad) = spawn_mock(500, false, json!(null)).await;
    let (url_ok, ok) = spawn_mock(200, false, json!({"ok": true})).await;
    let state = make_state(
        vec![
            worker(
                json!({"worker_id": "bad", "url": url_bad, "model_name": "m", "disagg_mode": "mixed"}),
            ),
            worker(
                json!({"worker_id": "ok", "url": url_ok, "model_name": "m", "disagg_mode": "mixed"}),
            ),
        ],
        1,
    );
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m"}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(resp.json::<Value>().await.unwrap()["ok"], true);
    assert_eq!(bad.hit_count(), 1);
    assert_eq!(ok.hit_count(), 1);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn half_pd_names_the_missing_pool() {
    for (mode, missing) in [("prefill", "decode"), ("decode", "prefill")] {
        let state = make_state(
            vec![worker(json!({
                "worker_id": mode,
                "url": "http://127.0.0.1:1",
                "model_name": "m",
                "disagg_mode": mode
            }))],
            0,
        );
        let router = spawn_router(state).await;
        let resp = client()
            .post(format!("{router}/v1/chat/completions"))
            .json(&json!({"model": "m"}))
            .send()
            .await
            .unwrap();

        assert_eq!(resp.status(), 503);
        let body = resp.json::<Value>().await.unwrap();
        let error = body["error"].as_str().unwrap();
        assert!(error.contains(missing), "{error}");
        assert!(error.contains("PD dispatch requires both pools"), "{error}");
        assert!(!error.contains("mixed"), "{error}");
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn empty_fleet_reports_no_active_worker() {
    let router = spawn_router(make_state(vec![], 0)).await;
    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m"}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 503);
    assert_eq!(
        resp.json::<Value>().await.unwrap()["error"],
        "no active worker for model=\"m\""
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn breaker_stops_reselecting_a_dead_worker() {
    // The regression behind issue #82, end to end through the real router
    // rather than against the breaker in isolation.
    //
    // Failover already made every one of these ten requests succeed, so a test
    // that only checked status codes passed before the fix and after it. What
    // was broken is the *cost*: `tried` is per-request, so RoundRobin kept
    // offering the dead worker its turn -- 5 of 10 requests paid a wasted
    // upstream round trip. The assertion that matters is bad.hit_count(), which
    // is 5 without the breaker and 3 with it.
    let (url_bad, bad) = spawn_mock(500, false, json!(null)).await;
    let (url_ok, ok) = spawn_mock(200, false, json!({"ok": true})).await;
    let state = make_state(
        vec![
            worker(
                json!({"worker_id": "bad", "url": url_bad, "model_name": "m", "disagg_mode": "mixed"}),
            ),
            worker(
                json!({"worker_id": "ok", "url": url_ok, "model_name": "m", "disagg_mode": "mixed"}),
            ),
        ],
        1,
    );
    let router = spawn_router(state).await;

    for _ in 0..10 {
        let resp = client()
            .post(format!("{router}/v1/chat/completions"))
            .json(&json!({"model": "m"}))
            .send()
            .await
            .unwrap();
        assert_eq!(
            resp.status(),
            200,
            "failover must still serve every request"
        );
    }

    // Default threshold is 3. RoundRobin offers `bad` on every other request,
    // so it takes 3 of its turns to trip; after that it is out of rotation and
    // the 5s cooldown does not elapse within the test.
    assert_eq!(
        bad.hit_count(),
        3,
        "dead worker must stop being re-picked after the threshold (was 5 before the fix)"
    );
    assert_eq!(ok.hit_count(), 10, "healthy worker still serves everything");
}

fn duration_sum(body: &str, outcome: &str) -> f64 {
    body.lines()
        .find(|line| {
            line.starts_with("infera_request_duration_seconds_sum")
                && line.contains("router=\"mixed\"")
                && line.contains(&format!("outcome=\"{outcome}\""))
        })
        .and_then(|line| line.rsplit_once(' '))
        .and_then(|(_, value)| value.parse().ok())
        .unwrap_or(0.0)
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn mixed_client_error_records_attempt_duration() {
    let state = Arc::new(MockState {
        status: 400,
        sse: false,
        reply: json!(null),
        hits: Mutex::new(Vec::new()),
        abort_rids: Mutex::new(Vec::new()),
        hang: false,
        hang_stream: false,
        truncated_sse: false,
        delay: Duration::from_millis(200),
    });
    let (url, _) = serve_mock(state).await;
    let app_state = make_state(
        vec![worker(
            json!({"worker_id": "w-slow-4xx", "url": url, "model_name": "m", "disagg_mode": "mixed"}),
        )],
        0,
    );
    let router = spawn_router(app_state).await;
    let before = client()
        .get(format!("{router}/metrics"))
        .send()
        .await
        .unwrap()
        .text()
        .await
        .unwrap();
    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m"}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 400);
    let after = client()
        .get(format!("{router}/metrics"))
        .send()
        .await
        .unwrap()
        .text()
        .await
        .unwrap();
    let delta = duration_sum(&after, "4xx") - duration_sum(&before, "4xx");
    assert!(
        delta >= 0.15,
        "4xx duration {delta} should cover the worker attempt"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn breaker_ignores_client_errors() {
    // A 400 comes from the request, not the worker: it would be returned by
    // every worker in the fleet, so counting it would circuit-break all of
    // them. Ten bad requests must leave the worker in rotation.
    let (url, w) = spawn_mock(400, false, json!(null)).await;
    let state = make_state(
        vec![worker(
            json!({"worker_id": "w1", "url": url, "model_name": "m", "disagg_mode": "mixed"}),
        )],
        0,
    );
    let router = spawn_router(state).await;

    for _ in 0..10 {
        let _ = client()
            .post(format!("{router}/v1/chat/completions"))
            .json(&json!({"model": "m"}))
            .send()
            .await
            .unwrap();
    }
    assert_eq!(
        w.hit_count(),
        10,
        "4xx must not take a healthy worker out of rotation"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn mixed_streaming_relays_sse() {
    let (url, _mock) = spawn_mock(200, true, json!(null)).await;
    let state = make_state(
        vec![worker(json!({
            "worker_id": "w1", "url": url, "model_name": "m", "disagg_mode": "mixed"
        }))],
        0,
    );
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": true}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(
        resp.headers()
            .get(CONTENT_TYPE)
            .and_then(|v| v.to_str().ok())
            .unwrap_or(""),
        "text/event-stream"
    );
    let text = resp.text().await.unwrap();
    assert!(text.contains("data: "), "expected SSE frames, got {text:?}");
    assert!(text.contains("[DONE]"), "expected [DONE], got {text:?}");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn unknown_model_is_503() {
    let (url, _mock) = spawn_mock(200, false, json!(null)).await;
    let state = make_state(
        vec![worker(json!({
            "worker_id": "w1", "url": url, "model_name": "known", "disagg_mode": "mixed"
        }))],
        0,
    );
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "unknown"}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 503);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn bad_json_is_400() {
    let state = make_state(vec![], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .header(CONTENT_TYPE, "application/json")
        .body("{not json")
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 400);
}

// ---------------------------------------------------------------------------
// PD (disaggregated) dispatch — exercises protocol + dp submodules
// ---------------------------------------------------------------------------

fn prefill(url: &str, dp_size: Option<i64>) -> Arc<Worker> {
    let mut spec = json!({
        "worker_id": "p", "url": url, "model_name": "m", "disagg_mode": "prefill",
        "disagg_meta": {"protocol": "sglang-bootstrap", "params": {"bootstrap_addr": "10.0.0.1:9000"}}
    });
    if let Some(sz) = dp_size {
        spec["dp_size"] = json!(sz);
    }
    worker(spec)
}

fn decode(url: &str) -> Arc<Worker> {
    worker(json!({
        "worker_id": "d", "url": url, "model_name": "m", "disagg_mode": "decode",
        "disagg_meta": {"protocol": "sglang-bootstrap"}
    }))
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_unary_injects_matching_bootstrap_room() {
    let (p_url, p) = spawn_mock(200, false, json!({"who": "prefill"})).await;
    let (d_url, d) = spawn_mock(200, false, json!({"who": "decode"})).await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": false}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    // The client sees the DECODE leg's body, not prefill's.
    assert_eq!(resp.json::<Value>().await.unwrap()["who"], "decode");

    let p_hit = &p.hits.lock().unwrap()[0].body;
    let d_hit = &d.hits.lock().unwrap()[0].body;
    // Bootstrap fields come from the prefill worker's advertised addr.
    assert_eq!(d_hit["bootstrap_host"], "10.0.0.1");
    assert_eq!(d_hit["bootstrap_port"], 9000);
    // Both legs must carry the SAME room or the KV handoff can't rendezvous.
    assert!(p_hit["bootstrap_room"].is_number());
    assert_eq!(p_hit["bootstrap_room"], d_hit["bootstrap_room"]);
    let room = p_hit["bootstrap_room"].as_u64().unwrap();
    assert_eq!(p_hit["rid"], format!("infera-{room}"));
    assert_eq!(p_hit["rid"], d_hit["rid"]);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_mixed_request_transports_reject_before_dispatch() {
    let (p_url, p) = spawn_mock(200, false, json!({"who": "prefill"})).await;
    let (d_url, d) = spawn_mock(200, false, json!({"who": "decode"})).await;
    let p_worker = worker(json!({
        "worker_id": "p",
        "url": p_url,
        "model_name": "m",
        "disagg_mode": "prefill",
        "disagg_meta": {
            "protocol": "sglang-bootstrap",
            "params": {"bootstrap_addr": "10.0.0.1:9000"}
        },
        "request_transport": "http"
    }));
    let d_worker = worker(json!({
        "worker_id": "d",
        "url": d_url,
        "model_name": "m",
        "disagg_mode": "decode",
        "disagg_meta": {"protocol": "sglang-bootstrap"},
        "request_transport": "nats"
    }));
    let router = spawn_router(make_state(vec![p_worker, d_worker], 0)).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": false}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), StatusCode::SERVICE_UNAVAILABLE);
    assert_eq!(p.hit_count(), 0);
    assert_eq!(d.hit_count(), 0);
}

/// PD dual-dispatch is path-generic: a Responses request must reach both legs on
/// `/v1/responses` with the same bootstrap trio as a chat request gets. (The
/// engine side needs a patch to stop dropping those fields — see
/// `deploy/docker/patches/sglang_disagg/patch_responses_pd_bootstrap.py` — but
/// that is not the router's contract to keep.)
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_responses_injects_bootstrap_on_both_legs() {
    let (p_url, p) = spawn_mock(200, false, json!({"who": "prefill"})).await;
    let (d_url, d) = spawn_mock(200, false, json!({"who": "decode"})).await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/responses"))
        .json(&json!({"model": "m", "input": "1+1=?", "store": false}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 200);
    assert_eq!(resp.json::<Value>().await.unwrap()["who"], "decode");

    let p_hit = &p.hits.lock().unwrap()[0];
    let d_hit = &d.hits.lock().unwrap()[0];
    assert_eq!(p_hit.path, "/v1/responses");
    assert_eq!(d_hit.path, "/v1/responses");
    assert_eq!(d_hit.body["bootstrap_host"], "10.0.0.1");
    assert_eq!(d_hit.body["bootstrap_port"], 9000);
    assert!(p_hit.body["bootstrap_room"].is_number());
    assert_eq!(p_hit.body["bootstrap_room"], d_hit.body["bootstrap_room"]);
    assert_eq!(p_hit.body["request_id"], p_hit.body["rid"]);
    assert_eq!(d_hit.body["request_id"], d_hit.body["rid"]);
    assert_eq!(p_hit.body["request_id"], d_hit.body["request_id"]);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_dp_multiplexed_prefill_pins_rank() {
    // A dp_size=2 prefill worker (dp_rank unset) fans out to per-rank targets;
    // RoundRobin picks rank 0 first, so the room aligns to rank 0, the prefill
    // leg carries the DP-rank header, and decode is told which rank holds its KV.
    let (p_url, p) = spawn_mock(200, false, json!({"who": "prefill"})).await;
    let (d_url, d) = spawn_mock(200, false, json!({"who": "decode"})).await;
    let state = make_state(vec![prefill(&p_url, Some(2)), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": false}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);

    let p_hits = p.hits.lock().unwrap();
    let d_hits = d.hits.lock().unwrap();
    assert_eq!(p_hits[0].dp_rank.as_deref(), Some("0"));
    // room aligned so room % dp_size == rank(0).
    let room = p_hits[0].body["bootstrap_room"].as_u64().unwrap();
    assert_eq!(room % 2, 0);
    // Decode is told the prefill DP rank holding its KV.
    assert_eq!(d_hits[0].body["disagg_prefill_dp_rank"], 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_streaming_relays_decode_and_fires_prefill() {
    let (p_url, p) = spawn_mock(200, false, json!(null)).await;
    let (d_url, _d) = spawn_mock(200, true, json!(null)).await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": true}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    // An nginx hop with `proxy_buffering on` would otherwise accumulate the
    // events and hand the client silence while the worker streams normally.
    assert_eq!(
        resp.headers()
            .get("x-accel-buffering")
            .and_then(|v| v.to_str().ok()),
        Some("no"),
        "an SSE reply must tell a proxy not to buffer it"
    );
    let text = resp.text().await.unwrap();
    assert!(text.contains("[DONE]"), "expected decode SSE, got {text:?}");

    // Prefill is fired on a detached task; give it a beat to land.
    let deadline = Instant::now() + Duration::from_secs(2);
    while p.hit_count() == 0 && Instant::now() < deadline {
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    assert_eq!(
        p.hit_count(),
        1,
        "prefill leg must run even while streaming"
    );
    assert!(
        p.abort_rids.lock().unwrap().is_empty(),
        "a completed stream must not abort the engine request"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_responses_completed_stream_does_not_abort() {
    let (p_url, p) = spawn_mock(200, false, json!(null)).await;
    let (d_url, d) = spawn_mock(200, true, json!(null)).await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/responses"))
        .json(&json!({"model": "m", "input": "hello", "stream": true}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let text = resp.text().await.unwrap();
    assert!(text.contains("event: response.completed"));

    tokio::time::sleep(Duration::from_millis(100)).await;
    assert!(p.abort_rids.lock().unwrap().is_empty());
    assert!(d.abort_rids.lock().unwrap().is_empty());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_client_disconnect_posts_abort_request() {
    let (p_url, p) = spawn_mock_cfg(200, false, json!(null), true, false).await;
    let (d_url, d) = spawn_mock_cfg(200, true, json!(null), false, true).await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": true}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let mut stream = resp.bytes_stream();
    let first = stream.next().await;
    assert!(first.is_some());
    drop(stream);

    let deadline = Instant::now() + Duration::from_secs(2);
    while p.abort_rids.lock().unwrap().is_empty() && Instant::now() < deadline {
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    let p_rids = p.abort_rids.lock().unwrap().clone();
    let d_rids = d.abort_rids.lock().unwrap().clone();
    assert!(
        !p_rids.is_empty(),
        "dropped client must abort the hung prefill"
    );
    assert!(p_rids[0].starts_with("infera-"));
    assert_eq!(p_rids[0], d_rids[0]);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_prefill_drain_timeout_posts_abort_request() {
    let (p_url, p) = spawn_mock_cfg(200, false, json!(null), true, false).await;
    let (d_url, d) = spawn_mock(200, true, json!(null)).await;
    let mut state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    state.pd_prefill_drain_timeout = Duration::from_millis(80);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": true}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let _ = resp.text().await.unwrap();

    let deadline = Instant::now() + Duration::from_secs(2);
    while p.abort_rids.lock().unwrap().is_empty() && Instant::now() < deadline {
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    assert!(
        !p.abort_rids.lock().unwrap().is_empty(),
        "drain timeout must abort hung prefill"
    );
    assert!(
        !d.abort_rids.lock().unwrap().is_empty(),
        "drain timeout must abort the decode KV waiter"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_prefill_drain_timeout_starts_after_decode_stream_ends() {
    let (p_url, p) = spawn_mock_cfg(200, false, json!(null), true, false).await;
    let (d_url, d) = spawn_mock_cfg(200, true, json!(null), false, true).await;
    let mut state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    state.pd_prefill_drain_timeout = Duration::from_millis(80);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": true}))
        .send()
        .await
        .unwrap();
    let mut stream = resp.bytes_stream();
    assert!(stream.next().await.is_some());
    tokio::time::sleep(Duration::from_millis(160)).await;

    assert!(
        p.abort_rids.lock().unwrap().is_empty(),
        "drain timeout must not run while decode is still streaming"
    );
    assert!(d.abort_rids.lock().unwrap().is_empty());
    drop(stream);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_unary_worker_failure_aborts_both_engine_requests() {
    let (p_url, p) = spawn_mock(500, false, json!({"error": "KVTransferError"})).await;
    let (d_url, d) = spawn_mock(500, false, json!({"error": "KVTransferError"})).await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": false}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 500);

    let deadline = Instant::now() + Duration::from_secs(2);
    while (p.abort_rids.lock().unwrap().is_empty() || d.abort_rids.lock().unwrap().is_empty())
        && Instant::now() < deadline
    {
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    let p_rids = p.abort_rids.lock().unwrap().clone();
    let d_rids = d.abort_rids.lock().unwrap().clone();
    assert!(
        !p_rids.is_empty(),
        "prefill failure must abort its inflight request"
    );
    assert!(
        !d_rids.is_empty(),
        "prefill failure must abort the decode KV waiter"
    );
    assert_eq!(p_rids[0], d_rids[0]);
}

/// A chat decode leg that closes cleanly without `[DONE]` is incomplete.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_chat_eof_without_done_aborts_the_pair() {
    let (p_url, p) = spawn_mock_cfg(200, false, json!(null), true, false).await;
    let (d_url, d) = spawn_mock_truncated_sse().await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": true}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let text = resp.text().await.unwrap();
    assert!(!text.contains("[DONE]"), "the mock decode stops early");

    let deadline = Instant::now() + Duration::from_secs(5);
    while (p.abort_rids.lock().unwrap().is_empty() || d.abort_rids.lock().unwrap().is_empty())
        && Instant::now() < deadline
    {
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    assert!(
        !p.abort_rids.lock().unwrap().is_empty(),
        "a truncated chat stream must abort the hung prefill"
    );
    assert!(
        !d.abort_rids.lock().unwrap().is_empty(),
        "a truncated chat stream must abort the decode leg too"
    );
}

/// A Responses decode leg that closes without `response.completed` is incomplete.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_responses_eof_without_completed_aborts_the_pair() {
    let (p_url, p) = spawn_mock_cfg(200, false, json!(null), true, false).await;
    let (d_url, d) = spawn_mock_truncated_sse().await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/responses"))
        .json(&json!({"model": "m", "input": "hello", "stream": true}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let text = resp.text().await.unwrap();
    assert!(
        !text.contains("event: response.completed"),
        "the mock decode stops early"
    );

    let deadline = Instant::now() + Duration::from_secs(5);
    while (p.abort_rids.lock().unwrap().is_empty() || d.abort_rids.lock().unwrap().is_empty())
        && Instant::now() < deadline
    {
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    assert!(
        !p.abort_rids.lock().unwrap().is_empty(),
        "a truncated decode stream must abort the hung prefill"
    );
    assert!(
        !d.abort_rids.lock().unwrap().is_empty(),
        "a truncated decode stream must abort the decode leg too"
    );
}

/// A non-streaming PD request has no response body to drop, so the disconnect
/// only shows up as the handler future being cancelled while both legs are
/// still generating. Nothing reads them after that, and both engines keep the
/// inflight slot until someone aborts the request id.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_unary_client_disconnect_posts_abort_request() {
    let (p_url, p) = spawn_mock_cfg(200, false, json!(null), true, false).await;
    let (d_url, d) = spawn_mock_cfg(200, false, json!(null), true, false).await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let pending = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": false}))
        .send();
    // Both legs hang, so the client gives up on a request still in flight.
    assert!(
        tokio::time::timeout(Duration::from_millis(200), pending)
            .await
            .is_err(),
        "the mock legs must still be generating when the client leaves"
    );

    let deadline = Instant::now() + Duration::from_secs(5);
    while (p.abort_rids.lock().unwrap().is_empty() || d.abort_rids.lock().unwrap().is_empty())
        && Instant::now() < deadline
    {
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    let p_rids = p.abort_rids.lock().unwrap().clone();
    let d_rids = d.abort_rids.lock().unwrap().clone();
    assert!(
        !p_rids.is_empty(),
        "a dropped unary request must abort the prefill leg"
    );
    assert!(
        !d_rids.is_empty(),
        "a dropped unary request must abort the decode leg"
    );
    assert!(p_rids[0].starts_with("infera-"));
    assert_eq!(p_rids[0], d_rids[0]);
}

/// Parallel sampling splits one router request id into `n` engine ids, so a
/// disconnect has to abort every one of them.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_unary_client_disconnect_aborts_every_sample() {
    let (p_url, p) = spawn_mock_cfg(200, false, json!(null), true, false).await;
    let (d_url, _d) = spawn_mock_cfg(200, false, json!(null), true, false).await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let pending = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": false, "n": 3}))
        .send();
    assert!(tokio::time::timeout(Duration::from_millis(200), pending)
        .await
        .is_err());

    let deadline = Instant::now() + Duration::from_secs(5);
    while p.abort_rids.lock().unwrap().len() < 3 && Instant::now() < deadline {
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    let mut rids = p.abort_rids.lock().unwrap().clone();
    rids.sort();
    assert_eq!(rids.len(), 3, "each sample carries its own engine rid");
    assert!(rids[0].ends_with("_0") && rids[2].ends_with("_2"));
}

/// The completed unary pair owns its own abort decision; the drop guard must
/// not fire a second one behind it.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_unary_success_does_not_abort() {
    let (p_url, p) = spawn_mock(200, false, json!(null)).await;
    let (d_url, d) = spawn_mock(200, false, json!({"answer": 42})).await;
    let state = make_state(vec![prefill(&p_url, None), decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": false}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    assert_eq!(resp.json::<Value>().await.unwrap()["answer"], 42);

    tokio::time::sleep(Duration::from_millis(150)).await;
    assert!(p.abort_rids.lock().unwrap().is_empty());
    assert!(d.abort_rids.lock().unwrap().is_empty());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn pd_protocol_mismatch_is_501() {
    let (p_url, _p) = spawn_mock(200, false, json!(null)).await;
    let (d_url, _d) = spawn_mock(200, false, json!(null)).await;
    // Prefill advertises no sglang-bootstrap protocol → unsupported connector.
    let p = worker(json!({
        "worker_id": "p", "url": p_url, "model_name": "m", "disagg_mode": "prefill",
        "disagg_meta": {"protocol": "mooncake"}
    }));
    let state = make_state(vec![p, decode(&d_url)], 0);
    let router = spawn_router(state).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m"}))
        .send()
        .await
        .unwrap();

    assert_eq!(resp.status(), 501);
}

// ---------------------------------------------------------------------------
// ATOM: serial-pull PD (atom-mooncake) and DP ranks in the body
// ---------------------------------------------------------------------------

fn atom_worker(role: &str, url: &str, handshake_port: i64) -> Arc<Worker> {
    worker(json!({
        "worker_id": role, "url": url, "model_name": "m", "engine": "atom",
        "disagg_mode": role,
        "disagg_meta": {"protocol": "atom-mooncake", "params": {
            "host": "10.0.0.1", "http_port": 19000, "handshake_port": handshake_port,
            "tp_size": 4, "dp_size": 1
        }}
    }))
}

/// What an ATOM prefill answers: its KV hand-off, rank included.
fn atom_prefill_reply() -> Value {
    json!({"choices": [{"text": "x"}], "kv_transfer_params": {
        "do_remote_prefill": true, "do_remote_decode": false,
        "transfer_id": "t-1", "first_token_id": 7, "remote_block_ids": [1, 2],
        "remote_host": "10.0.0.2", "remote_handshake_port": 21301, "dp_rank": 0
    }})
}

async fn atom_pd(
    p_status: u16,
    p_reply: Value,
    d_sse: bool,
) -> (String, Arc<MockState>, Arc<MockState>) {
    let (p_url, p) = spawn_mock(p_status, false, p_reply).await;
    let (d_url, d) = spawn_mock(200, d_sse, json!({"who": "decode"})).await;
    let workers = vec![
        atom_worker("prefill", &p_url, 21301),
        atom_worker("decode", &d_url, 21311),
    ];
    (spawn_router(make_state(workers, 0)).await, p, d)
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn atom_pd_unary_pulls_the_prefill_handoff_into_decode() {
    let (router, p, d) = atom_pd(200, atom_prefill_reply(), false).await;

    let resp = client()
        .post(format!("{router}/v1/completions"))
        .json(&json!({"model": "m", "prompt": "hi", "max_tokens": 64}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    assert_eq!(resp.json::<Value>().await.unwrap()["who"], "decode");

    let p_hit = &p.hits.lock().unwrap()[0];
    assert_eq!(p_hit.path, "/v1/completions");
    assert_eq!(p_hit.body["max_tokens"], 1);
    assert_eq!(p_hit.body["stream"], false);
    // The prefill pushes to the decode's handshake port.
    let p_kv = &p_hit.body["kv_transfer_params"];
    assert_eq!(p_kv["do_remote_decode"], true);
    assert_eq!(p_kv["remote_handshake_port"], 21311);

    let d_hit = &d.hits.lock().unwrap()[0];
    assert_eq!(d_hit.body["max_tokens"], 64);
    // The decode gets the prefill's hand-off verbatim, plus where its KV sits.
    let d_kv = &d_hit.body["kv_transfer_params"];
    assert_eq!(d_kv["transfer_id"], "t-1");
    assert_eq!(d_kv["first_token_id"], 7);
    assert_eq!(d_kv["remote_handshake_port"], 21301);
    assert_eq!(d_kv["remote_tp_size"], 4);
    assert_eq!(d_kv["remote_dp_rank"], 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn atom_pd_streaming_relays_the_decode() {
    let (router, p, d) = atom_pd(200, atom_prefill_reply(), true).await;

    let resp = client()
        .post(format!("{router}/v1/chat/completions"))
        .json(&json!({"model": "m", "stream": true, "messages": []}))
        .send()
        .await
        .unwrap();
    assert_eq!(resp.status(), 200);
    let text = resp.text().await.unwrap();
    assert!(text.contains("[DONE]"), "expected decode SSE, got {text:?}");
    // The prefill ran first and non-streaming; the decode streams.
    assert_eq!(p.hits.lock().unwrap()[0].body["stream"], false);
    assert_eq!(d.hits.lock().unwrap()[0].body["stream"], true);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn atom_pd_failed_prefill_never_reaches_decode() {
    for (status, reply, want) in [
        (503, json!(null), 503),
        (400, json!(null), 400),
        // A 200 without a hand-off leaves the decode nothing to pull.
        (200, json!({"choices": []}), 502),
    ] {
        let (router, p, d) = atom_pd(status, reply, false).await;
        let resp = client()
            .post(format!("{router}/v1/completions"))
            .json(&json!({"model": "m", "prompt": "hi"}))
            .send()
            .await
            .unwrap();
        assert_eq!(resp.status(), want, "prefill answered {status}");
        assert_eq!(p.hit_count(), 1);
        assert_eq!(
            d.hit_count(),
            0,
            "decode must not run after a failed prefill"
        );
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn atom_dp_rank_rides_in_the_body_and_follows_the_session() {
    use infera_router::session_affinity::{Mode, Sessions};
    let (url, mock) = spawn_mock(200, false, json!({})).await;
    let w = worker(json!({
        "worker_id": "w", "url": url, "model_name": "m", "engine": "atom", "dp_size": 4
    }));
    let mut state = make_state(vec![w], 0);
    state.sessions = Arc::new(Sessions::new(Mode::Both, Duration::from_secs(3600), 64));
    let router = spawn_router(state).await;
    for session in ["s1", "s2", "s1", "s2"] {
        let resp = client()
            .post(format!("{router}/v1/completions"))
            .header("X-Session-ID", session)
            .json(&json!({"model": "m", "prompt": "hi"}))
            .send()
            .await
            .unwrap();
        assert_eq!(resp.status(), 200);
    }
    let hits = mock.hits.lock().unwrap();
    // ATOM ignores the header, so none is sent.
    assert!(hits.iter().all(|h| h.dp_rank.is_none()));
    let ranks: Vec<_> = hits
        .iter()
        .map(|h| h.body["data_parallel_rank"].as_i64().unwrap())
        .collect();
    assert_eq!(ranks, vec![0, 1, 0, 1]);
    assert_eq!(hits[0].body["prompt"], "hi");
}

// ---------------------------------------------------------------------------
// Introspection endpoints
// ---------------------------------------------------------------------------

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn introspection_endpoints_report_fleet() {
    let (url, _mock) = spawn_mock(200, false, json!(null)).await;
    let state = make_state(
        vec![
            worker(
                json!({"worker_id": "w1", "url": url, "model_name": "m", "disagg_mode": "mixed"}),
            ),
            worker(
                json!({"worker_id": "w2", "url": "http://x", "model_name": "m", "disagg_mode": "mixed", "status": "draining"}),
            ),
        ],
        0,
    );
    let router = spawn_router(state).await;
    let c = client();

    let health: Value = c
        .get(format!("{router}/health"))
        .send()
        .await
        .unwrap()
        .json()
        .await
        .unwrap();
    assert_eq!(health["status"], "ok");
    assert_eq!(health["active_workers"], 1); // w2 is draining

    let models: Value = c
        .get(format!("{router}/v1/models"))
        .send()
        .await
        .unwrap()
        .json()
        .await
        .unwrap();
    let ids: Vec<&str> = models["data"]
        .as_array()
        .unwrap()
        .iter()
        .map(|m| m["id"].as_str().unwrap())
        .collect();
    assert_eq!(ids, vec!["m"]);

    let workers: Value = c
        .get(format!("{router}/v1/workers"))
        .send()
        .await
        .unwrap()
        .json()
        .await
        .unwrap();
    assert_eq!(workers["workers"].as_array().unwrap().len(), 2);

    let metrics = c
        .get(format!("{router}/metrics"))
        .send()
        .await
        .unwrap()
        .text()
        .await
        .unwrap();
    assert!(
        metrics.contains("infera_router_active_workers 1"),
        "got {metrics:?}"
    );
}

// ---------------------------------------------------------------------------
// kv-aware self-heal: the router asks a worker to flush a chain that never
// anchored. Everything upstream of the POST is covered by in-crate unit tests;
// this is the hop they cannot reach -- that the request actually leaves the
// router, over HTTP, at the endpoint the engine serves.
// ---------------------------------------------------------------------------

/// Spawn a worker that records which cache-flush endpoints it was asked for.
async fn spawn_flush_mock() -> (String, Arc<Mutex<Vec<String>>>) {
    let seen: Arc<Mutex<Vec<String>>> = Arc::new(Mutex::new(Vec::new()));
    let s = seen.clone();
    let router = Router::new()
        .route(
            "/flush_cache",
            post(move || {
                let s = s.clone();
                async move {
                    s.lock().unwrap().push("/flush_cache".to_string());
                    (StatusCode::OK, "Cache flushed.")
                }
            }),
        )
        .layer(DefaultBodyLimit::disable());
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    tokio::spawn(async move {
        axum::serve(listener, router).await.unwrap();
    });
    (format!("http://127.0.0.1:{port}"), seen)
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn a_flush_request_reaches_the_worker_over_http() {
    let (url, seen) = spawn_flush_mock().await;
    let flush = infera_router::kv_selfheal::spawn(proxy::build_upstream_client(0.0).unwrap());

    let w = worker(json!({
        "worker_id": "a", "url": url, "model_name": "m", "engine": "sglang",
    }));
    flush.request(&w);

    let deadline = Instant::now() + Duration::from_secs(5);
    while Instant::now() < deadline && seen.lock().unwrap().is_empty() {
        tokio::time::sleep(Duration::from_millis(20)).await;
    }
    assert_eq!(
        seen.lock().unwrap().as_slice(),
        ["/flush_cache"],
        "the engine's own cache-flush endpoint is what re-emits the rooted event"
    );

    // The detector re-arms on every unanchored batch -- it has to, or one
    // refusal would retire the repair for good -- so holding the POST down to
    // one is the actor's job: a worker with a flush in flight, and then inside
    // its cooldown, is asked no again. Repeating it would clear a cache that
    // is in the middle of being rebuilt.
    flush.request(&w);
    tokio::time::sleep(Duration::from_millis(200)).await;
    assert_eq!(seen.lock().unwrap().len(), 1);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn a_worker_reachable_only_over_nats_is_not_flushed_over_http() {
    let (url, seen) = spawn_flush_mock().await;
    let flush = infera_router::kv_selfheal::spawn(proxy::build_upstream_client(0.0).unwrap());

    // Its `url` may not be routable from here at all, so an HTTP POST would
    // fail on every retry while looking like an unreachable worker.
    flush.request(&worker(json!({
        "worker_id": "a", "url": url, "model_name": "m", "engine": "sglang",
        "request_transport": "nats",
    })));

    tokio::time::sleep(Duration::from_millis(300)).await;
    assert!(seen.lock().unwrap().is_empty());
}

// ---------------------------------------------------------------------------
// POST /v1/responses/input_tokens (LiteLLM CountTokens)
// ---------------------------------------------------------------------------

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn responses_input_tokens_counts_pre_tokenized_ids() {
    // Integer `prompt` hashes without a tokenizer; the handler still requires
    // Responses `input` so this is the wiring check, not a template render.
    let router = spawn_router(make_kv_state(vec![], 0)).await;
    let r = client()
        .post(format!("{router}/v1/responses/input_tokens"))
        .json(&json!({"model": "m", "input": "hi", "prompt": [1, 2, 3, 4]}))
        .send()
        .await
        .unwrap();
    assert_eq!(r.status(), 200);
    let body: Value = r.json().await.unwrap();
    assert_eq!(body["input_tokens"], 4);
    assert_eq!(body["object"], "response.input_tokens");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn responses_input_tokens_refuses_previous_response_id() {
    let router = spawn_router(make_kv_state(vec![], 0)).await;
    let r = client()
        .post(format!("{router}/v1/responses/input_tokens"))
        .json(&json!({
            "model": "m",
            "input": "hi",
            "previous_response_id": "resp_1",
        }))
        .send()
        .await
        .unwrap();
    assert_eq!(r.status(), 400);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn responses_input_tokens_requires_input() {
    let router = spawn_router(make_kv_state(vec![], 0)).await;
    let r = client()
        .post(format!("{router}/v1/responses/input_tokens"))
        .json(&json!({"model": "m"}))
        .send()
        .await
        .unwrap();
    assert_eq!(r.status(), 400);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn responses_input_tokens_unavailable_without_tokenizer() {
    let router = spawn_router(make_state(vec![], 0)).await;
    let r = client()
        .post(format!("{router}/v1/responses/input_tokens"))
        .json(&json!({"model": "m", "input": "hi"}))
        .send()
        .await
        .unwrap();
    assert_eq!(r.status(), 503);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn session_header_pins_each_pd_role_without_aligning_their_ranks() {
    use infera_router::policy::Role;
    use infera_router::session_affinity::{Mode, Sessions};
    for mode in [Mode::Off, Mode::Prefill, Mode::Both] {
        let (p_url, p) = spawn_mock(200, false, json!({})).await;
        let (d_url, d) = spawn_mock(200, false, json!({})).await;
        let mut dw = (*decode(&d_url)).clone();
        dw.dp_size = Some(8);
        let dw = Arc::new(dw);
        let mut state = make_state(vec![prefill(&p_url, Some(8)), dw.clone()], 0);
        state.sessions = Arc::new(Sessions::new(mode, Duration::from_secs(3600), 64));
        state.policy.pick(&[dw], &json!({}), Role::Decode);
        let router = spawn_router(state).await;
        for session in ["s1", "s2", "s1"] {
            let response = client()
                .post(format!("{router}/v1/chat/completions"))
                .header("X-Session-ID", session)
                .json(&json!({"model":"m", "messages":[{"role":"user","content":"unchanged"}]}))
                .send()
                .await
                .unwrap();
            assert_eq!(response.status(), 200);
            response.bytes().await.unwrap();
        }
        let ph = p.hits.lock().unwrap();
        let dh = d.hits.lock().unwrap();
        let pr: Vec<_> = ph.iter().map(|x| x.dp_rank.as_deref().unwrap()).collect();
        let dr: Vec<_> = dh.iter().map(|x| x.dp_rank.as_deref().unwrap()).collect();
        assert_eq!(
            pr,
            if mode == Mode::Off {
                vec!["0", "1", "2"]
            } else {
                vec!["0", "1", "0"]
            }
        );
        assert_eq!(
            dr,
            if mode == Mode::Both {
                vec!["1", "2", "1"]
            } else {
                vec!["1", "2", "3"]
            }
        );
        for (p, d) in ph.iter().zip(dh.iter()) {
            assert_eq!(p.body["bootstrap_room"], d.body["bootstrap_room"]);
            assert_eq!(
                p.body["messages"],
                json!([{"role":"user","content":"unchanged"}])
            );
            assert!(p.body.get("session_id").is_none());
        }
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn session_binding_is_invalidated_on_decode_eof_without_done() {
    use infera_router::session_affinity::{Mode, Sessions};
    let (p_url, _) = spawn_mock(200, false, json!({})).await;
    let (d_url, d) = spawn_mock_truncated_sse().await;
    let mut dw = (*decode(&d_url)).clone();
    dw.dp_size = Some(8);
    let mut state = make_state(vec![prefill(&p_url, Some(8)), Arc::new(dw)], 0);
    state.sessions = Arc::new(Sessions::new(Mode::Both, Duration::from_secs(3600), 64));
    let router = spawn_router(state).await;
    for _ in 0..2 {
        client()
            .post(format!("{router}/v1/chat/completions"))
            .header("X-Session-ID", "same-session")
            .json(&json!({"model":"m","stream":true}))
            .send()
            .await
            .unwrap()
            .bytes()
            .await
            .unwrap();
    }
    let hits = d.hits.lock().unwrap();
    assert_eq!(hits[0].dp_rank.as_deref(), Some("0"));
    assert_eq!(hits[1].dp_rank.as_deref(), Some("1"));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn session_both_also_pins_aggregated_requests() {
    use infera_router::session_affinity::{Mode, Sessions};
    let (url, mock) = spawn_mock(200, false, json!({})).await;
    let w = worker(json!({"worker_id":"w","url":url,"model_name":"m","dp_size":8}));
    let mut state = make_state(vec![w], 0);
    state.sessions = Arc::new(Sessions::new(Mode::Both, Duration::from_secs(3600), 64));
    let router = spawn_router(state).await;
    for session in ["s1", "s2", "s1"] {
        client()
            .post(format!("{router}/v1/completions"))
            .header("X-Session-ID", session)
            .json(&json!({"model":"m","prompt":"unchanged"}))
            .send()
            .await
            .unwrap()
            .bytes()
            .await
            .unwrap();
    }
    let hits = mock.hits.lock().unwrap();
    assert_eq!(
        hits.iter()
            .map(|h| h.dp_rank.as_deref().unwrap())
            .collect::<Vec<_>>(),
        vec!["0", "1", "0"]
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
#[ignore = "needs a broker: INFERA_TEST_NATS"]
async fn session_binding_is_reselected_after_nats_4xx() {
    use infera_router::nats_request::{
        request_subject, NatsRequestClient, HDR_STATUS, HDR_TYPE, TYPE_DONE,
    };
    use infera_router::session_affinity::{Mode, Sessions};
    let url = std::env::var("INFERA_TEST_NATS").expect("set INFERA_TEST_NATS");
    for stream in [false, true] {
        let wid = format!("session-nats-{}-{stream}", std::process::id());
        let nc = async_nats::connect(&url).await.unwrap();
        let mut requests = nc.subscribe(request_subject(&wid)).await.unwrap();
        nc.flush().await.unwrap();
        let worker_task = tokio::spawn(async move {
            let mut ranks = Vec::new();
            for _ in 0..2 {
                let message = tokio::time::timeout(Duration::from_secs(5), requests.next())
                    .await
                    .unwrap()
                    .unwrap();
                let payload: Value = serde_json::from_slice(&message.payload).unwrap();
                ranks.push(
                    payload["headers"][infera_router::dp::DP_RANK_HEADER]
                        .as_str()
                        .unwrap()
                        .to_owned(),
                );
                let mut headers = async_nats::HeaderMap::new();
                headers.insert(HDR_TYPE, TYPE_DONE);
                headers.insert(HDR_STATUS, "400");
                nc.publish_with_headers(message.reply.unwrap(), headers, Bytes::new())
                    .await
                    .unwrap();
                nc.flush().await.unwrap();
            }
            ranks
        });
        let w = worker(
            json!({"worker_id":wid,"url":"http://unused","model_name":"m","dp_size":8,"request_transport":"nats"}),
        );
        let mut state = make_state(vec![w], 0);
        state.sessions = Arc::new(Sessions::new(Mode::Both, Duration::from_secs(3600), 64));
        state.nats = Some(Arc::new(
            NatsRequestClient::connect(Some(&url), 3.0, 0.0, 0)
                .await
                .unwrap(),
        ));
        let router = spawn_router(state).await;
        for _ in 0..2 {
            let response = client()
                .post(format!("{router}/v1/chat/completions"))
                .header("X-Session-ID", "same-session")
                .json(&json!({"model":"m","stream":stream}))
                .send()
                .await
                .unwrap();
            assert_eq!(response.status(), 400);
            response.bytes().await.unwrap();
        }
        assert_eq!(worker_task.await.unwrap(), vec!["0", "1"]);
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn session_transport_mismatch_reselects_both_roles() {
    use infera_router::session_affinity::{Mode, Sessions};
    let (p_url, p) = spawn_mock(200, false, json!({})).await;
    let (d_url, d) = spawn_mock(200, false, json!({})).await;
    let mut nats_d = (*decode(&d_url)).clone();
    nats_d.worker_id = "d-nats".into();
    nats_d.request_transport = "nats".into();
    let mut state = make_state(
        vec![prefill(&p_url, Some(8)), Arc::new(nats_d), decode(&d_url)],
        0,
    );
    state.sessions = Arc::new(Sessions::new(Mode::Both, Duration::from_secs(3600), 64));
    let router = spawn_router(state).await;
    for expected in [503, 200] {
        let response = client()
            .post(format!("{router}/v1/chat/completions"))
            .header("X-Session-ID", "same-session")
            .json(&json!({"model":"m", "stream":false}))
            .send()
            .await
            .unwrap();
        assert_eq!(response.status(), expected);
        response.bytes().await.unwrap();
    }
    assert_eq!(p.hit_count(), 1);
    assert_eq!(d.hit_count(), 1);
    assert_eq!(p.hits.lock().unwrap()[0].dp_rank.as_deref(), Some("1"));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn session_http_failure_only_reselects_failed_role() {
    use infera_router::session_affinity::{Mode, Sessions};
    // The streaming decode error occurs before the downstream SSE response opens.
    for (p_status, d_status, stream) in [(500, 200, false), (200, 500, false), (200, 500, true)] {
        let (p_url, p) = spawn_mock(p_status, false, json!({})).await;
        let (d_url, d) = spawn_mock(d_status, false, json!({})).await;
        let mut dw = (*decode(&d_url)).clone();
        dw.dp_size = Some(8);
        let mut state = make_state(vec![prefill(&p_url, Some(8)), Arc::new(dw)], 0);
        state.sessions = Arc::new(Sessions::new(Mode::Both, Duration::from_secs(3600), 64));
        let sessions = state.sessions.clone();
        let router = spawn_router(state).await;
        for _ in 0..2 {
            let response = client()
                .post(format!("{router}/v1/chat/completions"))
                .header("X-Session-ID", "same-session")
                .json(&json!({"model":"m", "stream":stream}))
                .send()
                .await
                .unwrap();
            assert_eq!(response.status(), if stream { 502 } else { d_status });
            response.bytes().await.unwrap();
            // The streaming prefill drain completes independently of decode.
            tokio::time::timeout(Duration::from_secs(3), async {
                while !sessions
                    .metrics()
                    .contains("infera_router_session_active{role=\"prefill\"} 0")
                {
                    tokio::task::yield_now().await;
                }
            })
            .await
            .unwrap();
        }
        let ph = p.hits.lock().unwrap();
        let dh = d.hits.lock().unwrap();
        assert_eq!(ph.len(), 2);
        assert_eq!(dh.len(), 2);
        assert_eq!(ph[0].dp_rank.as_deref(), Some("0"));
        assert_eq!(dh[0].dp_rank.as_deref(), Some("0"));
        assert_eq!(
            ph[1].dp_rank.as_deref(),
            Some(if p_status == 200 { "0" } else { "1" })
        );
        assert_eq!(
            dh[1].dp_rank.as_deref(),
            Some(if d_status == 200 { "0" } else { "1" })
        );
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
#[ignore = "requires INFERA_TEST_NATS with JetStream; run serially"]
async fn session_nats_pd_failure_only_reselects_failed_role() {
    use infera_router::nats_request::{
        request_subject, NatsRequestClient, HDR_INBOX, HDR_STATUS, HDR_TYPE, REQUEST_STREAM,
        TYPE_DONE,
    };
    use infera_router::session_affinity::{Mode, Sessions};
    let url = std::env::var("INFERA_TEST_NATS").expect("set INFERA_TEST_NATS");
    let nc = async_nats::connect(&url).await.unwrap();
    let js = async_nats::jetstream::new(nc.clone());
    for stream in [false, true] {
        for (p_status, d_status, fail_dispatch) in
            [(500, 200, false), (200, 500, false), (200, 200, true)]
        {
            let prefix = format!(
                "session-pd-{}-{stream}-{p_status}-{d_status}-{fail_dispatch}",
                std::process::id()
            );
            let mut pw = (*prefill("http://unused", Some(8))).clone();
            pw.worker_id = format!("{prefix}-p");
            pw.request_transport = "nats".into();
            let mut dw = (*decode("http://unused")).clone();
            dw.worker_id = format!("{prefix}-d");
            dw.request_transport = "nats".into();
            dw.dp_size = Some(8);
            let nats = NatsRequestClient::connect(Some(&url), 3.0, 0.0, 100)
                .await
                .unwrap();
            let original = js
                .get_stream(REQUEST_STREAM)
                .await
                .unwrap()
                .cached_info()
                .config
                .clone();
            if fail_dispatch {
                // P publishes successfully; D fails before it can return a reply stream.
                let mut config = original.clone();
                config.subjects = vec![request_subject(&pw.worker_id)];
                js.update_stream(config).await.unwrap();
            }
            let mut tasks = Vec::new();
            for (w, status) in [(&pw, p_status), (&dw, d_status)] {
                if fail_dispatch && w.worker_id == dw.worker_id {
                    continue;
                }
                let mut requests = nc.subscribe(request_subject(&w.worker_id)).await.unwrap();
                let nc = nc.clone();
                tasks.push(tokio::spawn(async move {
                    let mut ranks = Vec::new();
                    while ranks.len() < 2 {
                        let message =
                            tokio::time::timeout(Duration::from_secs(10), requests.next())
                                .await
                                .unwrap()
                                .unwrap();
                        let payload: Value = serde_json::from_slice(&message.payload).unwrap();
                        let inbox = message
                            .headers
                            .as_ref()
                            .unwrap()
                            .get(HDR_INBOX)
                            .unwrap()
                            .as_str()
                            .to_owned();
                        let abort = payload["path"] == "/abort_request";
                        if !abort {
                            ranks.push(
                                payload["headers"][infera_router::dp::DP_RANK_HEADER]
                                    .as_str()
                                    .unwrap()
                                    .to_owned(),
                            );
                        }
                        let mut headers = async_nats::HeaderMap::new();
                        headers.insert(HDR_TYPE, TYPE_DONE);
                        headers.insert(HDR_STATUS, if abort { 200 } else { status }.to_string());
                        nc.publish_with_headers(inbox, headers, Bytes::new())
                            .await
                            .unwrap();
                        nc.flush().await.unwrap();
                    }
                    ranks
                }));
            }
            nc.flush().await.unwrap();
            let mut state = make_state(vec![Arc::new(pw), Arc::new(dw)], 0);
            state.sessions = Arc::new(Sessions::new(Mode::Both, Duration::from_secs(3600), 64));
            let sessions = state.sessions.clone();
            state.nats = Some(Arc::new(nats));
            let router = spawn_router(state).await;
            for _ in 0..2 {
                let response = client()
                    .post(format!("{router}/v1/chat/completions"))
                    .header("X-Session-ID", "same-session")
                    .json(&json!({"model":"m", "stream":stream}))
                    .send()
                    .await;
                if stream && d_status != 200 {
                    // An immediate failed terminal frame may close HTTP before headers flush.
                    if let Ok(response) = response {
                        assert_eq!(response.status(), 200);
                        assert!(response.bytes().await.is_err());
                    }
                } else {
                    let response = response.unwrap();
                    assert_eq!(
                        response.status(),
                        if fail_dispatch {
                            502
                        } else if stream {
                            200
                        } else {
                            d_status
                        }
                    );
                    response.bytes().await.unwrap();
                }
                tokio::time::timeout(Duration::from_secs(3), async {
                    loop {
                        let metrics = sessions.metrics();
                        if ["prefill", "decode"].iter().all(|role| {
                            metrics.contains(&format!(
                                "infera_router_session_active{{role=\"{role}\"}} 0"
                            ))
                        }) {
                            break;
                        }
                        tokio::task::yield_now().await;
                    }
                })
                .await
                .unwrap();
            }
            let p_ranks = tasks.remove(0).await.unwrap();
            assert_eq!(p_ranks, vec!["0", if p_status == 200 { "0" } else { "1" }]);
            if fail_dispatch {
                assert!(sessions
                    .metrics()
                    .contains("infera_router_session_selected_total{role=\"decode\"} 2"));
                js.update_stream(original).await.unwrap();
            } else {
                let d_ranks = tasks.remove(0).await.unwrap();
                assert_eq!(d_ranks, vec!["0", if d_status == 200 { "0" } else { "1" }]);
            }
        }
    }
}
