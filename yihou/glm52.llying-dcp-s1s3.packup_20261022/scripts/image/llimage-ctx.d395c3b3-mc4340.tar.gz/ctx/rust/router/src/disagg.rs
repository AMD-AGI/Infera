///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2026, Advanced Micro Devices, Inc. All rights reserved.
//
// SPDX-License-Identifier: MIT
///////////////////////////////////////////////////////////////////////////////
//! PD dual-dispatch.
//!
//! Concurrent topology (SGLang bootstrap, vLLM Mooncake): both legs are POSTed
//! concurrently; the decode leg streams back to the client while the prefill
//! leg drains in a background task. If the client disconnects before the stream
//! completes, or the prefill POST exceeds `pd_prefill_drain_timeout`, the router
//! aborts the engine request (`/abort_request`) so a hung Mooncake session
//! cannot occupy an inflight slot forever.
//!
//! Serial pull (ATOM Mooncake): the decode body is built from the prefill's
//! response, so the prefill runs to completion first (see [`serial_pull`]).

use std::sync::Arc;
use std::time::Duration;

use tokio::sync::oneshot;
use tokio::task::JoinHandle;

use axum::body::{Body, Bytes};
use axum::http::{header, StatusCode};
use axum::response::Response;
use serde_json::{Map, Value};

use crate::breaker::{is_worker_fault, CircuitBreaker};
use crate::dp;
use crate::handlers::AppState;
use crate::nats_request::{Frame, NatsRequestClient};
use crate::policy::{ActiveGuard, RequestTokens, Role};
use crate::pool::{DisaggMode, RouteTarget, Snapshot};
use crate::protocol;
use crate::proxy::{GuardedStream, StreamEnd};
use crate::util::{json_error, truncate_chars};

const DECODE_OPEN_RETRIES: u32 = 3;

#[derive(Clone)]
enum AbortTransport {
    Http {
        http: reqwest::Client,
        prefill_url: String,
        decode_url: String,
    },
    Nats {
        nats: Arc<NatsRequestClient>,
        prefill_worker_id: String,
        decode_worker_id: String,
    },
}

/// Entry point. Caller guarantees the model has both prefill and decode workers.
#[allow(clippy::too_many_arguments)]
pub async fn dispatch(
    state: &AppState,
    snap: &Snapshot,
    model: &str,
    request: &Value,
    raw: Bytes,
    stream: bool,
    path: &str,
    session: Option<&str>,
) -> Response {
    // role_hint lets a cost-aware policy weight P (cache-heavy: a hit skips a
    // whole prefill pass) differently from D (route by load).
    // Each pool is filtered against the breaker independently: a wedged prefill
    // and a wedged decode are different events against different pools, and one
    // open breaker must not remove the other role's healthy workers.
    let p_avail = state
        .breaker
        .filter(snap.list_active(model, DisaggMode::Prefill), |w| {
            w.worker_id.as_str()
        });
    let d_avail = state
        .breaker
        .filter(snap.list_active(model, DisaggMode::Decode), |w| {
            w.worker_id.as_str()
        });
    let tokens = RequestTokens::default();
    let (p_pick, p_session) = state.sessions.pick(
        state.policy.as_ref(),
        &p_avail,
        request,
        &tokens,
        Role::Prefill,
        model,
        session,
    );
    let (d_pick, d_session) = state.sessions.pick(
        state.policy.as_ref(),
        &d_avail,
        request,
        &tokens,
        Role::Decode,
        model,
        session,
    );
    let p = p_pick.target;
    let d = d_pick.target;
    if p.worker.request_transport != d.worker.request_transport {
        for lease in [&p_session, &d_session].into_iter().flatten() {
            lease.invalidate();
        }
        return json_error(
            StatusCode::SERVICE_UNAVAILABLE,
            "prefill and decode workers use different request transports",
        );
    }
    // One guard for both legs; dropped when the decode body finishes streaming
    // (or on any early error path), balancing the in-flight load refcount.
    let guard = ActiveGuard::start(
        state.policy.clone(),
        vec![
            (p.route_key(), p_pick.blocks),
            (d.route_key(), d_pick.blocks),
        ],
    )
    .with_sessions(p_session, d_session)
    .with_decode_demand(d_pick.decode_demand);

    async {
        let proto = match protocol::resolve_pd_protocol(&p.worker, &d.worker) {
            Ok(pr) => pr,
            Err(e) => {
                guard.invalidate_sessions();
                return json_error(StatusCode::NOT_IMPLEMENTED, &e.to_string());
            }
        };

        let base: Map<String, Value> = match serde_json::from_slice::<Value>(&raw) {
            Ok(Value::Object(m)) => m,
            Ok(_) => {
                guard.invalidate_sessions();
                return json_error(StatusCode::BAD_REQUEST, "body must be a JSON object");
            }
            Err(e) => {
                guard.invalidate_sessions();
                return json_error(StatusCode::BAD_REQUEST, &format!("bad json: {e}"));
            }
        };

        // ATOM: the decode body is built from the prefill's response, so the
        // legs run one after the other, over HTTP as on the Python backend.
        if proto == protocol::PdProtocol::AtomMooncake {
            return serial_pull(state, &p, &d, path, base, stream, guard).await;
        }

        let room = dp::align_room_to_prefill_rank(rand::random::<u64>() >> 1, &p);

        let mut p_body = base.clone();
        let mut d_body = base;
        let shaped = match proto {
            // SGLang: both legs carry the SAME top-level bootstrap fields.
            protocol::PdProtocol::SglangBootstrap => {
                protocol::annotate_sglang(&mut p_body, &p.worker, path, room)
                    .and_then(|_| protocol::annotate_sglang(&mut d_body, &p.worker, path, room))
            }
            // vLLM Mooncake: ASYMMETRIC — prefill runs prefill+1tok & pushes KV; decode
            // pulls it via the prefill's bootstrap and generates the rest.
            protocol::PdProtocol::VllmMooncake => {
                protocol::annotate_vllm_prefill(&mut p_body, path, room);
                protocol::annotate_vllm_decode(&mut d_body, &p.worker, path, room)
            }
            protocol::PdProtocol::AtomMooncake => unreachable!("served by serial_pull"),
        };
        if let Err(e) = shaped {
            guard.invalidate_sessions();
            return json_error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string());
        }
        // Tell the decode worker which prefill DP rank holds its KV.
        if let Some(rank) = p.dp_rank {
            d_body.insert("disagg_prefill_dp_rank".into(), Value::from(rank));
        }

        // Both legs over NATS only when both workers registered for it. The KV
        // transfer is engine-to-engine either way (the bootstrap_room travels in
        // the bodies), so the delivery channel is all that changes.
        if let Some(nats) = state.nats.clone() {
            if p.worker.request_transport == "nats" && d.worker.request_transport == "nats" {
                // Either leg being at its backlog limit refuses the whole request:
                // dispatching half a PD pair would leave the other worker holding a
                // bootstrap_room nobody completes.
                if !(nats.admit(&p.worker.worker_id).await && nats.admit(&d.worker.worker_id).await)
                {
                    guard.invalidate_sessions();
                    drop(guard);
                    return Response::builder()
                        .status(StatusCode::TOO_MANY_REQUESTS)
                        .header(header::CONTENT_TYPE, "application/json")
                        .header("Retry-After", "1")
                        .body(Body::from(
                            r#"{"error":"PD worker request backlog over limit"}"#,
                        ))
                        .expect("429 response is valid");
                }
                return dual_nats(state, &nats, &p, &d, path, p_body, d_body, stream, guard).await;
            }
        }

        let p_url = format!("{}{}", p.worker.url, path);
        let d_url = format!("{}{}", d.worker.url, path);

        if stream {
            stream_dual(state, &p, &d, path, p_url, d_url, p_body, d_body, guard).await
        } else {
            unary_dual(state, &p, &d, p_url, d_url, p_body, d_body, guard).await
        }
    }
    .await
}

/// Streaming: fire prefill in the background, stream decode back.
#[allow(clippy::too_many_arguments)]
async fn stream_dual(
    state: &AppState,
    p: &RouteTarget,
    d: &RouteTarget,
    path: &str,
    p_url: String,
    d_url: String,
    p_body: Map<String, Value>,
    d_body: Map<String, Value>,
    mut guard: ActiveGuard,
) -> Response {
    let rid = p_body
        .get("rid")
        .and_then(|v| v.as_str())
        .map(str::to_string)
        .unwrap_or_default();
    let n = sample_count(&p_body);
    let rid_for_log = rid.clone();
    let (incomplete_tx, incomplete_rx) = oneshot::channel();
    let prefill_guard = take_prefill_guard(state, &mut guard);
    let drain_handle = spawn_prefill_drain(
        state.http.clone(),
        state.breaker.clone(),
        p.worker.worker_id.clone(),
        p_url,
        p_body,
        p.dp_rank,
        prefill_guard,
        guard.take_prefill_session(),
    );
    watch_prefill_after_decode(
        incomplete_rx,
        drain_handle,
        state.pd_prefill_drain_timeout,
        AbortTransport::Http {
            http: state.http.clone(),
            prefill_url: p.worker.url.clone(),
            decode_url: d.worker.url.clone(),
        },
        rid,
        n,
    );
    let mut abort_unless_stream_owns_it = FireOnDrop(Some(incomplete_tx));

    let tracker = crate::metrics::RequestTracker::start_disagg(
        &d.worker.model_name,
        &p.worker.worker_id,
        &d.worker.worker_id,
    );
    match open_decode(state, d, &d_url, &d_body).await {
        Ok(resp) => crate::proxy::sse_response()
            // guard drops when the decode stream ends -> on_request_finished.
            .body(Body::from_stream(GuardedStream::new_with_incomplete_abort(
                resp.bytes_stream(),
                guard,
                crate::proxy::StreamSource {
                    path: path.to_string(),
                    worker_id: d.worker.worker_id.clone(),
                    request_id: rid_for_log,
                    stall_warn: state.stream_stall_warn,
                },
                abort_unless_stream_owns_it.take(),
                Some(tracker),
            )))
            .expect("stream response is valid"),
        Err(msg) => {
            let mut t = tracker;
            t.set_outcome("error");
            t.finish();
            guard.invalidate_sessions();
            json_error(StatusCode::BAD_GATEWAY, &msg)
        }
    }
}

/// Non-streaming: POST both legs concurrently, return the decode JSON.
#[allow(clippy::too_many_arguments)]
async fn unary_dual(
    state: &AppState,
    p: &RouteTarget,
    d: &RouteTarget,
    p_url: String,
    d_url: String,
    p_body: Map<String, Value>,
    d_body: Map<String, Value>,
    mut guard: ActiveGuard,
) -> Response {
    let prefill_guard = take_prefill_guard(state, &mut guard);
    let prefill_session = guard.take_prefill_session();
    // Held until both legs finish (dropped at fn end) -> on_request_finished.
    let mut _guard = guard;
    let mut tracker = crate::metrics::RequestTracker::start_disagg(
        &d.worker.model_name,
        &p.worker.worker_id,
        &d.worker.worker_id,
    );
    let rid = p_body
        .get("rid")
        .and_then(|v| v.as_str())
        .map(str::to_string)
        .unwrap_or_default();
    let n = sample_count(&p_body);
    let transport = AbortTransport::Http {
        http: state.http.clone(),
        prefill_url: p.worker.url.clone(),
        decode_url: d.worker.url.clone(),
    };
    // A client disconnect drops this future, cancelling both POSTs without the
    // engines hearing about it: they keep generating and hold their inflight
    // slots. The guard turns that drop into the abort the legs never got.
    let mut abort_on_disconnect = AbortPairOnDrop::arm(transport.clone(), rid.clone(), n);
    let p_fut = async {
        let response = post_leg(state, &p_url, p_body, p.dp_rank).await;
        if prefill_guard.is_some() {
            let failed =
                finish_unary_prefill(state, p, &p_url, response, prefill_session.as_ref()).await;
            drop(prefill_guard);
            drop(prefill_session);
            (None, failed, None)
        } else {
            (Some(response), false, prefill_session)
        }
    };
    let d_fut = post_leg(state, &d_url, d_body, d.dp_rank);
    let ((p_res, mut pair_failed, prefill_session), d_res) = tokio::join!(p_fut, d_fut);
    if let Some(response) = p_res {
        pair_failed =
            finish_unary_prefill(state, p, &p_url, response, prefill_session.as_ref()).await;
    }

    drop(prefill_session);
    let (response, decode_failed) =
        finish_unary_decode(state, d, d_res, &mut tracker, &_guard).await;
    pair_failed |= decode_failed;
    // Both legs answered, so nothing is left running that this guard has to
    // clean up; a failed pair is aborted below with its own reason logged.
    abort_on_disconnect.disarm();
    if pair_failed {
        tracing::warn!("PD unary pair failed; aborting rid={rid}");
        abort_sglang_pair(transport, &rid, n);
        if response.status().is_success() {
            // Prefill failed while decode returned 200; still count as error.
            tracker.set_outcome("error");
        }
    }
    tracker.finish();
    response
}

/// ATOM Mooncake (serial pull): POST the prefill for one token, then POST the
/// decode with the `kv_transfer_params` the prefill returned. A failed prefill
/// never reaches the decode, whose body would be incomplete. No abort to send
/// either way: ATOM has no abort endpoint, and dropping a leg's connection is
/// what tells it the client is gone.
async fn serial_pull(
    state: &AppState,
    p: &RouteTarget,
    d: &RouteTarget,
    path: &str,
    base: Map<String, Value>,
    stream: bool,
    mut guard: ActiveGuard,
) -> Response {
    let mut tracker = crate::metrics::RequestTracker::start_disagg(
        &d.worker.model_name,
        &p.worker.worker_id,
        &d.worker.worker_id,
    );
    let prefill_session = guard.take_prefill_session();
    let handoff = match atom_prefill(state, p, d, path, base.clone()).await {
        Ok(handoff) => handoff,
        Err((status, msg)) => {
            if let Some(lease) = &prefill_session {
                lease.invalidate();
            }
            tracker.set_outcome(if status.is_client_error() {
                "4xx"
            } else {
                "5xx"
            });
            tracker.finish();
            return json_error(status, &msg);
        }
    };
    // The prefill is done: its load ends now, the decode's with the reply.
    drop(guard.take_first());
    drop(prefill_session);

    let mut d_body = base;
    if let Err(e) = protocol::annotate_atom_decode(&mut d_body, &p.worker, handoff) {
        guard.invalidate_sessions();
        tracker.set_outcome("error");
        tracker.finish();
        return json_error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string());
    }
    dp::insert_body_rank(&mut d_body, d);
    let d_url = format!("{}{}", d.worker.url, path);

    if !stream {
        let d_res = post_leg(state, &d_url, d_body, dp::header_rank(d)).await;
        let (response, _) = finish_unary_decode(state, d, d_res, &mut tracker, &guard).await;
        tracker.finish();
        return response;
    }
    match open_decode(state, d, &d_url, &d_body).await {
        Ok(resp) => crate::proxy::sse_response()
            // guard drops when the decode stream ends -> on_request_finished.
            .body(Body::from_stream(GuardedStream::new_with_incomplete_abort(
                resp.bytes_stream(),
                guard,
                crate::proxy::StreamSource {
                    path: path.to_string(),
                    worker_id: d.worker.worker_id.clone(),
                    request_id: String::new(),
                    stall_warn: state.stream_stall_warn,
                },
                None,
                Some(tracker),
            )))
            .expect("stream response is valid"),
        Err(msg) => {
            tracker.set_outcome("error");
            tracker.finish();
            guard.invalidate_sessions();
            json_error(StatusCode::BAD_GATEWAY, &msg)
        }
    }
}

/// The prefill leg of a serial pull. Returns the decode's hand-off, or the
/// status and message for the client when the prefill failed.
async fn atom_prefill(
    state: &AppState,
    p: &RouteTarget,
    d: &RouteTarget,
    path: &str,
    mut body: Map<String, Value>,
) -> Result<Map<String, Value>, (StatusCode, String)> {
    let wid = &p.worker.worker_id;
    protocol::annotate_atom_prefill(&mut body, &d.worker, path)
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    dp::insert_body_rank(&mut body, p);
    let url = format!("{}{}", p.worker.url, path);
    let reply = post_leg(state, &url, body, dp::header_rank(p)).await;
    let (status, bytes) = match reply {
        Ok(resp) => (resp.status(), resp.bytes().await),
        Err(e) => {
            state.breaker.record_failure(wid);
            return Err((
                StatusCode::BAD_GATEWAY,
                format!("prefill {wid} unreachable: {e}"),
            ));
        }
    };
    let Ok(bytes) = bytes else {
        state.breaker.record_failure(wid);
        return Err((
            StatusCode::BAD_GATEWAY,
            format!("prefill {wid} reply could not be read"),
        ));
    };
    score_leg(&state.breaker, wid, status.as_u16());
    if !status.is_success() {
        tracing::warn!("prefill {wid} returned {} in serial pull", status.as_u16());
        let text = String::from_utf8_lossy(&bytes);
        let msg = format!(
            "prefill {}: {}",
            status.as_u16(),
            truncate_chars(&text, 500)
        );
        return Err((status, msg));
    }
    serde_json::from_slice::<Value>(&bytes)
        .map_err(anyhow::Error::from)
        .and_then(|reply| protocol::atom_handoff(&reply))
        .map_err(|e| {
            tracing::warn!("prefill {wid} hand-off unusable: {e}");
            (
                StatusCode::BAD_GATEWAY,
                format!("prefill {wid} hand-off unusable: {e}"),
            )
        })
}

/// Score a unary decode reply and turn it into the client's response. The bool
/// is whether the decode failed as a worker fault, which fails the pair.
async fn finish_unary_decode(
    state: &AppState,
    d: &RouteTarget,
    d_res: reqwest::Result<reqwest::Response>,
    tracker: &mut crate::metrics::RequestTracker,
    guard: &ActiveGuard,
) -> (Response, bool) {
    let mut failed = false;
    let response = match d_res {
        Ok(resp) => {
            let st = resp.status();
            if !st.is_success() {
                guard.invalidate_sessions();
            }
            if is_worker_fault(st.as_u16()) {
                failed = true;
                state.breaker.record_failure(&d.worker.worker_id);
            } else if st.is_success() {
                state.breaker.record_success(&d.worker.worker_id);
            } else {
                state.breaker.record_neutral(&d.worker.worker_id);
            }
            let ct = content_type(&resp);
            match resp.bytes().await {
                Ok(bytes) => {
                    if st.is_success() {
                        if let Ok(v) = serde_json::from_slice::<Value>(&bytes) {
                            if let Some(usage) = v.get("usage") {
                                if let Some(p) = usage.get("prompt_tokens").and_then(|x| x.as_u64())
                                {
                                    tracker.set_input_tokens(p);
                                }
                                if let Some(c) =
                                    usage.get("completion_tokens").and_then(|x| x.as_u64())
                                {
                                    tracker.set_output_tokens(c);
                                }
                            }
                        }
                        tracker.set_outcome("ok");
                    } else if st.is_client_error() {
                        tracker.set_outcome("4xx");
                    } else if st.is_server_error() {
                        tracker.set_outcome("5xx");
                    } else {
                        tracker.set_outcome("error");
                    }
                    Response::builder()
                        .status(st)
                        .header(header::CONTENT_TYPE, ct)
                        .body(Body::from(bytes))
                        .expect("unary response is valid")
                }
                Err(e) => {
                    tracker.set_outcome("error");
                    guard.invalidate_sessions();
                    json_error(
                        StatusCode::BAD_GATEWAY,
                        &format!("decode {} read failed: {e}", d.worker.worker_id),
                    )
                }
            }
        }
        Err(e) => {
            guard.invalidate_sessions();
            failed = true;
            state.breaker.record_failure(&d.worker.worker_id);
            tracker.set_outcome("error");
            json_error(
                StatusCode::BAD_GATEWAY,
                &format!("decode {} unreachable: {e}", d.worker.worker_id),
            )
        }
    };
    (response, failed)
}

async fn finish_unary_prefill(
    state: &AppState,
    p: &RouteTarget,
    p_url: &str,
    p_res: reqwest::Result<reqwest::Response>,
    session: Option<&crate::session_affinity::Lease>,
) -> bool {
    let mut pair_failed = false;
    match p_res {
        Ok(resp) => {
            let st = resp.status();
            if resp.bytes().await.is_err() || !st.is_success() {
                if let Some(lease) = session {
                    lease.invalidate();
                }
            }
            if st.is_client_error() || st.is_server_error() {
                tracing::warn!(
                    "prefill {} returned {} (decode may hang)",
                    p_url,
                    st.as_u16()
                );
            }
            if is_worker_fault(st.as_u16()) {
                pair_failed = true;
                state.breaker.record_failure(&p.worker.worker_id);
            } else if st.is_success() {
                state.breaker.record_success(&p.worker.worker_id);
            } else {
                state.breaker.record_neutral(&p.worker.worker_id);
            }
        }
        Err(e) => {
            if let Some(lease) = session {
                lease.invalidate();
            }
            tracing::warn!("prefill {} failed: {e}", p_url);
            pair_failed = true;
            state.breaker.record_failure(&p.worker.worker_id);
        }
    }

    pair_failed
}

fn take_prefill_guard(state: &AppState, guard: &mut ActiveGuard) -> Option<ActiveGuard> {
    (state.pd_prefill_guard_release == crate::config::PrefillGuardRelease::Completion)
        .then(|| guard.take_first())
        .flatten()
}

/// Both legs over NATS. Prefill is published and drained detached; decode's
/// reply is what reaches the client.
#[allow(clippy::too_many_arguments)]
async fn dual_nats(
    state: &AppState,
    nats: &Arc<NatsRequestClient>,
    p: &RouteTarget,
    d: &RouteTarget,
    path: &str,
    p_body: Map<String, Value>,
    d_body: Map<String, Value>,
    stream: bool,
    mut guard: ActiveGuard,
) -> Response {
    let rid = p_body
        .get("rid")
        .and_then(|v| v.as_str())
        .map(str::to_string)
        .unwrap_or_default();
    let n = sample_count(&p_body);
    let rid_for_log = rid.clone();
    let p_payload = leg_payload(path, false, p.dp_rank, p_body);
    let d_payload = leg_payload(path, stream, d.dp_rank, d_body);

    let (incomplete_tx, incomplete_rx) = oneshot::channel();
    let prefill_guard = take_prefill_guard(state, &mut guard);
    let drain_handle = spawn_prefill_drain_nats(
        nats.clone(),
        state.breaker.clone(),
        p.worker.worker_id.clone(),
        p_payload,
        prefill_guard,
        guard.take_prefill_session(),
    );
    watch_prefill_after_decode(
        incomplete_rx,
        drain_handle,
        state.pd_prefill_drain_timeout,
        AbortTransport::Nats {
            nats: nats.clone(),
            prefill_worker_id: p.worker.worker_id.clone(),
            decode_worker_id: d.worker.worker_id.clone(),
        },
        rid,
        n,
    );

    // Armed before the dispatch, as the HTTP leg is before `open_decode`: a
    // client that drops during it would otherwise take a bare sender with it,
    // leaving the watcher to cancel the prefill drain with no abort for the
    // decode request already on the wire.
    let mut abort_unless_decode_owns_it = FireOnDrop(Some(incomplete_tx));

    // Start before JetStream publish/ack so a dispatch failure still records
    // the time spent waiting on NATS (same pattern as the mixed path).
    let mut tracker = crate::metrics::RequestTracker::start_disagg(
        &d.worker.model_name,
        &p.worker.worker_id,
        &d.worker.worker_id,
    );

    let bindings = guard.session_bindings();
    let wid = d.worker.worker_id.clone();
    let mut reply = match nats.dispatch(&wid, &d_payload).await {
        Ok(r) => r,
        Err(e) => {
            guard.invalidate_sessions();
            state.breaker.record_failure(&wid);
            abort_unless_decode_owns_it.settle(StreamEnd::Incomplete);
            // Same 502 as the Python path; keep outcome labels aligned.
            tracker.set_outcome("5xx");
            tracker.finish();
            return json_error(
                StatusCode::BAD_GATEWAY,
                &format!("decode {wid} unreachable over nats: {e}"),
            );
        }
    };

    if !stream {
        let mut abort_unless_done = FireOnDrop(abort_unless_decode_owns_it.take());
        let mut buf: Vec<u8> = Vec::new();
        let mut status = StatusCode::OK;
        let mut done_seen = false;
        loop {
            let frame = reply.next().await;
            crate::session_affinity::observe_reply(frame.as_ref(), &bindings);
            match frame {
                Some(Frame::Data(b)) => buf.extend_from_slice(&b),
                Some(Frame::Done { status: s }) => {
                    status = StatusCode::from_u16(s).unwrap_or(StatusCode::OK);
                    done_seen = true;
                    break;
                }
                Some(Frame::Error { status: s, message }) => {
                    // 504 on a timeout, 502 for a worker-side failure.
                    let code = s
                        .and_then(|c| StatusCode::from_u16(c).ok())
                        .unwrap_or(StatusCode::BAD_GATEWAY);
                    score_leg(&state.breaker, &wid, code.as_u16());
                    tracing::warn!(
                        "decode (nats) {wid} failed: {}",
                        truncate_chars(&message, 200)
                    );
                    tracker.set_outcome("error");
                    tracker.finish();
                    return json_error(code, &format!("decode {wid} nats failed"));
                }
                None => break,
            }
        }
        if !done_seen {
            // The worker stopped talking without finishing. Scoring this as a
            // 200 would record the exact profile the breaker exists to catch --
            // a worker that accepts work and then goes quiet -- as health.
            state.breaker.record_failure(&wid);
            drop(guard);
            tracker.set_outcome("error");
            tracker.finish();
            return json_error(
                StatusCode::BAD_GATEWAY,
                &format!("decode {wid} closed the nats reply without finishing"),
            );
        }
        score_leg(&state.breaker, &wid, status.as_u16());
        drop(guard);
        abort_unless_done.settle(unary_nats_end(status.as_u16()));
        if status.is_success() {
            if let Ok(v) = serde_json::from_slice::<Value>(&buf) {
                if let Some(usage) = v.get("usage") {
                    if let Some(p) = usage.get("prompt_tokens").and_then(|x| x.as_u64()) {
                        tracker.set_input_tokens(p);
                    }
                    if let Some(c) = usage.get("completion_tokens").and_then(|x| x.as_u64()) {
                        tracker.set_output_tokens(c);
                    }
                }
            }
            tracker.set_outcome("ok");
        } else if status.is_client_error() {
            tracker.set_outcome("4xx");
        } else if status.is_server_error() {
            tracker.set_outcome("5xx");
        } else {
            tracker.set_outcome("error");
        }
        tracker.finish();
        return Response::builder()
            .status(status)
            .header(header::CONTENT_TYPE, "application/json")
            .body(Body::from(buf))
            .expect("unary response is valid");
    }

    // Streaming commits at hand-off, as the HTTP path does. Success is not
    // recorded yet: an accepted request says nothing about whether this worker
    // produces anything, and the failure profile worth catching is exactly the
    // one that accepts and then goes quiet. It is recorded on the first byte.
    // Reuse the tracker started before dispatch so NATS publish/ack time is
    // included in the request duration.
    let breaker = state.breaker.clone();
    let body = futures::stream::unfold(
        (Some(reply), breaker, wid, false, false, bindings),
        |(reply, breaker, wid, served, fail_after_chunk, bindings)| async move {
            if fail_after_chunk {
                return Some((
                    Err(std::io::Error::other("decode NATS stream failed")),
                    (None, breaker, wid, served, false, bindings),
                ));
            }
            let mut r = reply?;
            let frame = r.next().await;
            crate::session_affinity::observe_reply(frame.as_ref(), &bindings);
            match frame {
                Some(Frame::Data(b)) => {
                    if !served && !b.is_empty() {
                        // Bytes are flowing, so this worker is doing the work.
                        breaker.record_success(&wid);
                    }
                    let served = served || !b.is_empty();
                    Some((
                        Ok::<Bytes, std::io::Error>(b),
                        (Some(r), breaker, wid, served, false, bindings),
                    ))
                }
                Some(Frame::Error { message, .. }) => {
                    tracing::warn!(
                        "decode (nats) {wid} stream failed: {}",
                        truncate_chars(&message, 200)
                    );
                    if !served {
                        breaker.record_failure(&wid);
                    }
                    let chunk = Bytes::from(format!(
                        "data: {{\"error\":\"decode {wid} nats stream failed\"}}\n\n"
                    ));
                    Some((Ok(chunk), (None, breaker, wid, served, true, bindings)))
                }
                Some(Frame::Done { status }) => {
                    score_leg(&breaker, &wid, status);
                    match nats_stream_end(Some(status)) {
                        Ok(()) => None,
                        Err(error) => {
                            Some((Err(error), (None, breaker, wid, served, false, bindings)))
                        }
                    }
                }
                None => {
                    breaker.record_failure(&wid);
                    Some((
                        Err(nats_stream_end(None).expect_err("missing done must fail")),
                        (None, breaker, wid, served, false, bindings),
                    ))
                }
            }
        },
    );
    crate::proxy::sse_response()
        .body(Body::from_stream(
            crate::proxy::guarded_with_incomplete_abort(
                body,
                guard,
                crate::proxy::StreamSource {
                    path: path.to_string(),
                    worker_id: d.worker.worker_id.clone(),
                    request_id: rid_for_log,
                    stall_warn: state.stream_stall_warn,
                },
                abort_unless_decode_owns_it.take(),
                Some(tracker),
            ),
        ))
        .expect("stream response is valid")
}

/// The request envelope the worker side expects, shared with the mixed path.
fn leg_payload(
    path: &str,
    stream: bool,
    dp_rank: Option<i64>,
    body: Map<String, Value>,
) -> Vec<u8> {
    let headers = match dp_rank {
        Some(r) => {
            let mut m = Map::new();
            m.insert(dp::DP_RANK_HEADER.to_string(), Value::from(r.to_string()));
            Value::Object(m)
        }
        None => Value::Null,
    };
    serde_json::to_vec(&serde_json::json!({
        "path": path,
        "stream": stream,
        "headers": headers,
        "body": Value::Object(body),
    }))
    .expect("the envelope is serialisable")
}

/// Detached prefill over NATS. Its controller owns timeout and abort policy.
fn spawn_prefill_drain_nats(
    nats: Arc<NatsRequestClient>,
    breaker: Arc<CircuitBreaker>,
    worker_id: String,
    payload: Vec<u8>,
    guard: Option<ActiveGuard>,
    session: Option<crate::session_affinity::Lease>,
) -> JoinHandle<()> {
    tokio::spawn(async move {
        let _guard = guard;
        drain_prefill_nats(nats, breaker, worker_id, payload, session).await;
    })
}

async fn drain_prefill_nats(
    nats: Arc<NatsRequestClient>,
    breaker: Arc<CircuitBreaker>,
    worker_id: String,
    payload: Vec<u8>,
    session: Option<crate::session_affinity::Lease>,
) {
    let bindings: Vec<_> = session.iter().map(|s| s.binding()).collect();
    let mut reply = match nats.dispatch(&worker_id, &payload).await {
        Ok(r) => r,
        Err(e) => {
            if let Some(s) = &session {
                s.invalidate();
            }
            tracing::warn!("prefill (nats) {worker_id} failed: {e} (decode may hang on KVPoll)");
            breaker.record_failure(&worker_id);
            return;
        }
    };
    loop {
        let frame = reply.next().await;
        crate::session_affinity::observe_reply(frame.as_ref(), &bindings);
        match frame {
            Some(Frame::Data(_)) => {}
            Some(Frame::Done { status }) => {
                if !StatusCode::from_u16(status).is_ok_and(|s| s.is_success()) {
                    tracing::warn!(
                        "prefill (nats) {worker_id} returned {status} (decode may hang on KVPoll)"
                    );
                }
                score_leg(&breaker, &worker_id, status);
                return;
            }
            Some(Frame::Error { message, .. }) => {
                tracing::warn!(
                    "prefill (nats) {worker_id} failed: {} (decode may hang on KVPoll)",
                    truncate_chars(&message, 200)
                );
                breaker.record_failure(&worker_id);
                return;
            }
            None => return,
        }
    }
}

/// One leg's outcome against the worker that produced it. The two legs are
/// different workers with independent health, so neither is scored for the
/// other's failure. A 4xx is the request's fault, not the worker's.
///
/// Used for the NATS legs too, where the status arrives in the `done` frame:
/// a `done` says the request finished, not that it succeeded, since the worker
/// proxies whatever its engine returned. Scoring on the frame kind alone would
/// read every failed prefill as health.
fn score_leg(breaker: &Arc<CircuitBreaker>, worker_id: &str, status: u16) {
    if is_worker_fault(status) {
        breaker.record_failure(worker_id);
    } else if (200..400).contains(&status) {
        breaker.record_success(worker_id);
    } else {
        breaker.record_neutral(worker_id);
    }
}

/// Detached prefill POST. Its controller owns timeout and abort policy.
#[allow(clippy::too_many_arguments)]
fn spawn_prefill_drain(
    http: reqwest::Client,
    breaker: Arc<CircuitBreaker>,
    worker_id: String,
    url: String,
    body: Map<String, Value>,
    dp_rank: Option<i64>,
    guard: Option<ActiveGuard>,
    session: Option<crate::session_affinity::Lease>,
) -> JoinHandle<()> {
    tokio::spawn(async move {
        let _guard = guard;
        drain_prefill_http(http, breaker, worker_id, url, body, dp_rank, session).await;
    })
}

async fn drain_prefill_http(
    http: reqwest::Client,
    breaker: Arc<CircuitBreaker>,
    worker_id: String,
    url: String,
    body: Map<String, Value>,
    dp_rank: Option<i64>,
    session: Option<crate::session_affinity::Lease>,
) {
    let mut req = http.post(&url).json(&Value::Object(body));
    if let Some(r) = dp_rank {
        req = req.header(dp::DP_RANK_HEADER, r.to_string());
    }
    match req.send().await {
        Ok(resp) => {
            let st = resp.status();
            let failed = resp.bytes().await.is_err() || !st.is_success();
            if failed {
                if let Some(s) = &session {
                    s.invalidate();
                }
            }
            if st.is_client_error() || st.is_server_error() {
                tracing::warn!(
                    "prefill {url} returned {} (decode may hang on KVPoll)",
                    st.as_u16()
                );
            }
            if is_worker_fault(st.as_u16()) {
                breaker.record_failure(&worker_id);
            } else if st.is_success() {
                breaker.record_success(&worker_id);
            } else {
                breaker.record_neutral(&worker_id);
            }
        }
        Err(e) => {
            if let Some(s) = &session {
                s.invalidate();
            }
            tracing::warn!("prefill {url} failed: {e} (decode may hang on KVPoll)");
            breaker.record_failure(&worker_id);
        }
    }
}

fn watch_prefill_after_decode(
    rx: oneshot::Receiver<StreamEnd>,
    mut drain: JoinHandle<()>,
    timeout: Duration,
    transport: AbortTransport,
    rid: String,
    n: usize,
) {
    tokio::spawn(async move {
        match rx.await {
            Ok(StreamEnd::Incomplete) => {
                drain.abort();
                if rid.is_empty() {
                    return;
                }
                abort_sglang_pair(transport, &rid, n);
            }
            Ok(StreamEnd::Complete) => {
                if timeout.is_zero() {
                    let _ = drain.await;
                    return;
                }
                if tokio::time::timeout(timeout, &mut drain).await.is_err() {
                    drain.abort();
                    if rid.is_empty() {
                        tracing::warn!(
                            "prefill drain timed out {:?} after decode completed; protocol has no \
                             abort request id, closing the drain connection",
                            timeout
                        );
                    } else {
                        tracing::warn!(
                            "prefill drain timed out {:?} after decode completed; aborting rid={rid}",
                            timeout
                        );
                        abort_sglang_pair(transport, &rid, n);
                    }
                }
            }
            Err(_) => drain.abort(),
        }
    });
}

fn sample_count(body: &Map<String, Value>) -> usize {
    body.get("n")
        .and_then(Value::as_u64)
        .and_then(|n| usize::try_from(n).ok())
        .filter(|n| *n > 0)
        .unwrap_or(1)
}

fn abort_request_ids(rid: &str, n: usize) -> Vec<String> {
    if rid.is_empty() {
        return Vec::new();
    }
    if n <= 1 {
        return vec![rid.to_string()];
    }
    (0..n).map(|index| format!("{rid}_{index}")).collect()
}

fn abort_sglang_pair(transport: AbortTransport, rid: &str, n: usize) {
    for request_id in abort_request_ids(rid, n) {
        match &transport {
            AbortTransport::Http {
                http,
                prefill_url,
                decode_url,
            } => {
                abort_sglang_request(http.clone(), prefill_url.clone(), request_id.clone());
                abort_sglang_request(http.clone(), decode_url.clone(), request_id);
            }
            AbortTransport::Nats {
                nats,
                prefill_worker_id,
                decode_worker_id,
            } => {
                abort_sglang_request_nats(
                    nats.clone(),
                    prefill_worker_id.clone(),
                    request_id.clone(),
                );
                abort_sglang_request_nats(nats.clone(), decode_worker_id.clone(), request_id);
            }
        }
    }
}

fn abort_sglang_request(http: reqwest::Client, worker_url: String, rid: String) {
    tokio::spawn(async move {
        let url = format!("{}/abort_request", worker_url.trim_end_matches('/'));
        match http
            .post(&url)
            .timeout(Duration::from_secs(5))
            .json(&serde_json::json!({ "rid": rid }))
            .send()
            .await
        {
            Ok(resp) if !resp.status().is_success() => {
                tracing::warn!("PD abort {url} rid={rid} returned {}", resp.status());
            }
            Ok(_) => tracing::info!("PD abort {url} rid={rid}"),
            Err(e) => tracing::warn!("PD abort {url} rid={rid} failed: {e}"),
        }
    });
}

fn abort_sglang_request_nats(nats: Arc<NatsRequestClient>, worker_id: String, rid: String) {
    tokio::spawn(async move {
        let mut body = Map::new();
        body.insert("rid".into(), Value::from(rid.clone()));
        let payload = leg_payload("/abort_request", false, None, body);
        match nats.dispatch(&worker_id, &payload).await {
            Ok(mut reply) => {
                while let Some(frame) = reply.next().await {
                    match frame {
                        Frame::Done { status } if !(200..400).contains(&status) => {
                            tracing::warn!(
                                "PD abort over NATS worker={worker_id} rid={rid} returned {status}"
                            );
                            return;
                        }
                        Frame::Done { .. } => {
                            tracing::info!("PD abort over NATS worker={worker_id} rid={rid}");
                            return;
                        }
                        Frame::Error { message, .. } => {
                            tracing::warn!(
                                "PD abort over NATS worker={worker_id} rid={rid} failed: {message}"
                            );
                            return;
                        }
                        Frame::Data(_) => {}
                    }
                }
            }
            Err(error) => {
                tracing::warn!("PD abort over NATS worker={worker_id} rid={rid} failed: {error}");
            }
        }
    });
}

/// How a unary NATS decode reply ends for the prefill watcher. A 5xx decode
/// never consumed the KV it was sent, so the prefill leg is left holding the
/// bootstrap room: that pair has to be aborted, not drained.
fn unary_nats_end(status: u16) -> StreamEnd {
    if status >= 500 {
        StreamEnd::Incomplete
    } else {
        StreamEnd::Complete
    }
}

/// Validate the terminal status of a committed NATS decode stream.
fn nats_stream_end(status: Option<u16>) -> std::io::Result<()> {
    match status {
        Some(status) if status < 500 => Ok(()),
        Some(status) => Err(std::io::Error::other(format!(
            "decode NATS stream ended with status {status}"
        ))),
        None => Err(std::io::Error::other(
            "decode NATS stream ended without a done frame",
        )),
    }
}

/// Reports an incomplete stream on drop until ownership is handed off.
struct FireOnDrop(Option<oneshot::Sender<StreamEnd>>);

impl FireOnDrop {
    fn settle(&mut self, end: StreamEnd) {
        if let Some(tx) = self.0.take() {
            let _ = tx.send(end);
        }
    }

    fn take(&mut self) -> Option<oneshot::Sender<StreamEnd>> {
        self.0.take()
    }
}

impl Drop for FireOnDrop {
    fn drop(&mut self) {
        if let Some(tx) = self.0.take() {
            let _ = tx.send(StreamEnd::Incomplete);
        }
    }
}

/// Aborts an engine pair when the request future is dropped before both legs
/// were answered, which is what a client disconnect looks like on the unary
/// path: nothing ever reads the responses, so nothing else would notice.
struct AbortPairOnDrop {
    transport: Option<AbortTransport>,
    rid: String,
    n: usize,
}

impl AbortPairOnDrop {
    fn arm(transport: AbortTransport, rid: String, n: usize) -> Self {
        AbortPairOnDrop {
            transport: Some(transport),
            rid,
            n,
        }
    }

    /// Hand the pair back: the caller reached a point where it owns the abort.
    fn disarm(&mut self) {
        self.transport = None;
    }
}

impl Drop for AbortPairOnDrop {
    fn drop(&mut self) {
        let Some(transport) = self.transport.take() else {
            return;
        };
        // Without a request id the protocol has nothing to abort with.
        if self.rid.is_empty() {
            return;
        }
        tracing::warn!("PD unary request dropped; aborting rid={}", self.rid);
        abort_sglang_pair(transport, &self.rid, self.n);
    }
}

/// POST the decode leg, retrying on pre-flight transport errors (the engine
/// hasn't seen the body yet, so re-sending the same bootstrap_room is safe).
async fn open_decode(
    state: &AppState,
    d: &RouteTarget,
    url: &str,
    body: &Map<String, Value>,
) -> Result<reqwest::Response, String> {
    let mut backoff = Duration::from_millis(50);
    for attempt in 0..=DECODE_OPEN_RETRIES {
        match post_leg(state, url, body.clone(), dp::header_rank(d)).await {
            Ok(resp) => {
                let st = resp.status();
                if st.is_client_error() || st.is_server_error() {
                    if is_worker_fault(st.as_u16()) {
                        state.breaker.record_failure(&d.worker.worker_id);
                    } else {
                        state.breaker.record_neutral(&d.worker.worker_id);
                    }
                    let txt = resp.text().await.unwrap_or_default();
                    return Err(format!(
                        "decode {} error {}: {}",
                        d.worker.worker_id,
                        st.as_u16(),
                        truncate_chars(&txt, 300)
                    ));
                }
                state.breaker.record_success(&d.worker.worker_id);
                return Ok(resp);
            }
            Err(e) if attempt < DECODE_OPEN_RETRIES && e.is_connect() => {
                tracing::info!(
                    "decode open retry {}/{DECODE_OPEN_RETRIES} for {url}: {e}",
                    attempt + 1
                );
                tokio::time::sleep(backoff).await;
                backoff = (backoff * 2).min(Duration::from_millis(500));
            }
            Err(e) => {
                // Exhausted the in-request retries: this worker is not merely
                // slow to accept a connection.
                state.breaker.record_failure(&d.worker.worker_id);
                return Err(format!("decode {} unreachable: {e}", d.worker.worker_id));
            }
        }
    }
    unreachable!("loop returns on the final attempt")
}

fn post_leg(
    state: &AppState,
    url: &str,
    body: Map<String, Value>,
    dp_rank: Option<i64>,
) -> impl std::future::Future<Output = reqwest::Result<reqwest::Response>> {
    // `.json()` sets content-type: application/json itself.
    let mut req = state.http.post(url).json(&Value::Object(body));
    if let Some(r) = dp_rank {
        req = req.header(dp::DP_RANK_HEADER, r.to_string());
    }
    req.send()
}

fn content_type(resp: &reqwest::Response) -> String {
    resp.headers()
        .get(header::CONTENT_TYPE)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("application/json")
        .to_string()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::breaker::CircuitBreaker;
    use futures::StreamExt;

    fn breaker() -> Arc<CircuitBreaker> {
        Arc::new(CircuitBreaker::default())
    }

    #[test]
    fn a_leg_that_failed_is_not_scored_as_healthy() {
        // The NATS `done` frame carries the engine's status, so 500 has to be
        // read out of it. Taking the frame's arrival as success is the trap:
        // the prefill leg's reply is discarded, so nothing else would notice a
        // worker that fails every request while decode hangs on KVPoll.
        let b = breaker();
        for _ in 0..3 {
            score_leg(&b, "p1", 500);
        }
        assert_eq!(b.state_of("p1").as_str(), "open");
    }

    #[test]
    fn a_4xx_leg_does_not_accumulate_towards_tripping() {
        // The request is bad, and every worker would answer the same.
        let b = breaker();
        for _ in 0..5 {
            score_leg(&b, "p1", 400);
        }
        assert_eq!(b.state_of("p1").as_str(), "closed");
    }

    #[test]
    fn a_successful_leg_clears_the_failure_count() {
        let b = breaker();
        score_leg(&b, "p1", 500);
        score_leg(&b, "p1", 500);
        score_leg(&b, "p1", 200);
        score_leg(&b, "p1", 500);
        assert_eq!(
            b.state_of("p1").as_str(),
            "closed",
            "three failures have to be consecutive, or the count only ever climbs"
        );
    }

    #[test]
    fn the_legs_are_scored_independently() {
        // A decode that answers cannot vouch for a prefill that did not.
        let b = breaker();
        for _ in 0..3 {
            score_leg(&b, "p1", 500);
            score_leg(&b, "d1", 200);
        }
        assert_eq!(b.state_of("p1").as_str(), "open");
        assert_eq!(b.state_of("d1").as_str(), "closed");
    }

    #[tokio::test]
    async fn fire_on_drop_can_transfer_abort_ownership() {
        let (tx, rx) = oneshot::channel();
        drop(FireOnDrop(Some(tx)));
        assert_eq!(
            rx.await.unwrap(),
            StreamEnd::Incomplete,
            "dropping the guard must signal abort"
        );

        let (tx, mut rx) = oneshot::channel();
        let transferred = {
            let mut guard = FireOnDrop(Some(tx));
            guard.take()
        };

        assert!(rx.try_recv().is_err(), "handoff must not signal abort");
        drop(transferred);
        assert!(
            rx.await.is_err(),
            "dropping the transferred sender closes the channel"
        );
    }

    #[tokio::test]
    async fn fire_on_drop_settles_with_the_reported_end() {
        let (tx, rx) = oneshot::channel();
        let mut guard = FireOnDrop(Some(tx));
        guard.settle(StreamEnd::Incomplete);
        drop(guard);
        assert_eq!(rx.await.unwrap(), StreamEnd::Incomplete);
    }

    #[tokio::test]
    async fn a_failed_unary_nats_decode_cancels_the_prefill_drain() {
        use std::sync::atomic::{AtomicBool, Ordering};

        // A drain that is still running when the decode leg fails: reporting
        // completion would leave it waiting out the whole drain timeout on a
        // pair nobody is going to finish.
        let drained = Arc::new(AtomicBool::new(false));
        let drained_by_task = drained.clone();
        let drain = tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(40)).await;
            drained_by_task.store(true, Ordering::SeqCst);
        });
        let (tx, rx) = oneshot::channel();
        watch_prefill_after_decode(
            rx,
            drain,
            Duration::from_secs(300),
            AbortTransport::Http {
                http: reqwest::Client::new(),
                prefill_url: "http://prefill.invalid".into(),
                decode_url: "http://decode.invalid".into(),
            },
            "infera-1".into(),
            1,
        );

        FireOnDrop(Some(tx)).settle(unary_nats_end(500));
        tokio::time::sleep(Duration::from_millis(80)).await;
        assert!(
            !drained.load(Ordering::SeqCst),
            "a 5xx decode must abort the pair instead of draining prefill"
        );
    }

    #[test]
    fn a_failed_unary_nats_decode_does_not_complete_the_pair() {
        // The `done` frame carries the engine's status, so a 500 arrives on the
        // same frame a success does. Reading the frame as completion lets the
        // prefill leg drain against a decode that never took the KV.
        assert_eq!(unary_nats_end(500), StreamEnd::Incomplete);
        assert_eq!(unary_nats_end(503), StreamEnd::Incomplete);
        assert_eq!(unary_nats_end(200), StreamEnd::Complete);
        assert_eq!(unary_nats_end(400), StreamEnd::Complete);
    }

    #[test]
    fn a_streaming_nats_decode_requires_a_successful_done_frame() {
        assert!(nats_stream_end(Some(200)).is_ok());
        assert!(nats_stream_end(Some(499)).is_ok());
        assert!(nats_stream_end(Some(500)).is_err());
        assert!(nats_stream_end(None).is_err());
    }

    #[test]
    fn parallel_sampling_expands_abort_request_ids() {
        assert_eq!(abort_request_ids("infera-7", 1), vec!["infera-7"]);
        assert_eq!(
            abort_request_ids("infera-7", 3),
            vec!["infera-7_0", "infera-7_1", "infera-7_2"]
        );
    }

    #[tokio::test]
    async fn incomplete_protocol_without_rid_aborts_prefill_drain() {
        use std::sync::atomic::{AtomicBool, Ordering};

        let completed = Arc::new(AtomicBool::new(false));
        let completed_by_task = completed.clone();
        let drain = tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(20)).await;
            completed_by_task.store(true, Ordering::SeqCst);
        });
        let (tx, rx) = oneshot::channel();
        watch_prefill_after_decode(
            rx,
            drain,
            Duration::from_millis(1),
            AbortTransport::Http {
                http: reqwest::Client::new(),
                prefill_url: "http://prefill".into(),
                decode_url: "http://decode".into(),
            },
            String::new(),
            1,
        );

        tx.send(StreamEnd::Incomplete).unwrap();
        tokio::time::sleep(Duration::from_millis(40)).await;
        assert!(
            !completed.load(Ordering::SeqCst),
            "an incomplete decode must cancel the prefill HTTP drain without an abort id"
        );
    }

    #[tokio::test]
    async fn completed_protocol_without_rid_aborts_timed_out_prefill_drain() {
        use std::sync::atomic::{AtomicBool, Ordering};

        let completed = Arc::new(AtomicBool::new(false));
        let completed_by_task = completed.clone();
        let drain = tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(20)).await;
            completed_by_task.store(true, Ordering::SeqCst);
        });
        let (tx, rx) = oneshot::channel();
        watch_prefill_after_decode(
            rx,
            drain,
            Duration::from_millis(1),
            AbortTransport::Http {
                http: reqwest::Client::new(),
                prefill_url: "http://prefill".into(),
                decode_url: "http://decode".into(),
            },
            String::new(),
            1,
        );

        tx.send(StreamEnd::Complete).unwrap();
        tokio::time::sleep(Duration::from_millis(40)).await;
        assert!(
            !completed.load(Ordering::SeqCst),
            "a timed-out prefill drain must close without an abort id"
        );
    }

    #[tokio::test]
    async fn closed_decode_signal_aborts_prefill_drain() {
        use std::sync::atomic::{AtomicBool, Ordering};

        let completed = Arc::new(AtomicBool::new(false));
        let completed_by_task = completed.clone();
        let drain = tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(20)).await;
            completed_by_task.store(true, Ordering::SeqCst);
        });
        let (tx, rx) = oneshot::channel();
        watch_prefill_after_decode(
            rx,
            drain,
            Duration::from_millis(1),
            AbortTransport::Http {
                http: reqwest::Client::new(),
                prefill_url: "http://prefill".into(),
                decode_url: "http://decode".into(),
            },
            String::new(),
            1,
        );

        drop(tx);
        tokio::time::sleep(Duration::from_millis(40)).await;
        assert!(
            !completed.load(Ordering::SeqCst),
            "a closed decode signal must cancel the prefill HTTP drain"
        );
    }
    fn demand_state(
        workers: Vec<Arc<crate::pool::Worker>>,
    ) -> (AppState, Arc<crate::policy::KvEventAwarePolicy>) {
        use crate::{
            block_hasher::BlockHasher, decode_demand::Mode, kv_event::KvEventClient,
            policy::KvEventAwarePolicy,
        };
        let policy = Arc::new(
            KvEventAwarePolicy::new(
                Arc::new(KvEventClient::nats_fed()),
                BlockHasher::disabled(),
                20.0,
                None,
                None,
            )
            .with_decode_input_demand(Mode::On),
        );
        let state = AppState {
            pool: Arc::new(arc_swap::ArcSwap::from_pointee(Snapshot::build(workers))),
            policy: policy.clone(),
            http: crate::proxy::build_upstream_client(0.0).unwrap(),
            started: std::time::Instant::now(),
            retries: 0,
            breaker: breaker(),
            nats: None,
            pd_prefill_drain_timeout: Duration::from_secs(1),
            pd_prefill_guard_release: crate::config::PrefillGuardRelease::Decode,
            sessions: Arc::new(crate::session_affinity::Sessions::default()),
            stream_stall_warn: crate::proxy::StallWarn {
                before_first_byte: Duration::from_secs(10),
                mid_stream: Duration::from_secs(10),
            },
        };
        (state, policy)
    }

    fn demand_worker(id: &str, url: &str, role: &str, transport: &str) -> Arc<crate::pool::Worker> {
        Arc::new(serde_json::from_value(serde_json::json!({
            "worker_id":id, "url":url, "model_name":"m", "disagg_mode":role,
            "request_transport":transport,
            "disagg_meta":{"protocol":"sglang-bootstrap", "params":{"bootstrap_addr":"127.0.0.1:9000"}}
        })).unwrap())
    }

    async fn demand_dispatch(state: &AppState, stream: bool) -> Response {
        let request = serde_json::json!({"model":"m", "prompt":vec![7;128], "stream":stream});
        dispatch(
            state,
            &state.pool.load(),
            "m",
            &request,
            Bytes::from(serde_json::to_vec(&request).unwrap()),
            stream,
            "/v1/completions",
            None,
        )
        .await
    }

    async fn demand_mock(
        status: StatusCode,
        hold_headers: bool,
        stream: bool,
        fail_body: bool,
    ) -> (
        String,
        Arc<tokio::sync::Notify>,
        Arc<tokio::sync::Notify>,
        tokio::task::JoinHandle<()>,
    ) {
        use axum::{routing::post, Router};
        let arrived = Arc::new(tokio::sync::Notify::new());
        let release = Arc::new(tokio::sync::Notify::new());
        let (a, r) = (arrived.clone(), release.clone());
        let router = Router::new()
            .route(
                "/v1/completions",
                post(move || {
                    let (arrived, release) = (a.clone(), r.clone());
                    async move {
                        arrived.notify_one();
                        if hold_headers {
                            release.notified().await;
                        }
                        let body = if stream {
                            let first = futures::stream::once(async {
                                Ok::<_, std::io::Error>(Bytes::from_static(
                                    b"data: {\"choices\":[]}\n\n",
                                ))
                            });
                            let tail = futures::stream::once(async move {
                                release.notified().await;
                                if fail_body {
                                    Err(std::io::Error::other("upstream body failed"))
                                } else {
                                    Ok(Bytes::from_static(b"data: [DONE]\n\n"))
                                }
                            });
                            Body::from_stream(first.chain(tail))
                        } else {
                            Body::from("{}")
                        };
                        Response::builder().status(status).body(body).unwrap()
                    }
                }),
            )
            .route("/abort_request", post(|| async { StatusCode::OK }));
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let url = format!("http://{}", listener.local_addr().unwrap());
        let server = tokio::spawn(async move {
            axum::serve(listener, router).await.unwrap();
        });
        (url, arrived, release, server)
    }

    #[tokio::test]
    async fn decode_demand_http_unary_waits_for_prefill_and_releases_on_completion() {
        let (p_url, p_arrived, p_release, ps) =
            demand_mock(StatusCode::OK, true, false, false).await;
        let (d_url, d_arrived, d_release, ds) =
            demand_mock(StatusCode::OK, true, false, false).await;
        let (state, policy) = demand_state(vec![
            demand_worker("p", &p_url, "prefill", "http"),
            demand_worker("d", &d_url, "decode", "http"),
        ]);
        let task = tokio::spawn(async move { demand_dispatch(&state, false).await });
        tokio::time::timeout(Duration::from_secs(3), async {
            p_arrived.notified().await;
            d_arrived.notified().await;
        })
        .await
        .unwrap();
        assert_eq!(policy.demand_snapshot()["d"].tokens, 128);
        d_release.notify_one();
        assert!(!task.is_finished());
        assert_eq!(policy.demand_snapshot()["d"].tokens, 128);
        p_release.notify_one();
        assert_eq!(task.await.unwrap().status(), StatusCode::OK);
        assert!(policy.demand_snapshot().is_empty());
        ps.abort();
        ds.abort();
    }

    #[tokio::test]
    async fn decode_demand_http_stream_owns_charge_until_eof_error_or_drop() {
        for end in ["done", "error", "cancel"] {
            let (p_url, _, _, ps) = demand_mock(StatusCode::OK, false, false, false).await;
            let (d_url, _, release, ds) =
                demand_mock(StatusCode::OK, false, true, end == "error").await;
            let (state, policy) = demand_state(vec![
                demand_worker("p", &p_url, "prefill", "http"),
                demand_worker("d", &d_url, "decode", "http"),
            ]);
            let response = demand_dispatch(&state, true).await;
            assert_eq!(response.status(), StatusCode::OK);
            let mut body = response.into_body().into_data_stream();
            body.next().await.unwrap().unwrap();
            assert_eq!(policy.demand_snapshot()["d"].tokens, 128);
            if end == "cancel" {
                drop(body);
            } else {
                release.notify_one();
                let mut failed = false;
                while let Some(chunk) = body.next().await {
                    failed |= chunk.is_err();
                }
                assert_eq!(failed, end == "error");
                drop(body);
            }
            assert!(policy.demand_snapshot().is_empty(), "{end}");
            ps.abort();
            ds.abort();
        }
    }

    #[tokio::test]
    async fn decode_demand_http_early_errors_and_unary_cancel_release_charge() {
        let (p_url, _, _, ps) = demand_mock(StatusCode::OK, false, false, false).await;
        let (d_url, _, _, ds) =
            demand_mock(StatusCode::INTERNAL_SERVER_ERROR, false, false, false).await;
        for stream in [false, true] {
            let (state, policy) = demand_state(vec![
                demand_worker("p", &p_url, "prefill", "http"),
                demand_worker("d", &d_url, "decode", "http"),
            ]);
            let response = demand_dispatch(&state, stream).await;
            assert!(!response.status().is_success());
            assert!(policy.demand_snapshot().is_empty());
        }
        let (state, policy) = demand_state(vec![
            demand_worker("p", &p_url, "prefill", "http"),
            demand_worker("d", &d_url, "decode", "nats"),
        ]);
        assert_eq!(
            demand_dispatch(&state, false).await.status(),
            StatusCode::SERVICE_UNAVAILABLE
        );
        assert!(policy.demand_snapshot().is_empty());
        ds.abort();
        let (d_url, arrived, _, ds) = demand_mock(StatusCode::OK, true, false, false).await;
        let (state, policy) = demand_state(vec![
            demand_worker("p", &p_url, "prefill", "http"),
            demand_worker("d", &d_url, "decode", "http"),
        ]);
        let task = tokio::spawn(async move { demand_dispatch(&state, false).await });
        tokio::time::timeout(Duration::from_secs(3), arrived.notified())
            .await
            .unwrap();
        assert_eq!(policy.demand_snapshot()["d"].tokens, 128);
        task.abort();
        let _ = task.await;
        assert!(policy.demand_snapshot().is_empty());
        ps.abort();
        ds.abort();
    }

    #[tokio::test]
    #[ignore = "requires INFERA_TEST_NATS"]
    async fn decode_demand_nats_releases_on_terminal_error_and_cancellation() {
        use crate::nats_request::{
            request_subject, NatsRequestClient, HDR_STATUS, HDR_TYPE, TYPE_DONE,
        };
        let url = std::env::var("INFERA_TEST_NATS").expect("set INFERA_TEST_NATS");
        let nc = async_nats::connect(&url).await.unwrap();
        for stream in [false, true] {
            for end in ["done", "error", "cancel"] {
                let p_id = format!("r2-p-{}-{stream}-{end}", std::process::id());
                let d_id = format!("r2-d-{}-{stream}-{end}", std::process::id());
                let mut p_sub = nc.subscribe(request_subject(&p_id)).await.unwrap();
                let mut d_sub = nc.subscribe(request_subject(&d_id)).await.unwrap();
                nc.flush().await.unwrap();
                let p_nc = nc.clone();
                let p_task = tokio::spawn(async move {
                    let msg = p_sub.next().await.unwrap();
                    let mut headers = async_nats::HeaderMap::new();
                    headers.insert(HDR_TYPE, TYPE_DONE);
                    headers.insert(HDR_STATUS, "200");
                    p_nc.publish_with_headers(msg.reply.unwrap(), headers, Bytes::new())
                        .await
                        .unwrap();
                    p_nc.flush().await.unwrap();
                });
                let (ready_tx, ready_rx) = oneshot::channel();
                let (release_tx, release_rx) = oneshot::channel();
                let d_nc = nc.clone();
                let d_task = tokio::spawn(async move {
                    let msg = d_sub.next().await.unwrap();
                    ready_tx.send(()).unwrap();
                    if release_rx.await.is_err() {
                        return;
                    }
                    let mut headers = async_nats::HeaderMap::new();
                    headers.insert(HDR_TYPE, TYPE_DONE);
                    headers.insert(HDR_STATUS, if end == "error" { "500" } else { "200" });
                    d_nc.publish_with_headers(msg.reply.unwrap(), headers, Bytes::new())
                        .await
                        .unwrap();
                    d_nc.flush().await.unwrap();
                });
                let (mut state, policy) = demand_state(vec![
                    demand_worker(&p_id, "http://unused", "prefill", "nats"),
                    demand_worker(&d_id, "http://unused", "decode", "nats"),
                ]);
                state.nats = Some(Arc::new(
                    NatsRequestClient::connect(Some(&url), 10.0, 0.0, 0)
                        .await
                        .unwrap(),
                ));
                let task = tokio::spawn(async move { demand_dispatch(&state, stream).await });
                tokio::time::timeout(Duration::from_secs(3), ready_rx)
                    .await
                    .unwrap()
                    .unwrap();
                assert_eq!(policy.demand_snapshot()[&d_id].tokens, 128);
                if end == "cancel" {
                    if stream {
                        drop(task.await.unwrap());
                    } else {
                        task.abort();
                        let _ = task.await;
                    }
                    drop(release_tx);
                } else {
                    release_tx.send(()).unwrap();
                    let response = task.await.unwrap();
                    assert_eq!(
                        response.status().as_u16(),
                        if !stream && end == "error" { 500 } else { 200 }
                    );
                    let body = axum::body::to_bytes(response.into_body(), usize::MAX).await;
                    assert_eq!(body.is_err(), stream && end == "error");
                }
                assert!(policy.demand_snapshot().is_empty(), "{stream} {end}");
                tokio::time::timeout(Duration::from_secs(3), p_task)
                    .await
                    .unwrap()
                    .unwrap();
                tokio::time::timeout(Duration::from_secs(3), d_task)
                    .await
                    .unwrap()
                    .unwrap();
            }
        }
    }
}

#[cfg(test)]
#[path = "prefill_guard_tests.rs"]
mod guard_tests;
