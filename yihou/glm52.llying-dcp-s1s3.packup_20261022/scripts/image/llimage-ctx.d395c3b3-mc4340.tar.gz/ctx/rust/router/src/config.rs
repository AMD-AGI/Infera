///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2026, Advanced Micro Devices, Inc. All rights reserved.
//
// SPDX-License-Identifier: MIT
///////////////////////////////////////////////////////////////////////////////
//! CLI / env configuration. Flag names mirror `infera.server.args` so the
//! Python `--router-backend rust` shim can translate 1:1.

use clap::{Parser, ValueEnum};

use crate::session_affinity::Mode as SessionAffinityMode;

#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
pub enum PrefillGuardRelease {
    Decode,
    Completion,
}

#[derive(Debug, Clone, Parser)]
#[command(name = "infera-router", about = "Infera router data plane (Rust)")]
pub struct Config {
    #[arg(long, default_value = "0.0.0.0")]
    pub host: String,

    #[arg(long, default_value_t = 8000)]
    pub port: u16,

    #[arg(long, default_value = "127.0.0.1:2379")]
    pub etcd_endpoint: String,

    #[arg(long, default_value = "/infera/workers/")]
    pub etcd_prefix: String,

    /// Failover attempts to alternate workers on a pre-first-byte failure.
    #[arg(long, default_value_t = 1)]
    pub request_max_retries: usize,

    /// Consecutive pre-first-byte worker faults before a worker is taken out
    /// of rotation. Failover alone forgets between requests; this remembers.
    #[arg(long, default_value_t = 3)]
    pub breaker_failure_threshold: u32,

    /// Seconds a tripped worker is excluded before one probe is admitted.
    #[arg(long, default_value_t = 5.0)]
    pub breaker_cooldown_s: f64,

    /// Ceiling for the cooldown, which doubles on each failed probe.
    #[arg(long, default_value_t = 60.0)]
    pub breaker_max_cooldown_s: f64,

    /// `round-robin` or `kv-aware` (DP-attention cache-locality routing).
    #[arg(long, default_value = "round-robin")]
    pub router_policy: String,

    /// Release PD prefill load when its response completes, or retain it with decode.
    #[arg(
        long,
        env = "INFERA_PD_PREFILL_GUARD_RELEASE",
        value_enum,
        default_value = "decode"
    )]
    pub pd_prefill_guard_release: PrefillGuardRelease,

    /// Keep each `X-Session-ID` session on its last target: `prefill`
    /// pins prefill picks only, `both` also decode and aggregated picks.
    #[arg(long, value_enum, default_value = "off")]
    pub session_affinity: SessionAffinityMode,

    /// Idle seconds before a session binding is dropped.
    #[arg(long, default_value_t = 3600, value_parser = clap::value_parser!(u64).range(1..=86400))]
    pub session_affinity_ttl_seconds: u64,

    /// Decode input-token demand routing (kv-aware only); off, shadow or on.
    #[arg(
        long,
        value_enum,
        default_value = "off",
        env = "INFERA_DECODE_INPUT_DEMAND"
    )]
    pub decode_input_demand: crate::decode_demand::Mode,

    /// `etcd` (external) or `kubernetes` (workers publish into their own Pod
    /// annotation and the API server is watched).
    #[arg(long, default_value = "etcd")]
    pub discovery_backend: String,

    /// kubernetes discovery: label selector identifying the fleet's worker
    /// Pods. Required for that backend -- an empty selector would match every
    /// Pod in the namespace.
    #[arg(long, env = "INFERA_K8S_LABEL_SELECTOR")]
    pub k8s_label_selector: Option<String>,

    /// kubernetes discovery: namespace to watch. Defaults to the Pod's own.
    #[arg(long)]
    pub k8s_namespace: Option<String>,

    /// `nats` (publish onto the worker's own subject and stream the reply back
    /// over an inbox) or `http` (dial the worker directly).
    ///
    /// Defaults to `nats` because the Python backend does. This binary is a
    /// drop-in for it, and the launcher forwards whatever Python resolved --
    /// so a different default here would mean the same deployment behaved one
    /// way through `python -m infera.server --router-backend rust` and another
    /// way run directly.
    #[arg(long, default_value = "nats")]
    pub request_transport: String,

    /// NATS broker URL. Falls back to `NATS_SERVER`, then to localhost. Used by
    /// both the request transport and the kv-event feed.
    #[arg(long, env = "NATS_SERVER")]
    pub nats_server: Option<String>,

    /// Where kv-aware routing gets its cache events: `nats` (one subscription
    /// for the fleet) or `zmq` (a socket per worker). Ignored unless
    /// `--router-policy kv-aware`. Defaults to `nats`, as the Python backend
    /// does.
    #[arg(long, default_value = "nats")]
    pub kv_event_transport: String,

    /// Seconds to wait for the *next* reply chunk before giving up on a
    /// request. Reset on every chunk, so a long generation that keeps producing
    /// tokens never trips it -- only a stall does. Expiry is a 504, which
    /// scores the worker. 0 disables it.
    ///
    /// Kept on, unlike the HTTP half below, because this transport has no
    /// connection to lose: a worker that dies mid-stream simply stops
    /// publishing, and the router would wait on a reply nobody will ever send.
    /// An HTTP peer in the same state resets the socket, which surfaces as a
    /// read error. The default is long enough to be a backstop rather than a
    /// policy -- reporting a stall is `--stream-stall-warn-s`'s job.
    #[arg(long, default_value_t = 900.0, env = "INFERA_NATS_REQ_IDLE_TIMEOUT")]
    pub nats_req_idle_timeout_s: f64,

    /// Hard cap on a whole request's wall clock regardless of token flow, for
    /// runaway generations. 0 (the default) disables it.
    #[arg(long, default_value_t = 0.0, env = "INFERA_NATS_REQ_MAX_DURATION")]
    pub nats_req_max_duration_s: f64,

    /// Refuse to dispatch to a worker whose in-NATS backlog has reached this
    /// many messages, answering 429. Turning it on makes the request path
    /// JetStream-backed, which is what makes the backlog measurable. 0 (the
    /// default) keeps the transport pure core NATS.
    #[arg(long, default_value_t = 0, env = "INFERA_NATS_REQ_MAX_PENDING")]
    pub nats_req_max_pending: usize,

    /// Seconds a stream may go without its *first* byte before the router
    /// reports it, with the worker and request id. 0 disables the reporting.
    ///
    /// This window is admission -- queueing, prefill, and the KV transfer --
    /// which a saturated decode queue has been measured holding for 200s at the
    /// 99th percentile, so the default sits above that rather than reporting
    /// every queued request as a fault.
    #[arg(long, default_value_t = 240.0, env = "INFERA_STREAM_ADMISSION_WARN")]
    pub stream_admission_warn_s: f64,

    /// Seconds a stream that has already produced bytes may go silent before
    /// the router reports it. 0 disables the reporting.
    ///
    /// Much shorter than the admission window above: a generation under way
    /// emits tokens tens of milliseconds apart, so this silence is a fault
    /// rather than a queue.
    ///
    /// Reporting only, on both windows: the stream keeps waiting, because
    /// ending it early would fail requests that were still going to answer,
    /// and a caller that does give up disconnects -- which already reclaims
    /// the slot without the router deciding for it.
    #[arg(long, default_value_t = 60.0, env = "INFERA_STREAM_STALL_WARN")]
    pub stream_stall_warn_s: f64,

    /// Seconds to wait for the *next* body chunk from a worker over HTTP before
    /// failing the stream. Reset on every chunk. 0 (the default) disables it,
    /// leaving `--stream-stall-warn-s` to report a stall without ending a
    /// request the caller has not given up on. Set it only where a caller with
    /// no timeout of its own would otherwise hold a stream open indefinitely.
    #[arg(long, default_value_t = 0.0, env = "INFERA_HTTP_REQ_IDLE_TIMEOUT")]
    pub http_req_idle_timeout_s: f64,

    /// Seconds to wait for a detached PD prefill POST before aborting it.
    /// Matches the Mooncake KVPoll window. 0 disables the wall-clock cap;
    /// client-disconnect abort still runs.
    #[arg(long, default_value_t = 300.0, env = "INFERA_PD_PREFILL_DRAIN_TIMEOUT")]
    pub pd_prefill_drain_timeout_s: f64,

    /// kv-aware only: path to the model's HF fast tokenizer (`tokenizer.json` or
    /// its dir). Required for cache locality — without it kv-aware degrades to
    /// pure load balancing (block hashes can't be computed).
    #[arg(long)]
    pub kv_tokenizer_path: Option<String>,

    /// kv-aware: the engine's `--default-chat-template-kwargs`, as JSON.
    ///
    /// The one input to the engine's render the router is never told about: the
    /// client does not send it, discovery does not carry it, and it is merged
    /// before the template runs. Set it here to whatever the workers were
    /// launched with and the router renders the same preamble they do.
    ///
    /// This is a config that can drift from the fleet, which is the very class
    /// of bug it fixes -- so do not trust it, check it. The startup render
    /// probe reports `infera_router_render_parity{worker_id,model}` = 0 when
    /// this is set wrong, and the router also reads each worker's real value
    /// from `/get_server_info` and prefers that over this flag (see
    /// `--kv-per-worker-template-kwargs`). This flag is the floor for workers
    /// that cannot be asked.
    #[arg(long, env = "INFERA_KV_DEFAULT_CHAT_TEMPLATE_KWARGS")]
    pub kv_default_chat_template_kwargs: Option<String>,

    /// kv-aware: read each worker's own `--default-chat-template-kwargs` from
    /// `/get_server_info` at registration, and hash requests for that worker
    /// the way that worker renders them.
    ///
    /// On by default, and additive: a worker that cannot be asked falls back to
    /// `--kv-default-chat-template-kwargs`, i.e. to today's behaviour. Turn it
    /// off to pin the whole fleet to the flag.
    #[arg(long, default_value_t = true, action = clap::ArgAction::Set)]
    pub kv_per_worker_template_kwargs: bool,

    /// kv-aware: base overlap weight in `cost = w*(blocks-hits) + active`.
    #[arg(long, default_value_t = 1.0)]
    pub kv_overlap_weight: f64,

    /// kv-aware: overlap weight for prefill workers (compute-bound; weight cache
    /// locality aggressively). Defaults to `kv_overlap_weight`.
    #[arg(long)]
    pub kv_prefill_overlap_weight: Option<f64>,

    /// kv-aware: overlap weight for decode workers (memory-bound; route by load).
    /// Defaults to `kv_overlap_weight`.
    #[arg(long)]
    pub kv_decode_overlap_weight: Option<f64>,
}

impl Config {
    pub fn parse_and_validate() -> anyhow::Result<Self> {
        let c = Config::parse();
        c.validate()?;
        Ok(c)
    }

    /// Reject config outside the Rust backend's supported set.
    pub fn validate(&self) -> anyhow::Result<()> {
        if self.router_policy != "round-robin" && self.router_policy != "kv-aware" {
            anyhow::bail!(
                "rust backend supports --router-policy round-robin|kv-aware (got {:?})",
                self.router_policy
            );
        }
        if let Some(raw) = &self.kv_default_chat_template_kwargs {
            match serde_json::from_str::<serde_json::Value>(raw) {
                Ok(v) if v.is_object() => {}
                Ok(_) => anyhow::bail!(
                    "--kv-default-chat-template-kwargs must be a JSON object (got {raw:?})"
                ),
                Err(e) => anyhow::bail!("--kv-default-chat-template-kwargs is not JSON: {e}"),
            }
        }
        if self.decode_input_demand != crate::decode_demand::Mode::Off
            && self.router_policy != "kv-aware"
        {
            anyhow::bail!("--decode-input-demand requires --router-policy kv-aware");
        }
        if self.router_policy == "kv-aware" && self.kv_tokenizer_path.is_none() {
            tracing::warn!(
                "--router-policy kv-aware without --kv-tokenizer-path: block hashes \
                 can't be computed, so routing degrades to pure load balancing"
            );
        }
        match self.discovery_backend.as_str() {
            "etcd" => {}
            "kubernetes" => {
                // Without a selector this would watch every Pod in the
                // namespace and register anything carrying the annotation.
                if self.k8s_label_selector.as_deref().unwrap_or("").is_empty() {
                    anyhow::bail!("--discovery-backend kubernetes requires --k8s-label-selector");
                }
            }
            other => anyhow::bail!(
                "rust backend supports --discovery-backend etcd|kubernetes (got {other:?})"
            ),
        }
        if self.request_transport != "http" && self.request_transport != "nats" {
            anyhow::bail!(
                "rust backend supports --request-transport http|nats (got {:?})",
                self.request_transport
            );
        }
        if self.kv_event_transport != "zmq" && self.kv_event_transport != "nats" {
            anyhow::bail!(
                "rust backend supports --kv-event-transport zmq|nats (got {:?})",
                self.kv_event_transport
            );
        }
        Ok(())
    }

    /// Normalize the etcd endpoint to a base URL for the v3 HTTP/JSON gateway.
    pub fn etcd_base(&self) -> String {
        let ep = &self.etcd_endpoint;
        if ep.starts_with("http://") || ep.starts_with("https://") {
            ep.trim_end_matches('/').to_string()
        } else if ep.contains(':') {
            format!("http://{ep}")
        } else {
            format!("http://{ep}:2379")
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn with_endpoint(ep: &str) -> Config {
        Config::try_parse_from(["infera-router", "--etcd-endpoint", ep]).unwrap()
    }

    /// The defaults have to be the Python backend's, because the launcher
    /// forwards whatever Python resolved and this binary is meant to be a
    /// drop-in. When these drifted apart, the same deployment ran over NATS
    /// through `python -m infera.server --router-backend rust` and over plain
    /// HTTP when the binary was run directly -- with nothing in either log
    /// saying which transport was in use.
    ///
    /// Values are from infera/server/args.py; changing one side means changing
    /// both.
    #[test]
    fn prefill_guard_release_is_explicit_and_validated() {
        let default = Config::try_parse_from(["infera-router"]).unwrap();
        assert_eq!(
            default.pd_prefill_guard_release,
            PrefillGuardRelease::Decode
        );
        let enabled =
            Config::try_parse_from(["infera-router", "--pd-prefill-guard-release", "completion"])
                .unwrap();
        assert_eq!(
            enabled.pd_prefill_guard_release,
            PrefillGuardRelease::Completion
        );
        assert!(
            Config::try_parse_from(["infera-router", "--pd-prefill-guard-release", "typo"])
                .is_err()
        );
    }

    #[test]
    fn session_affinity_flags_are_validated() {
        let default = Config::try_parse_from(["infera-router"]).unwrap();
        assert_eq!(default.session_affinity, SessionAffinityMode::Off);
        assert_eq!(default.session_affinity_ttl_seconds, 3600);
        let both = Config::try_parse_from([
            "infera-router",
            "--session-affinity",
            "both",
            "--session-affinity-ttl-seconds",
            "60",
        ])
        .unwrap();
        assert_eq!(both.session_affinity, SessionAffinityMode::Both);
        assert_eq!(both.session_affinity_ttl_seconds, 60);
        for bad in [
            ["--session-affinity", "Both"],
            ["--session-affinity-ttl-seconds", "0"],
            ["--session-affinity-ttl-seconds", "86401"],
        ] {
            assert!(Config::try_parse_from(["infera-router", bad[0], bad[1]]).is_err());
        }
    }

    #[test]
    fn transport_defaults_match_the_python_backend() {
        let c = Config::try_parse_from(["infera-router"]).unwrap();
        assert_eq!(c.request_transport, "nats");
        assert_eq!(c.kv_event_transport, "nats");
        assert_eq!(c.discovery_backend, "etcd");
        assert_eq!(c.router_policy, "round-robin");
    }

    /// A stall has to be reported inside the window a caller waits, or the only
    /// record of it is the caller's own timeout -- which is what made a stalled
    /// stream diagnosable solely from the client side.
    #[test]
    fn a_stall_is_reported_before_a_caller_gives_up() {
        const SDK_IDLE_TIMEOUT_S: f64 = 300.0;
        let c = Config::try_parse_from(["infera-router"]).unwrap();
        for (phase, warn) in [
            ("admission", c.stream_admission_warn_s),
            ("mid-stream", c.stream_stall_warn_s),
        ] {
            assert!(
                warn > 0.0 && warn < SDK_IDLE_TIMEOUT_S,
                "{phase} reporting is {warn}"
            );
        }
    }

    /// Admission covers a queue measured at 200s at the 99th percentile, so
    /// reporting it on the mid-stream window would call every queued request a
    /// fault. A generation under way emits tokens milliseconds apart.
    #[test]
    fn admission_is_given_a_longer_window_than_a_live_stream() {
        let c = Config::try_parse_from(["infera-router"]).unwrap();
        assert!(c.stream_admission_warn_s > 200.0);
        assert!(c.stream_stall_warn_s < c.stream_admission_warn_s);
    }

    /// Ending a stalled stream is the caller's call: it disconnects, which
    /// already reclaims the slot. Cutting first would fail requests still
    /// waiting on admission, which outlasts a saturated decode queue.
    ///
    /// NATS keeps a backstop because it has no connection to lose: a worker
    /// that dies mid-stream stops publishing and signals nothing, where an
    /// HTTP peer resets the socket. The backstop has to stay well clear of the
    /// windows a stall is reported on, or it becomes the policy again.
    #[test]
    fn only_the_transport_without_a_connection_ends_a_stalled_stream() {
        let c = Config::try_parse_from(["infera-router"]).unwrap();
        assert_eq!(c.http_req_idle_timeout_s, 0.0);
        assert!(c.nats_req_idle_timeout_s > c.stream_admission_warn_s * 2.0);
    }

    #[test]
    fn etcd_base_normalizes_forms() {
        assert_eq!(
            with_endpoint("127.0.0.1:2379").etcd_base(),
            "http://127.0.0.1:2379"
        );
        // bare host gets the default etcd port
        assert_eq!(
            with_endpoint("etcd-host").etcd_base(),
            "http://etcd-host:2379"
        );
        // explicit scheme is preserved, trailing slash trimmed
        assert_eq!(
            with_endpoint("https://etcd:2379/").etcd_base(),
            "https://etcd:2379"
        );
        assert_eq!(
            with_endpoint("http://etcd:2379").etcd_base(),
            "http://etcd:2379"
        );
    }

    #[test]
    fn validate_rejects_unsupported_subset() {
        // unknown policy is rejected
        let bad =
            Config::try_parse_from(["infera-router", "--router-policy", "least-load"]).unwrap();
        assert!(bad.validate().is_err());
        // round-robin (default) and kv-aware are both accepted
        let ok = Config::try_parse_from(["infera-router"]).unwrap();
        assert!(ok.validate().is_ok());
        let kva = Config::try_parse_from([
            "infera-router",
            "--router-policy",
            "kv-aware",
            "--kv-tokenizer-path",
            "/tmp/tok.json",
        ])
        .unwrap();
        assert!(kva.validate().is_ok());
        // the template-kwargs flag has to be a JSON object: a router that
        // renders with a half-parsed default is worse than one that will not
        // start, because it starts.
        for bad_kwargs in ["{\"reasoning_effort\": high}", "\"high\"", "[1]"] {
            let c = Config::try_parse_from([
                "infera-router",
                "--kv-default-chat-template-kwargs",
                bad_kwargs,
            ])
            .unwrap();
            assert!(c.validate().is_err(), "{bad_kwargs} should be rejected");
        }
        let good = Config::try_parse_from([
            "infera-router",
            "--kv-default-chat-template-kwargs",
            "{\"reasoning_effort\": \"high\"}",
        ])
        .unwrap();
        assert!(good.validate().is_ok());
        // unsupported discovery backend still rejected
        let bad_disc =
            Config::try_parse_from(["infera-router", "--discovery-backend", "k8s"]).unwrap();
        assert!(bad_disc.validate().is_err());
    }
    #[test]
    fn decode_demand_is_opt_in_and_requires_kv_aware() {
        let off = Config::try_parse_from(["router", "--decode-input-demand", "off"]).unwrap();
        assert!(off.validate().is_ok());
        for mode in ["shadow", "on"] {
            let invalid =
                Config::try_parse_from(["router", "--decode-input-demand", mode]).unwrap();
            assert!(invalid.validate().is_err());
            let valid = Config::try_parse_from([
                "router",
                "--router-policy",
                "kv-aware",
                "--decode-input-demand",
                mode,
            ])
            .unwrap();
            assert!(valid.validate().is_ok());
        }
        assert!(Config::try_parse_from(["router", "--decode-input-demand", "enabled"]).is_err());
    }
}
