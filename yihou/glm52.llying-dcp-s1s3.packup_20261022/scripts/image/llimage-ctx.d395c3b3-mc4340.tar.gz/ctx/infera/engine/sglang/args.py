###############################################################################
# Copyright (c) 2026, Advanced Micro Devices, Inc. All rights reserved.
#
# SPDX-License-Identifier: MIT
###############################################################################
from __future__ import annotations

import argparse
import logging
import os
from dataclasses import dataclass, field

from sglang.srt.server_args import ServerArgs

logger = logging.getLogger(__name__)

#: SGLang's opt-in for a radix prefix cache on a PD *decode* leg. Without it the
#: decode leg runs ``ChunkCache``, which keeps no radix tree -- and therefore
#: publishes no ``BlockStored`` chain and no ``AllBlocksCleared``.
_DECODE_RADIX_CACHE_FLAG = "--disaggregation-decode-enable-radix-cache"

#: Opt-in shared with the SGLang decode-radix-spec patch, which accepts
#: :data:`_DECODE_RADIX_CACHE_FLAG` under EAGLE/NEXTN with topk 1 when it is "1".
_DECODE_RADIX_SPEC_ENV = "SGLANG_EXPERIMENTAL_DECODE_RADIX_SPEC"


@dataclass(kw_only=True)
class SglangWorkerArgs:
    server_args: ServerArgs
    discovery_backend: str  # "etcd" | "kubernetes"
    etcd_endpoint: str | None
    etcd_prefix: str
    k8s_namespace: str | None
    request_transport: str  # "http" | "nats"
    # NATS request timeouts / admission (None => env $INFERA_NATS_REQ_* or the
    # built-in defaults in infera.common.nats_request).
    nats_req_idle_timeout: float | None = None
    nats_req_max_duration: float | None = None
    nats_req_max_pending: int | None = None
    drain_timeout: float = 30.0
    advertise_host: str | None
    # Benchmark-only escape hatch: skip the disagg transport preflight that
    # rejects configs prone to a silent TCP fallback. Default False.
    disaggregation_allow_tcp: bool
    # PR #10: SGLang-native KV event publisher for KvEventClient.
    enable_kv_events: bool
    # Original argv (everything we didn't consume) forwarded verbatim to the
    # `sglang.launch_server` subprocess. Re-parsing ServerArgs would lose
    # multi-value list flags (`--cuda-graph-bs 1 2 3 ...`) and other quirks.
    sglang_argv: list[str] = field(default_factory=list)

    # Phase 1: KvEventProbe + snapshot server. `auto` enables iff
    # tokenizer loads cleanly. `off` skips the whole worker-side KV
    # plane; the worker still registers but with `kv=None`.
    kv_events: str  # "on" | "off" | "auto"
    kv_events_bind: str  # tcp://0.0.0.0:<port> — what the publisher binds to
    kv_events_advertise: str | None  # what to register; default = derived from bind + host
    kv_snapshot_host: str  # bind for the snapshot HTTP server
    kv_snapshot_port: int  # bind for the snapshot HTTP server
    kv_snapshot_advertise: str | None  # base URL the server pulls from
    index_block_size: int

    # KV-event transport for KV-aware routing: "zmq" (router connects to
    # this worker's kv_events_endpoint directly) or "nats" (this worker
    # relays its engine events onto a NATS broker). Default "nats".
    kv_event_transport: str
    nats_server: str | None

    # Phase 4.5+: infera-kvd HiCacheStorage backend.
    # When set, register `infera-kvd` with SGLang's StorageBackendFactory
    # before launch_server, and (if not already set on server_args) inject
    # the SGLang flags that select our backend.
    infera_kvd_socket: str | None  # UDS path the kvd daemon listens on

    # PD prefill loads weights immediately, then waits for decode before
    # advertising the worker. None means default-on for prefill.
    wait_for_decode: bool | None
    decode_ready_timeout: float | None
    k8s_label_selector: str | None


def _rename_cuda_graph_max_bs(argv: list[str], parser: argparse.ArgumentParser) -> list[str]:
    """SGLang v0.5.22 split --cuda-graph-max-bs into --cuda-graph-max-bs-decode and
    --cuda-graph-max-bs-prefill; argparse then rejects the old spelling as an ambiguous
    prefix of both. It sized the decode graphs, so it maps onto the decode flag."""
    options = parser._option_string_actions
    if "--cuda-graph-max-bs" in options or "--cuda-graph-max-bs-decode" not in options:
        return argv
    renamed = []
    for token in argv:
        if token == "--cuda-graph-max-bs":
            token = "--cuda-graph-max-bs-decode"
        elif token.startswith("--cuda-graph-max-bs="):
            token = "--cuda-graph-max-bs-decode=" + token.split("=", 1)[1]
        renamed.append(token)
    return renamed


def parse_sglang_args(argv: list[str] | None = None) -> SglangWorkerArgs:
    parser = argparse.ArgumentParser(add_help=True)

    # Infera-specific args (not forwarded to SGLang).
    # Disagg role is read directly from SGLang's --disaggregation-mode.
    parser.add_argument(
        "--discovery-backend",
        choices=("etcd", "kubernetes"),
        default="kubernetes",
        help="Self-registration transport. 'kubernetes' (default) writes the "
        "worker record into this worker's own Pod annotation (no etcd; requires "
        "POD_NAME/POD_NAMESPACE downward API + RBAC to patch its own Pod). 'etcd' "
        "takes an etcd lease and PUTs the worker record (--etcd-endpoint).",
    )
    parser.add_argument(
        "--etcd-endpoint",
        default=None,
        help="Etcd endpoint (host:port, host, or http(s)://...) for "
        "lease-based self-registration. Required for --discovery-backend=etcd. "
        "All Infera servers watching the same --etcd-prefix see this worker.",
    )
    parser.add_argument(
        "--etcd-prefix",
        default="/infera/workers/",
        help="Etcd key prefix (default: /infera/workers/). Must be unique per "
        "deployment: the PD decode barrier lists this prefix with no extra "
        "selector, so a shared prefix can unblock prefill using another "
        "deployment's decode worker.",
    )
    parser.add_argument(
        "--k8s-namespace",
        default=None,
        help="Namespace of this worker's Pod for --discovery-backend=kubernetes "
        "(default: POD_NAMESPACE env / the Pod's mounted ServiceAccount namespace).",
    )
    parser.add_argument(
        "--k8s-label-selector",
        default=None,
        help="Label selector used by a PD prefill worker to find decode Pods "
        "(--wait-for-decode). Default: $INFERA_K8S_LABEL_SELECTOR, else this "
        "Pod's own infera.amd.com/deployment label, else that label with "
        "$WORKLOAD_ID. The barrier refuses to run unscoped.",
    )
    parser.add_argument(
        "--wait-for-decode",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="On --disaggregation-mode prefill, load weights immediately, skip "
        "SGLang's fake-bootstrap PD warmup, and wait until a matching decode "
        "worker has registered before advertising this worker. Default on for "
        "prefill; --no-wait-for-decode uses SGLang's own startup warmup.",
    )
    parser.add_argument(
        "--decode-ready-timeout",
        type=float,
        default=None,
        help="Seconds a PD prefill worker waits for a registered decode peer. "
        "Default $INFERA_DECODE_READY_TIMEOUT, else 14400. Separate from "
        "$INFERA_ENGINE_READY_TIMEOUT, which is the engine's own /health budget.",
    )
    parser.add_argument(
        "--request-transport",
        choices=("http", "nats"),
        default="nats",
        help="How the router reaches this worker. 'nats' (default) runs a NATS "
        "consumer that proxies requests from this worker's per-instance subject to "
        "the local engine HTTP (worker advertises request_transport=nats so the "
        "router uses NATS; requires a reachable --nats-server / $NATS_SERVER). "
        "'http' serves the engine HTTP directly.",
    )
    parser.add_argument(
        "--nats-req-idle-timeout",
        type=float,
        default=None,
        help="NATS request idle (inactivity) timeout (s) for the worker's local "
        "read timeout. None => $INFERA_NATS_REQ_IDLE_TIMEOUT or default 900.",
    )
    parser.add_argument(
        "--nats-req-max-duration",
        type=float,
        default=None,
        help="NATS request total (overall) timeout (s); the worker hard-aborts a "
        "request at this wall-clock cap. None => $INFERA_NATS_REQ_MAX_DURATION "
        "or built-in default 0 (off).",
    )
    parser.add_argument(
        "--nats-req-max-pending",
        type=int,
        default=None,
        help="NATS request admission limit; >0 makes this worker consume requests "
        "via a JetStream consumer so the router can throttle by backlog. None => "
        "$INFERA_NATS_REQ_MAX_PENDING or built-in default 0 (off).",
    )
    parser.add_argument(
        "--drain-timeout",
        type=float,
        default=float(__import__("os").environ.get("INFERA_DRAIN_TIMEOUT", "30") or 30),
        help="Graceful shutdown: on SIGTERM the worker stops accepting new NATS "
        "requests and lets in-flight generations finish for up to this many "
        "seconds (rolling-upgrade drain). How long one generation is worth "
        "waiting for: whatever is still running at the deadline is cancelled, "
        "or handed back to the router when it enabled --migration-limit. "
        "Default 30; 0 = do not wait. Overrides $INFERA_DRAIN_TIMEOUT.",
    )
    parser.add_argument(
        "--advertise-host",
        default=None,
        help="Host/IP to publish to etcd (worker_id, url, bootstrap_addr). "
        "Use this when the engine binds on 0.0.0.0 but peers need to "
        "reach it via a routable address. Defaults to --host.",
    )
    parser.add_argument(
        "--enable-kv-events",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Publish KV cache events on a ZMQ socket for KV-aware routing "
        "(default on; pass --no-enable-kv-events to disable). A free port is "
        "allocated automatically and reported to the router via "
        "WorkerInfo.kv_events_endpoint.",
    )
    parser.add_argument(
        "--disaggregation-allow-tcp",
        action="store_true",
        default=False,
        help="Benchmark-only: skip the disagg transport preflight that "
        "rejects configs prone to a silent TCP fallback (no explicit RDMA "
        "--disaggregation-transfer-backend). Do NOT use in production.",
    )

    # KV management.
    parser.add_argument(
        "--kv-events",
        choices=("on", "off", "auto"),
        default="auto",
        help="Enable per-worker KV event publishing (ZMQ PUB). 'auto' "
        "(default) turns it on iff tokenizer loads cleanly. 'off' "
        "skips it: the worker still registers but the router falls "
        "back to round-robin for it.",
    )
    parser.add_argument(
        "--kv-events-bind",
        default="tcp://0.0.0.0:5557",
        help="ZMQ PUB endpoint to bind. Default tcp://0.0.0.0:5557.",
    )
    parser.add_argument(
        "--kv-events-advertise",
        default=None,
        help="ZMQ endpoint to advertise to the server (etcd kv block). "
        "Default: derived from --kv-events-bind, with host filled from "
        "SGLang --host if the bind uses 0.0.0.0.",
    )
    parser.add_argument(
        "--kv-snapshot-host",
        default="0.0.0.0",
        help="Bind host for the per-worker snapshot HTTP server. Default 0.0.0.0.",
    )
    parser.add_argument(
        "--kv-snapshot-port",
        type=int,
        default=8801,
        help="Bind port for the per-worker snapshot HTTP server. Default 8801.",
    )
    parser.add_argument(
        "--kv-snapshot-advertise",
        default=None,
        help="Base URL the server should pull /v1/kv-snapshot from. "
        "Default: derived from --kv-snapshot-port + SGLang --host.",
    )
    parser.add_argument(
        "--index-block-size",
        type=int,
        default=64,
        help="Block size used for index_block hashing. This is the "
        "router's coalescing unit, NOT the engine's KV page size. "
        "Default 64.",
    )

    parser.add_argument(
        "--kv-event-transport",
        choices=("zmq", "nats"),
        default="nats",
        help="How this worker exposes KV events to the router. 'nats' "
        "(default): relay engine events onto a NATS broker so the router can "
        "subscribe once (infera.kv.events.>). 'zmq': engine publishes on "
        "kv_events_endpoint, router connects directly. Requires --enable-kv-events.",
    )
    parser.add_argument(
        "--nats-server",
        default=None,
        help="NATS server URL for --kv-event-transport=nats (default: "
        "$NATS_SERVER or nats://127.0.0.1:4222).",
    )

    # Phase 4.5+: infera-kvd HiCacheStorage adapter wiring.
    parser.add_argument(
        "--infera-kvd-socket",
        default=None,
        help="UDS path the infera-kvd daemon listens on. When set, the "
        "infera-kvd backend is registered with SGLang's storage factory "
        "and selected via --hicache-storage-backend infera-kvd. The "
        "socket must be reachable BEFORE the engine starts (the worker "
        "probes it and aborts on failure rather than running with a "
        "silently-broken cache backend). Also sets INFERA_KVD_SOCKET "
        "in the environment for child processes.",
    )

    # Split our args from SGLang's args
    known, remaining = parser.parse_known_args(argv)

    # Parse the rest as SGLang ServerArgs
    sglang_parser = argparse.ArgumentParser(add_help=False)
    ServerArgs.add_cli_args(sglang_parser)
    remaining = _rename_cuda_graph_max_bs(remaining, sglang_parser)
    sglang_parsed = sglang_parser.parse_args(remaining)

    # infera product default: fp8 KV cache (fp8_e4m3) unless the operator passed
    # --kv-cache-dtype explicitly. fp8 halves the KV footprint -> ~2x the KV that
    # fits in VRAM and halves PD KV-transfer + RDMA memory-registration volume
    # (bf16 hit ionic ibv_reg_mr ENOMEM at high concurrency / long inputs). Small
    # accuracy cost; opt out with --kv-cache-dtype auto|bf16 or INFERA_DEFAULT_KV_FP8=0.
    #
    # Applied to the PARSED ARGS, before ServerArgs resolves them. Newer SGLang
    # freezes server_args once resolved and raises on assignment:
    #
    #   AttributeError: server_args.kv_cache_dtype assigned after resolution;
    #   server_args is read-only -- use get_context().override(source, ...)
    #
    # which took down every worker on the Kimi-K3 build. Setting it pre-resolution
    # needs no override API and works on both the old and new SGLang.
    if os.environ.get("INFERA_DEFAULT_KV_FP8", "1") != "0" and not any(
        t == "--kv-cache-dtype" or t.startswith("--kv-cache-dtype=") for t in remaining
    ):
        sglang_parsed.kv_cache_dtype = "fp8_e4m3"
        logger.info(
            "infera default: kv_cache_dtype=fp8_e4m3 "
            "(override with --kv-cache-dtype or INFERA_DEFAULT_KV_FP8=0)"
        )

    # Explicit HiCache needs radix even when KV-event publication is disabled.
    auto_decode_radix = (
        (known.enable_kv_events or getattr(sglang_parsed, "enable_hierarchical_cache", False))
        and sglang_parsed.disaggregation_mode == "decode"
        and getattr(sglang_parsed, "disaggregation_transfer_backend", None) == "mooncake"
        and _DECODE_RADIX_CACHE_FLAG not in remaining
    )
    spec_opted_in = (
        getattr(sglang_parsed, "speculative_algorithm", None) is None
        or os.environ.get(_DECODE_RADIX_SPEC_ENV, "0") == "1"
    )
    radix_for_hicache = (
        auto_decode_radix
        and spec_opted_in
        and getattr(sglang_parsed, "enable_hierarchical_cache", False)
    )
    if radix_for_hicache:
        if getattr(sglang_parsed, "disable_radix_cache", False):
            raise ValueError("Decode HiCache is incompatible with --disable-radix-cache")
        # HiCache compatibility is checked inside ServerArgs construction.
        sglang_parsed.disaggregation_decode_enable_radix_cache = True
        remaining.append(_DECODE_RADIX_CACHE_FLAG)

    server_args = ServerArgs.from_cli_args(sglang_parsed)

    from infera.engine.sglang.hicache_validate import warn_if_hicache_prefetch_disabled

    warn_if_hicache_prefetch_disabled(server_args)

    # Model checks need the resolved config. Ordinary Decode can still append
    # the flag here; HiCache must have received it before resolution above.
    if auto_decode_radix:
        # Keep stock behavior unless the worker uses a SGLang build with the
        # matching decode-radix/speculation opt-in.
        if not spec_opted_in:
            logger.info(
                "kv-events on, but --disaggregation-decode-enable-radix-cache is "
                "incompatible with --speculative-algorithm %s; not appending it. "
                "The decode leg will use SGLang's chunk cache and contribute "
                "little to the router KV view; prefix-aware routing runs on the "
                "prefill-side view. %s=1 opts in on an SGLang that carries the "
                "decode-radix-spec patch.",
                sglang_parsed.speculative_algorithm,
                _DECODE_RADIX_SPEC_ENV,
            )
        else:
            # Same story for the rest of SGLang's rejection set, the hybrid
            # SWA/SSM half of which bites much later and much harder -- which is
            # why it gets its own guard rather than a line in the one above.
            # See _decode_radix_cache_unsupported_reason.
            reason = _decode_radix_cache_unsupported_reason(server_args)
            if reason is not None:
                if radix_for_hicache:
                    raise ValueError(f"Decode HiCache requires a supported radix cache: {reason}")
                logger.info(
                    "kv-events on, but --disaggregation-decode-enable-radix-cache "
                    "is incompatible with %s; not appending it. The decode leg "
                    "will use SGLang's chunk cache and contribute little to the "
                    "router KV view; prefix-aware routing runs on the "
                    "prefill-side view.",
                    reason,
                )
            elif not radix_for_hicache:
                remaining.append(_DECODE_RADIX_CACHE_FLAG)

    return SglangWorkerArgs(
        server_args=server_args,
        discovery_backend=known.discovery_backend,
        etcd_endpoint=known.etcd_endpoint,
        etcd_prefix=known.etcd_prefix,
        k8s_namespace=known.k8s_namespace,
        request_transport=known.request_transport,
        nats_req_idle_timeout=known.nats_req_idle_timeout,
        nats_req_max_duration=known.nats_req_max_duration,
        nats_req_max_pending=known.nats_req_max_pending,
        drain_timeout=known.drain_timeout,
        advertise_host=known.advertise_host,
        disaggregation_allow_tcp=known.disaggregation_allow_tcp,
        enable_kv_events=known.enable_kv_events,
        sglang_argv=list(remaining),
        kv_events=known.kv_events,
        kv_events_bind=known.kv_events_bind,
        kv_events_advertise=known.kv_events_advertise,
        kv_snapshot_host=known.kv_snapshot_host,
        kv_snapshot_port=known.kv_snapshot_port,
        kv_snapshot_advertise=known.kv_snapshot_advertise,
        index_block_size=known.index_block_size,
        kv_event_transport=known.kv_event_transport,
        nats_server=known.nats_server,
        infera_kvd_socket=known.infera_kvd_socket,
        wait_for_decode=known.wait_for_decode,
        decode_ready_timeout=known.decode_ready_timeout,
        k8s_label_selector=known.k8s_label_selector,
    )


def no_clear_event_reason(args: SglangWorkerArgs) -> str | None:
    """Why flushing this engine's cache cannot re-anchor its KV-event chain.

    Returns a short reason, or None when a flush does re-anchor.

    ``infera/engine/flush.py`` repairs a chain by flushing and then *waiting for
    the resulting* ``AllBlocksCleared`` -- waiting on the observation rather
    than on its own POST is the whole point, because a flush issued before the
    relay's subscription attached is lost the same way the anchor was. But that
    wait only terminates against an engine that emits the event at all.

    A PD decode leg without :data:`_DECODE_RADIX_CACHE_FLAG` runs SGLang's
    ``ChunkCache``, whose ``reset()`` is ``pass``. ``/flush_cache`` still answers
    **200** -- the scheduler accepted it, there was simply no radix tree to
    clear -- so nothing distinguishes it from a successful flush except the
    event that never comes. Unasked, the loop spends its full budget (~10s with
    the defaults) on the startup path, immediately before ``register()``, and
    then warns that "the router's chain has no anchor" about a leg that has no
    chain to anchor and never had one.

    This is not a corner case here: the guard a few lines up refuses that same
    flag for hybrid SWA/SSM models, which makes ChunkCache the *normal* decode
    leg for Kimi-K3 and everything else in that family.

    A decode leg is not the only way onto ChunkCache, though it is the one that
    prompted this. ``--disable-radix-cache`` puts an aggregated or prefill
    worker on the same cache, with the same silent 200 and the same lost budget.

    For a decode leg, read off ``sglang_argv`` rather than ``server_args``: the
    append happens after ``ServerArgs.from_cli_args``, and SGLang's
    ``pd_disaggregation_hook`` has by then already set
    ``server_args.disable_radix_cache = True`` for *every* decode leg, including
    the ones we are about to hand the flag to. Reading that attribute in decode
    mode answers "ChunkCache" for a leg that will run a radix cache. The
    forwarded argv is what ``launch_server`` actually parses, and is the only
    honest source here. Outside decode mode the hook leaves the attribute alone,
    so there it *is* the operator's own setting.

    One residual, deliberately not covered: ``kv_cache_builder.py`` also forces
    ChunkCache for a multimodal model on the Transformers backend, which no
    argument announces. Detecting it means loading the model config, and this
    function has no failure path -- unlike
    ``_decode_radix_cache_unsupported_reason``, which needs one anyway. The cost
    of missing it is one wasted startup budget and one confusing line, not a
    crash, which is not worth a new way for argv parsing to fail.
    """
    sa = args.server_args
    if sa.disaggregation_mode == "decode":
        if _DECODE_RADIX_CACHE_FLAG in args.sglang_argv:
            return None
        return (
            "this PD decode leg runs SGLang's ChunkCache "
            f"({_DECODE_RADIX_CACHE_FLAG} is not set), which keeps no radix tree "
            "and emits no AllBlocksCleared -- /flush_cache would answer 200 and "
            "publish nothing"
        )
    if sa.disable_radix_cache:
        return (
            "--disable-radix-cache puts this worker on SGLang's ChunkCache, "
            "which keeps no radix tree and emits no AllBlocksCleared -- "
            "/flush_cache would answer 200 and publish nothing"
        )
    return None


def _decode_radix_cache_unsupported_reason(server_args) -> str | None:
    """Why SGLang would reject ``--disaggregation-decode-enable-radix-cache``.

    Returns a short reason ("Mamba/SSM models", "--enable-hisparse"), or None
    when this decode leg accepts the flag. Callers may assume decode mode: the
    only caller is already inside that branch, and every rejection below is one
    SGLang raises only for a decode leg.

    Two sites reject the flag, and they differ in *when*.

    ``arg_groups/pd_disaggregation_hook.py`` rejects at argument-resolution
    time, before any weight is loaded: ``--enable-hisparse``, and ``dcp_size >
    1`` (PD decode DCP is chunk-cache only). Those are cheap to hit but still
    worth pre-empting, because the ValueError names a flag the operator never
    passed -- infera appended it -- so the obvious fix, deleting it from their
    config, is a flag they cannot find.

    ``mem_cache/kv_cache_builder.py`` rejects a hybrid SWA or SSM model: those
    keep their state in specialised pools that the prefix-match-and-lock
    allocation path cannot address. Two things make *that* raise worth
    pre-empting:

    * it fires inside ``build_kv_cache``, i.e. *after* the weights are loaded,
      so each wrong answer costs ~2.5 minutes and shows up as a decode leg that
      dies long after startup looked healthy;
    * the flag is one *we* appended, not one the operator asked for, so the
      resulting ValueError names a flag that appears nowhere in their config.

    Kimi-K3 (hybrid SSM / KDA linear attention) hit exactly this; it took four
    deployments to find, and the workaround was to hand-write
    ``--no-enable-kv-events`` on every decode leg -- which also switched off the
    KV events themselves, a much bigger hammer than the problem needed.

    The predicates are deliberately SGLang's own rather than an architecture
    list of ours. That list grows every release and a stale copy fails in both
    directions: miss a newly-added hybrid arch and the late crash is back, match
    too eagerly and the decode-side KV view disappears with nothing to show why.
    Mirrors ``kv_cache_builder.py`` -- ``is_hybrid_swa`` there reads
    ``tp_worker.is_hybrid_swa``, which is ``model_config.is_hybrid_swa``, the
    same attribute read here.

    Two rejections in the hook are deliberately *not* mirrored:
    ``--disaggregation-transfer-backend fake`` is unreachable, because the
    append is already gated on that backend being ``mooncake``; and
    ``speculative_algorithm`` has its own guard at the call site, which can name
    the algorithm in its message.

    Never raises: a model whose config cannot be read here fails for real a few
    lines later when the engine starts, and refusing to launch over a *warning
    path* would be worse than the crash it is meant to avoid.
    """
    # Above the try, and read off `server_args` rather than the model config:
    # these two need neither, so a config that cannot be read must not swallow
    # them into the "appending it as before" fallback below.
    #
    # getattr with a default because both flags postdate some SGLang releases we
    # still run against; on one that lacks them, there is no rejection to
    # pre-empt.
    if getattr(server_args, "enable_hisparse", False):
        return "--enable-hisparse"
    if getattr(server_args, "dcp_size", 1) > 1:
        return "--dcp-size > 1 (PD decode DCP requires chunk cache)"

    try:
        # Inside the try on purpose: `hybrid_arch` is a private SGLang module and
        # its contents move between releases, so an ImportError here is exactly
        # the "cannot read the config" case the docstring promises to survive.
        # Importing above the try would raise it at the caller instead.
        from sglang.srt.configs.hybrid_arch import (
            hybrid_gdn_config,
            hybrid_lightning_config,
            kimi_linear_config,
            linear_attn_model_spec,
            mamba2_config,
        )

        get_model_config = getattr(server_args, "get_model_config", None)
        if get_model_config is not None:
            model_config = get_model_config()
        else:
            # SGLang >= v0.5.22 builds the ModelConfig from the arguments record.
            from sglang.srt.arg_groups.model_override_base import model_config_of

            model_config = model_config_of(server_args)

        if model_config.is_hybrid_swa:
            return "sliding window attention (SWA) models"

        spec = linear_attn_model_spec(model_config)
        if (
            (spec is not None and spec.uses_mamba_radix_cache)
            or hybrid_gdn_config(model_config) is not None
            or mamba2_config(model_config) is not None
            or kimi_linear_config(model_config) is not None
            or hybrid_lightning_config(model_config) is not None
        ):
            return "Mamba/SSM models"
    except Exception:  # noqa: BLE001 - see the docstring's last paragraph
        # An explicit radix flag is force-on, not an escape from incompatibility.
        # Opt out of KV events and HiCache to suppress automatic radix.
        logger.warning(
            "could not determine whether this model supports "
            "--disaggregation-decode-enable-radix-cache; appending it as before. "
            "If the decode leg dies in build_kv_cache with an 'incompatible "
            "with Mamba/SSM models' or 'with sliding window attention (SWA) "
            "models' ValueError, this model is one of those: relaunch the decode "
            "leg with --no-enable-kv-events and disable HiCache if it was requested. Passing "
            "--disaggregation-decode-enable-radix-cache explicitly will not help "
            "-- infera reads it as a request to force the flag on, and forwards "
            "it.",
            exc_info=True,
        )

    return None


# `warn_if_hicache_prefetch_disabled` lives in
# `infera.engine.sglang.hicache_validate` — kept separate so the
# unit tests don't have to import sglang.srt.server_args.
