###############################################################################
# Copyright (c) 2026, Advanced Micro Devices, Inc. All rights reserved.
#
# SPDX-License-Identifier: MIT
###############################################################################
"""python -m infera.engine.sglang --model-path Qwen/Qwen3-0.6B --port 30000 \\
    --etcd-endpoint host:2379

For PD disaggregation, pass SGLang's own --disaggregation-mode:
    --disaggregation-mode prefill --disaggregation-bootstrap-port 8998
    --disaggregation-mode decode

KV management:
    --kv-events auto         # auto (default) | on | off
    --kv-events-bind tcp://0.0.0.0:5557
    --kv-snapshot-port 8801
    --index-block-size 64
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager

import httpx

from infera.common.disagg_preflight import (
    validate_advertise_host,
    validate_sglang_transport,
)
from infera.common.discovery import _normalize_endpoint
from infera.common.k8s_client import make_client
from infera.common.registration import RegistrationClient
from infera.common.registration_k8s import K8sRegistrationClient
from infera.engine.base import EngineDeath, watch_engine_death
from infera.engine.decode_barrier import (
    DISCOVERY_LOOKUP_ERRORS,
    apply_pd_probe_recovery_defaults,
    decode_ready_timeout_seconds,
    discovery_budget_seconds,
    ensure_barrier_discovery_is_reachable,
    ensure_skip_server_warmup,
    is_compatible_prefill_worker,
    list_etcd_worker_payloads,
    list_k8s_worker_payloads,
    prefill_bootstrap_addr,
    probe_until_one_passes,
    should_verify_prefill,
    should_wait_for_decode,
    verify_pd_peer,
    wait_for_decode,
    wait_for_k8s_label_selector,
)
from infera.engine.drain import drain_engine_inflight
from infera.engine.flush import anchor_kv_chain
from infera.engine.readiness import (
    close_readiness,
    engine_health_check,
    serve_readiness_best_effort,
)
from infera.engine.sglang.args import (
    SglangWorkerArgs,
    no_clear_event_reason,
    parse_sglang_args,
)
from infera.engine.sglang.kv_wiring import (
    SglangKvWiring,
    build_and_start,
    resolve_advertise_endpoint,
)
from infera.engine.sglang.kvd_wiring import awire_infera_kvd_backend
from infera.engine.sglang.worker import SglangEngine

#: Floor on the budget left before a peer probe is attempted. wait_for(0.0)
#: raises immediately, which would fail the decode without naming a peer.
_MIN_PREFILL_PROBE_SECONDS = 5.0


def _kill_process_group_safely() -> None:
    """Tear down the process group with SIGTERM → wait → SIGKILL.

    A naive `os.killpg(getpgrp(), SIGKILL)` also kills the parent shell when
    the worker wasn't started via `setsid` (most dev invocations). SIGTERM
    first lets the SGLang children clean up; the brief sleep may take us
    (and them) down before the SIGKILL, which is the intent.
    """
    try:
        pgid = os.getpgrp()
        os.killpg(pgid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        return
    import time as _time

    _time.sleep(0.5)
    try:
        os.killpg(pgid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


def _multinode_node_rank(args: SglangWorkerArgs) -> int:
    """This worker's node rank in a multi-node (LeaderWorkerSet) TP group.

    From sglang ServerArgs (set via the injected --node-rank
    $LWS_WORKER_INDEX), with the LWS env as a fallback.
    """
    node_rank = int(getattr(args.server_args, "node_rank", 0) or 0)
    if node_rank <= 0:
        try:
            node_rank = int(os.environ.get("LWS_WORKER_INDEX", "0") or "0")
        except ValueError:
            node_rank = 0
    return node_rank


async def _maybe_wait_for_decode(args: SglangWorkerArgs, config) -> None:
    """Verify a compatible decode worker and its real KV path.

    Weight load already happened: launch_server ran with --skip-server-warmup.
    Fake-bootstrap PD warmup is replaced by a real peer-to-peer transfer.
    """
    mode = getattr(args.server_args, "disaggregation_mode", None)
    if not should_wait_for_decode(mode, args.wait_for_decode):
        return
    # After engine.start() the TP group has already rendezvoused. Only the
    # serving rank issues warmup /generate and needs decode to be registered.
    if _multinode_node_rank(args) > 0:
        logger.info("decode barrier: skipped wait on multinode follower")
        return
    model_name = (
        getattr(args.server_args, "served_model_name", None)
        or getattr(args.server_args, "model_path", None)
        or ""
    )
    timeout = decode_ready_timeout_seconds(args.decode_ready_timeout)
    started = asyncio.get_running_loop().time()
    deadline = started + timeout
    # Discovery stops early so the KV probe keeps a reserve of the shared
    # budget; it still runs one immediate lookup when nothing is left.
    discovery_deadline = started + discovery_budget_seconds(timeout)

    async with _discovery_lister(
        args,
        selector_timeout=max(0.0, discovery_deadline - asyncio.get_running_loop().time()),
    ) as _list:
        logger.info(
            "decode barrier: prefill waiting up to %.0fs for a registered decode worker "
            "(model=%s, discovery=%s)",
            timeout,
            model_name,
            args.discovery_backend,
        )
        remaining = max(0.0, discovery_deadline - asyncio.get_running_loop().time())
        decode = await wait_for_decode(_list, model_name=str(model_name), timeout=remaining)
        decode_url = str(decode.get("url") or "").rstrip("/")
        if not decode_url:
            raise RuntimeError("registered decode worker has no URL")
        bootstrap_host = str(config.host)
        if bootstrap_host in ("0.0.0.0", ""):
            raise RuntimeError("prefill has no routable bootstrap host")
        # The probe spends what is left of the decode-ready budget rather than
        # extending it: its own retry schedule is otherwise unbounded here.
        probe_timeout = max(0.0, deadline - asyncio.get_running_loop().time())
        await asyncio.wait_for(
            verify_pd_peer(
                prefill_url=f"http://{config.host}:{config.port}",
                decode_url=decode_url,
                bootstrap_host=bootstrap_host,
                bootstrap_port=int(args.server_args.disaggregation_bootstrap_port),
                dp_size=int(getattr(args.server_args, "dp_size", 1) or 1),
                decode_dp_size=int(decode.get("dp_size") or 1),
            ),
            timeout=probe_timeout,
        )


@asynccontextmanager
async def _discovery_lister(
    args: SglangWorkerArgs, *, selector_timeout: float
) -> AsyncIterator[Callable[[], Awaitable[list]]]:
    """Open one discovery client and yield a worker-listing callable.

    One client for the whole caller on either backend. The k8s path also
    re-reads the ServiceAccount token per request so a rotation is not a 401.
    """
    http: httpx.AsyncClient | None = None
    try:
        if args.discovery_backend == "kubernetes":
            http = make_client(timeout=10.0)
            selector = await wait_for_k8s_label_selector(
                args.k8s_label_selector,
                namespace=args.k8s_namespace,
                http=http,
                timeout=selector_timeout,
            )

            async def _list() -> list:
                return await list_k8s_worker_payloads(
                    namespace=args.k8s_namespace,
                    label_selector=selector,
                    http=http,
                )

        else:
            http = httpx.AsyncClient(base_url=_normalize_endpoint(args.etcd_endpoint), timeout=10.0)

            async def _list() -> list:
                return await list_etcd_worker_payloads(
                    args.etcd_endpoint, args.etcd_prefix, http=http
                )

        yield _list
    finally:
        if http is not None:
            await http.aclose()


async def _maybe_verify_prefill_peer(args: SglangWorkerArgs, config) -> None:
    """Verify the KV path to an already-registered prefill before serving.

    The reverse of the prefill barrier, and the reason a rolling upgrade can
    replace one leg at a time: the prefill barrier only runs on a starting
    prefill, so a decode replaced on its own would otherwise join the fleet
    with its transfer path to the surviving prefill never exercised.

    Unlike the prefill barrier this never waits. A prefill registers only
    after probing a decode, so a decode that blocked here would deadlock the
    first deployment of a pair. Finding no prefill therefore means "nothing to
    verify yet" and the prefill's own barrier covers the pairing instead.
    """
    mode = getattr(args.server_args, "disaggregation_mode", None)
    if not should_verify_prefill(mode, args.wait_for_decode):
        return
    if _multinode_node_rank(args) > 0:
        logger.info("prefill probe: skipped on multinode follower")
        return
    model_name = str(
        getattr(args.server_args, "served_model_name", None)
        or getattr(args.server_args, "model_path", None)
        or ""
    )
    decode_url = f"http://{config.host}:{config.port}"
    timeout = decode_ready_timeout_seconds(args.decode_ready_timeout)
    deadline = asyncio.get_running_loop().time() + timeout

    # A misconfigured discovery backend is fatal, and checked before anything
    # is dialled: an unresolvable label selector would otherwise make every
    # lookup fail, and the except below would read that as "no peers yet" and
    # skip the verification this exists for -- silently, on every decode.
    ensure_barrier_discovery_is_reachable(
        args.discovery_backend,
        k8s_label_selector=args.k8s_label_selector,
        etcd_endpoint=args.etcd_endpoint,
    )

    # A reachable-but-failing lookup skips the probe rather than failing the
    # worker: decode is the leg that starts first, so making it depend on a
    # healthy backend would turn an unrelated outage into a decode that cannot
    # boot. Narrow to transport and protocol errors, so a TypeError or
    # AttributeError in this path surfaces as the bug it is instead of hiding
    # as a skipped probe. A failed *probe* below is the opposite -- that is the
    # incompatibility this exists to catch, and it must stop registration.
    try:
        async with _discovery_lister(
            args, selector_timeout=discovery_budget_seconds(timeout)
        ) as list_workers:
            workers = await list_workers()
    except DISCOVERY_LOOKUP_ERRORS as exc:
        logger.warning("prefill probe: worker lookup failed; skipping: %s", exc)
        return

    peers = [
        payload
        for payload in workers
        if is_compatible_prefill_worker(payload, model_name=model_name)
    ]
    if not peers:
        logger.info(
            "prefill probe: no registered prefill for model %s; skipping "
            "(the prefill barrier covers this pairing)",
            model_name,
        )
        return
    # One verified peer is enough. Every registered prefill may route here, so
    # probing all of them would cover more -- but the transfer path this checks
    # (Mooncake/RDMA over the same NICs) is shared, so a second passing peer
    # re-exercises the same plumbing. A failing peer moves on to the next one,
    # so a stale registration for a dead prefill does not fail every decode.
    # The prefill barrier covers the pairing from the other side as peers
    # restart.
    decode_dp_size = int(getattr(args.server_args, "dp_size", 1) or 1)

    def _probe_for(peer: dict, prefill_url: str, host: str, port: int):
        async def probe(_budget: float) -> None:
            logger.info(
                "prefill probe: verifying KV path to prefill %s (bootstrap %s:%d)",
                peer.get("worker_id") or prefill_url,
                host,
                port,
            )
            await verify_pd_peer(
                prefill_url=prefill_url,
                decode_url=decode_url,
                bootstrap_host=host,
                bootstrap_port=port,
                dp_size=int(peer.get("dp_size") or 1),
                decode_dp_size=decode_dp_size,
            )

        return probe

    probes = []
    for peer in peers:
        addr = prefill_bootstrap_addr(peer)
        prefill_url = str(peer.get("url") or "").rstrip("/")
        if addr is None or not prefill_url:
            continue
        host, port = addr
        probes.append(
            (peer.get("worker_id") or prefill_url, _probe_for(peer, prefill_url, host, port))
        )
    if not probes:
        logger.warning(
            "prefill probe: %d registered prefill(s) for model %s carry no url or "
            "bootstrap address; skipping verification",
            len(peers),
            model_name,
        )
        return

    # A spent budget must not become a zero timeout: wait_for(0.0) raises
    # immediately, which would fail the decode without naming a peer or ever
    # reaching the engine.
    loop = asyncio.get_running_loop()
    if not await probe_until_one_passes(
        probes, deadline=deadline, min_budget=_MIN_PREFILL_PROBE_SECONDS, clock=loop.time
    ):
        logger.warning(
            "prefill probe: less than %.0fs of the %.0fs budget left; skipping verification",
            _MIN_PREFILL_PROBE_SECONDS,
            timeout,
        )


def _supervise_engine(engine: SglangEngine) -> tuple[asyncio.Event, EngineDeath, asyncio.Task]:
    """Watch SIGTERM and subprocess death for the whole post-start lifetime."""
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)
    death = EngineDeath()
    death_task = watch_engine_death(engine, stop, death)
    return stop, death, death_task


async def _startup_barrier(args: SglangWorkerArgs, config) -> None:
    """Run whichever PD barrier applies to this leg before it registers.

    Both halves early-return on the wrong disaggregation mode, so a prefill
    runs the first, a decode the second, and a mixed worker neither.
    """
    await _maybe_wait_for_decode(args, config)
    await _maybe_verify_prefill_peer(args, config)


async def _run_startup_barrier_until_stop(
    args: SglangWorkerArgs, config, stop: asyncio.Event
) -> bool:
    """Run the PD barrier unless shutdown or engine death wins the race."""
    wait_task = asyncio.create_task(_startup_barrier(args, config))
    stop_task = asyncio.create_task(stop.wait())
    try:
        await asyncio.wait({wait_task, stop_task}, return_when=asyncio.FIRST_COMPLETED)
        if wait_task.done() and not wait_task.cancelled():
            wait_task.result()
            return not stop.is_set()
        return False
    finally:
        for task in (wait_task, stop_task):
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass


logging.basicConfig(level=logging.INFO)
# httpx logs every etcd lease keepalive (~ every ttl/3 seconds). That's
# pure noise in the worker log; surface only warnings/errors.
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)


def _wire_mori_dispatch_buffer(server_args) -> None:
    """Size the mori-MoE expert-dispatch buffer from the documented chunked-prefill knob.

    SGLang's mori MoE all-to-all preallocates a per-rank dispatch buffer of
    ``SGLANG_MORI_NUM_MAX_DISPATCH_TOKENS_PER_RANK`` tokens (default 4096) and, on the
    PREFILL engine, asserts ``chunked_prefill_size <= that`` (server_args.py; the check
    is skipped for ``disaggregation-mode=decode``). That env var is undocumented, so a
    user who legitimately raises the documented ``--chunked-prefill-size`` gets a cryptic
    assert and has to discover a second, hidden knob. Instead: when mori-MoE is active and
    the operator hasn't pinned the env explicitly, derive the buffer from the chunked-prefill
    size they chose — one documented knob, no surprise assert. The env is read by the
    ``sglang.launch_server`` subprocess, which inherits this process's environment.
    """
    if getattr(server_args, "moe_a2a_backend", None) != "mori":
        return  # mori MoE off -> no buffer, no assert
    if os.environ.get("SGLANG_MORI_NUM_MAX_DISPATCH_TOKENS_PER_RANK"):
        return  # explicit operator override wins
    cps = getattr(server_args, "chunked_prefill_size", None)
    if not cps or cps <= 0:  # chunked prefill disabled -> assert skipped
        return
    os.environ["SGLANG_MORI_NUM_MAX_DISPATCH_TOKENS_PER_RANK"] = str(int(cps))
    logger.info(
        "mori-MoE: auto-set SGLANG_MORI_NUM_MAX_DISPATCH_TOKENS_PER_RANK=%d to match "
        "--chunked-prefill-size (satisfies sglang's prefill dispatch-buffer assert)",
        int(cps),
    )


async def _maybe_start_kv_plane(
    args: SglangWorkerArgs,
    engine: SglangEngine,
    *,
    model_name: str,
) -> SglangKvWiring | None:
    """Build the KV plane unless `--kv-events off`.

    Returns the SglangKvWiring (caller stops it on shutdown) or None if
    KV was skipped or failed to come up under --kv-events auto.
    """
    if args.kv_events == "off":
        logger.info("--kv-events off; worker will register with kv=None")
        return None

    # 0.0.0.0 bind is fine inside the worker but useless on the wire;
    # the registered endpoint must be reachable by the server.
    #
    # Use the resolved advertise host, not the bind host. main() sets
    # args.advertise_host from POD_IP under Kubernetes discovery precisely so these
    # endpoints can be reached — its own comment says "the registered url/worker_id
    # and kv endpoints all derive from this" — but this path ignored it and
    # published the bind address. With the usual `--host 0.0.0.0` the router then
    # polled `http://0.0.0.0:8801` for every worker and logged "All connection
    # attempts failed" on a loop, while both workers registered and looked healthy.
    # The vLLM worker already does `args.advertise_host or args.host`.
    advertise_host = args.advertise_host or args.server_args.host
    events_advertise = args.kv_events_advertise or resolve_advertise_endpoint(
        args.kv_events_bind, advertise_host
    )
    snapshot_advertise = args.kv_snapshot_advertise or (
        f"http://{advertise_host}:{args.kv_snapshot_port}"
    )

    # The KV page size the engine actually settled on. `SglangEngine.start`
    # reads it back from the subprocess's /get_server_info once it is serving,
    # because `server_args.page_size` is only what the operator typed and stays
    # None whenever they left the choice to the engine.
    #
    # When neither is known we register None. Registering 1 instead is worse
    # than registering nothing: the router accepts the value, builds a KV view
    # at block_size 1, then rejects every event the engine emits at 64 and
    # silently drops to round-robin. Seen on GLM-5.3-Flash
    # (attention_backend=dsa), where the router logged
    #
    #   kv events ... are paged at block_size=64 but this worker registered 1
    #
    # for both legs. None makes the router skip the worker and say so once.
    engine_block_size = getattr(engine, "resolved_page_size", None) or getattr(
        args.server_args, "page_size", None
    )
    if engine_block_size:
        engine_block_size = int(engine_block_size)
    else:
        engine_block_size = None
        logger.warning(
            "KV page size is unresolved (engine did not report one and --page-size "
            "is unset); registering engine_block_size=None. kv-aware routing will "
            "skip this worker. Pass --page-size explicitly to pin it."
        )

    # Locate the RadixCache. SGLang exposes it on its scheduler, which
    # the launch_server thread keeps alive — but it isn't reliably
    # reachable from outside the worker process, so we attach only if we
    # can grab it. Otherwise the plane still runs (events empty, the
    # reconciler will catch up via empty snapshots until SGLang grows
    # an out-of-process event hook).
    try:
        from infera.engine.sglang.kv_wiring import _find_radix_cache

        radix_cache = _find_radix_cache(engine)
    except Exception:
        radix_cache = None

    publisher_id = f"{args.server_args.host}:{args.server_args.port}"
    try:
        wiring = await build_and_start(
            model_id=model_name,
            tokenizer_path=args.server_args.tokenizer_path or args.server_args.model_path,
            engine_block_size=engine_block_size,
            index_block_size=args.index_block_size,
            publisher_id=publisher_id,
            events_bind=args.kv_events_bind,
            events_advertise=events_advertise,
            snapshot_host=args.kv_snapshot_host,
            snapshot_port=args.kv_snapshot_port,
            snapshot_advertise=snapshot_advertise,
            radix_cache=radix_cache,
            trust_remote_code=bool(getattr(args.server_args, "trust_remote_code", False)),
        )
    except Exception:
        # `auto` swallows; `on` fails fast.
        if args.kv_events == "on":
            raise
        logger.exception(
            "--kv-events auto: KV plane failed to start; worker will register with kv=None"
        )
        return None

    logger.info(
        "KV plane up: events_bind=%s events_advertise=%s snapshot=%s "
        "engine_block_size=%s index_block_size=%d",
        args.kv_events_bind,
        events_advertise,
        snapshot_advertise,
        engine_block_size,
        args.index_block_size,
    )
    return wiring


async def main() -> None:
    args = parse_sglang_args()

    # Kubernetes discovery: advertise the routable Pod IP (downward API) rather
    # than the 0.0.0.0 bind host, so the server/peers can reach this worker
    # (the registered url/worker_id and kv endpoints all derive from this).
    if args.discovery_backend == "kubernetes" and not args.advertise_host:
        pod_ip = os.environ.get("POD_IP")
        if pod_ip:
            args.advertise_host = pod_ip
            logger.info("k8s discovery: advertising Pod IP %s", pod_ip)

    # Fail fast on disagg configs that silently break across nodes: a
    # non-routable advertise host, or no explicit RDMA transfer backend
    # (which risks a silent TCP fallback). No-op for mixed workers.
    is_disagg = args.server_args.disaggregation_mode in ("prefill", "decode")
    validate_advertise_host(args.advertise_host or args.server_args.host, is_disagg=is_disagg)
    validate_sglang_transport(
        getattr(args.server_args, "disaggregation_transfer_backend", None),
        is_disagg=is_disagg,
        allow_tcp=args.disaggregation_allow_tcp,
    )

    # Optional infera-kvd HiCacheStorage wiring. Done BEFORE engine.start()
    # because SGLang's launch_server reads server_args once at startup, and
    # we need to register the backend with the storage factory before any
    # subprocess opens it.
    await awire_infera_kvd_backend(args)

    # Ionic RoCE-v2 RDMA env defaults for the Mooncake/MoRI transfer engines
    # (set-if-unset; an operator/launcher still overrides via env). Must run
    # BEFORE engine.start() spawns the sglang subprocess so it's inherited.
    # Without these the transfer engine silently falls back to TCP / hangs.
    from infera.engine.dsv4_gfx942 import apply_gfx942_dsv4
    from infera.engine.rocm_dsa_env import apply_rocm_dsa_env_defaults
    from infera.engine.rocm_rdma_env import (
        apply_kv_host_ip_default,
        apply_rocm_rdma_env_defaults,
    )

    apply_rocm_rdma_env_defaults()
    recovery_defaults = apply_pd_probe_recovery_defaults(
        getattr(args.server_args, "disaggregation_mode", None),
        getattr(args.server_args, "disaggregation_transfer_backend", None),
    )
    if recovery_defaults:
        logger.info(
            "Mooncake probe recovery defaults applied: %s",
            recovery_defaults,
        )
    # Disable sglang's CUDA-only DSA topk_v2 JIT on ROCm (set-if-unset), else every
    # non-DeepseekV4 DSA arch dies in CUDA-graph capture. See rocm_dsa_env.py.
    apply_rocm_dsa_env_defaults()
    # Pin the KV host IP to the RDMA rail (else get_ip() picks the public NIC and
    # KV transfer targets the wrong interface). Must follow the GID default above.
    apply_kv_host_ip_default()
    # MI325X (gfx942) + DeepSeek-V4: enforce the support matrix (raise on an
    # unsupported quant/engine combo) and apply the fp8 env + functional CLI
    # defaults (Flash also gets MTP). No-op on other arches / non-dsv4 models.
    args.sglang_argv = apply_gfx942_dsv4(
        args.server_args.model_path, engine="sglang", argv=args.sglang_argv
    )

    # Auto-size the mori-MoE dispatch buffer from --chunked-prefill-size so operators
    # only set the one documented knob (else sglang asserts on the prefill engine).
    _wire_mori_dispatch_buffer(args.server_args)

    # Prefill PD warmup is a /generate to 2.2.2.2 during FastAPI startup.
    # Load weights in parallel with decode and skip that warmup entirely.
    if should_wait_for_decode(
        getattr(args.server_args, "disaggregation_mode", None), args.wait_for_decode
    ):
        args.sglang_argv = ensure_skip_server_warmup(args.sglang_argv)
        # The barrier itself runs after the weights are in, so a discovery
        # config it could never resolve would cost one full load per restart.
        if _multinode_node_rank(args) == 0:
            ensure_barrier_discovery_is_reachable(
                args.discovery_backend,
                k8s_label_selector=args.k8s_label_selector,
                etcd_endpoint=args.etcd_endpoint,
            )
    # The decode's prefill probe also runs after the weights are in; fail an
    # unresolvable discovery config now, as the prefill does above.
    if (
        should_verify_prefill(
            getattr(args.server_args, "disaggregation_mode", None), args.wait_for_decode
        )
        and _multinode_node_rank(args) == 0
    ):
        ensure_barrier_discovery_is_reachable(
            args.discovery_backend,
            k8s_label_selector=args.k8s_label_selector,
            etcd_endpoint=args.etcd_endpoint,
        )

    if args.discovery_backend == "kubernetes":
        stale_registration = K8sRegistrationClient(namespace=args.k8s_namespace)
        await stale_registration.clear_stale_registration()

    engine = SglangEngine(
        args.server_args,
        sglang_argv=args.sglang_argv,
        advertise_host=args.advertise_host,
        enable_kv_events=args.enable_kv_events,
    )

    try:
        config = await engine.start()
    except Exception:
        logger.exception("engine failed to start; tearing down")
        try:
            await engine.stop()
        finally:
            _kill_process_group_safely()
        raise
    logger.info(
        "worker ready: model=%s url=http://%s:%d engine=%s disagg=%s meta=%s",
        config.model_name,
        config.host,
        config.port,
        config.engine,
        config.disagg_mode,
        config.disagg_meta,
    )

    await _run_started_engine(args, engine, config)


async def _run_started_engine(args: SglangWorkerArgs, engine: SglangEngine, config) -> None:
    """Supervise and tear down an engine that completed startup."""
    stop, death, death_task = _supervise_engine(engine)
    failed = False
    try:
        if await _run_startup_barrier_until_stop(args, config, stop):
            await _run_after_start(args, engine, config, stop)
    except BaseException:
        failed = True
        logger.exception("worker failed after engine start; tearing down")
        raise
    finally:
        death_task.cancel()
        try:
            await death_task
        except asyncio.CancelledError:
            pass
        try:
            await engine.stop()
        finally:
            if failed:
                _kill_process_group_safely()
        if not failed and death.exit_status is not None:
            raise SystemExit(death.exit_status)


async def _run_after_start(
    args: SglangWorkerArgs,
    engine: SglangEngine,
    config,
    stop: asyncio.Event,
) -> None:
    """Worker lifecycle once the sglang subprocess is up: KV plane,
    registration, then serve until shutdown. Raises on any setup failure so
    ``main`` can tear the engine down (avoids orphaning the subprocess tree).

    ``stop`` is already armed (signals + engine-death watch) before the
    decode barrier, so this function does not install a second watcher.
    """
    # --- Multinode follower gate ---
    # In a multi-node (LeaderWorkerSet) TP group only node-rank 0 runs the
    # serving HTTP API and should register; ranks > 0 are pure TP workers (their
    # sglang answers /health but cannot serve /v1/*). Registering them would let
    # the router proxy requests to a non-serving endpoint (404). So a follower
    # skips the KV plane + registration and just keeps its sglang subprocess
    # alive until shutdown. node-rank comes from sglang ServerArgs (set via the
    # injected --node-rank $LWS_WORKER_INDEX), with the LWS env as a fallback.
    node_rank = _multinode_node_rank(args)
    if node_rank > 0:
        logger.info(
            "multinode follower (node-rank %d): TP worker only; skipping KV plane "
            "+ registration (node-rank 0 serves and registers).",
            node_rank,
        )
        await stop.wait()
        return

    # --- KV plane (best-effort under auto, fatal under on, skipped under off) ---
    kv_wiring = await _maybe_start_kv_plane(args, engine, model_name=config.model_name)
    if kv_wiring is not None:
        config.kv = kv_wiring.metadata

    # --- KV-event NATS relay (opt-in) ---
    # In NATS mode, forward this worker's engine KV events onto the broker so
    # the router subscribes once instead of dialing our kv_events_endpoint.
    # No-op without --enable-kv-events (nothing to relay).
    kv_relay = None
    if args.kv_event_transport == "nats" and config.kv_events_endpoint:
        from infera.kv.nats_relay import KvEventNatsRelay

        # SGLang --dp-size multiplexes DP ranks on base_port + r; relay tails
        # each. Single-rank (dp_size None/1) stays rank 0.
        _dp = config.dp_size or 1
        if config.kv_block_size:
            kv_relay = KvEventNatsRelay(
                worker_id=f"{config.host}:{config.port}",
                engine_zmq_endpoint=config.kv_events_endpoint,
                engine=config.engine,
                block_size=config.kv_block_size,
                dp_size=_dp,
                multiplexed=_dp > 1,
                nats_url=args.nats_server,
            )
        else:
            # A missing block size is not a 1. Relaying events stamped
            # block_size=1 makes the router build a view the engine's real
            # events -- paged at 64 -- can never match: every one is rejected,
            # kv-aware degrades to load balancing, and nothing reports an
            # error. Not relaying at all costs the same routing and says so.
            logger.error(
                "KV NATS relay disabled: this worker resolved no KV page size, so its "
                "events cannot be indexed. kv-aware routing is off for it. Usually an "
                "unresolved --page-size; check /get_server_info."
            )
        if kv_relay is not None:
            try:
                await kv_relay.start()
            except Exception:
                logger.exception("KV NATS relay failed to start; continuing without it")
                kv_relay = None

    # --- Optional NATS request transport: run a consumer that proxies requests
    # from this worker's per-instance subject to the local engine HTTP. Advertise
    # request_transport=nats so the router publishes here instead of HTTP. ---
    config.request_transport = args.request_transport
    nats_req_server = None
    if args.request_transport == "nats":
        from infera.common.nats_request import NatsRequestServer

        worker_id = f"{config.host}:{config.port}"
        nats_req_server = NatsRequestServer(
            worker_id,
            config.port,
            url=args.nats_server,
            max_pending=args.nats_req_max_pending,
            idle_timeout=args.nats_req_idle_timeout,
            max_duration=args.nats_req_max_duration,
        )
        try:
            await nats_req_server.start()
        except Exception:
            logger.exception("NATS request consumer failed to start; registering as http instead")
            config.request_transport = "http"
            nats_req_server = None

    # --- Auto-registration (etcd or kubernetes) ---
    if args.discovery_backend == "kubernetes":
        logger.info("using kubernetes registration: namespace=%s", args.k8s_namespace or "<pod>")
        reg_client = K8sRegistrationClient(namespace=args.k8s_namespace)
    else:
        if not args.etcd_endpoint:
            raise SystemExit("--discovery-backend=etcd requires --etcd-endpoint")
        logger.info(
            "using etcd registration: endpoint=%s prefix=%s",
            args.etcd_endpoint,
            args.etcd_prefix,
        )
        reg_client = RegistrationClient(
            endpoint=args.etcd_endpoint,
            prefix=args.etcd_prefix,
        )

    # --- Re-anchor the KV-event chain before anyone can route here ---
    # The engine's warmup already wrote its radix tree and published the one
    # rooted event, to nobody: the relay above only just subscribed. Flushing
    # now re-emits an anchor the relay can actually see. This slot is the whole
    # reason it is cheap -- unregistered, the worker takes no traffic, so the
    # discarded prefix cache is warmup's alone and the engine is idle enough to
    # accept the flush. See infera/engine/flush.py.
    #
    # Skipped for a leg that cannot emit the clear event we would then wait for:
    # the loop's budget would be spent in full, right before register(), and the
    # give-up warning would blame a missing anchor on a leg that has no chain.
    if kv_relay is not None:
        no_clear = no_clear_event_reason(args)
        if no_clear is not None:
            logger.info(
                "kv events: not flushing this worker's cache -- %s. Its KV view "
                "comes from the prefill leg; nothing here needs re-anchoring.",
                no_clear,
            )
        else:
            await anchor_kv_chain(
                host=config.host,
                port=config.port,
                engine=config.engine,
                observed=kv_relay.cleared_observed,
            )

    await reg_client.register(config)
    hb_task = asyncio.create_task(reg_client.heartbeat_loop(), name="worker-heartbeat")
    # Opened only now, so a rollout waiting on this pod's readiness waits for
    # a worker the router can actually reach -- the engine's /health has been
    # answering since before the PD barrier ran.
    ready_server = await serve_readiness_best_effort(
        engine_alive=engine_health_check(args.server_args.host, config.port)
    )

    await stop.wait()

    # Closed before deregistration rather than after draining: this is the
    # signal a surge rollout reads, and it should stop claiming readiness the
    # moment shutdown begins, not once in-flight work has finished.
    await close_readiness(ready_server)

    # Stop the heartbeat before touching the record: it re-asserts registration
    # from config, so a refresh landing after deregistration would put the
    # worker straight back into the pool.
    hb_task.cancel()
    try:
        await hb_task
    except asyncio.CancelledError:
        pass

    async def _drain() -> None:
        if nats_req_server is not None:
            await nats_req_server.stop(drain=True, drain_timeout=args.drain_timeout)
        else:
            # HTTP transport: the router talks straight to the engine, so infera
            # never saw these requests and has to ask the engine what is still
            # in flight.
            await drain_engine_inflight(
                host=config.host,
                port=config.port,
                engine=config.engine,
                timeout=args.drain_timeout,
            )

    # Deregister before draining, on every backend: removing the record is what
    # stops new work arriving, and waiting on in-flight work while still being
    # dispatched to just races arrivals.
    #
    # On Kubernetes the registry does drop a Pod on its deletionTimestamp, well
    # before this process is signalled -- but only when the Pod is being
    # deleted. A liveness-probe restart, a node graceful shutdown or a manual
    # kill all deliver SIGTERM with the Pod object untouched, and on those paths
    # the annotation is still there and still parsed, so this worker stays
    # routable until it clears it. Draining first would hand it new work for the
    # whole drain window.
    #
    # The cost is that the worker is gone from /v1/workers while it finishes,
    # rather than visibly draining.
    if not await reg_client.deregister():
        # deregister() already logged why, including whether it matters here.
        logger.warning("draining anyway")
    await _drain()

    if kv_relay is not None:
        await kv_relay.stop()

    if kv_wiring is not None:
        await kv_wiring.stop()


if __name__ == "__main__":
    asyncio.run(main())
