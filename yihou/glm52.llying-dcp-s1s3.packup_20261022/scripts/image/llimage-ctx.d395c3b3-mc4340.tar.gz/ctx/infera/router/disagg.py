###############################################################################
# Copyright (c) 2026, Advanced Micro Devices, Inc. All rights reserved.
#
# SPDX-License-Identifier: MIT
###############################################################################
from __future__ import annotations

import asyncio
import json
import logging
import random
from functools import partial

import anyio
import httpx
from fastapi import Response
from fastapi.responses import JSONResponse, StreamingResponse

from infera.common.nats_request import TYPE_DATA, TYPE_DONE, TYPE_ERROR
from infera.common.worker_pool import DisaggMode
from infera.router.base import BaseRouter
from infera.router.breaker import is_worker_fault
from infera.router.cache_control import parse_cache_hints
from infera.router.disagg_protocols import (
    ProtocolMismatch,
    UnknownProtocol,
    resolve_protocol,
)
from infera.router.dp_routing import (
    align_room_to_prefill_rank,
    dp_rank_header,
    inject_disagg_prefill_dp_rank,
    inject_dp_rank,
)
from infera.router.engine_priority import inject_engine_priority
from infera.router.pd_abort import (
    abort_engine_request,
    abort_request_ids,
    prefill_drain_timeout_s,
)
from infera.router.policy.target import RouteTarget
from infera.server import metrics

logger = logging.getLogger(__name__)


def _sanitized_error(reason: str, exc: BaseException, *, status_code: int) -> JSONResponse:
    """Return a client-safe error response while logging the full exception.

    Interpolating ``str(exc)`` into an HTTP response can leak internal details
    or stack information to the caller (CodeQL ``py/stack-trace-exposure``).
    The exception is logged server-side for debugging; the client receives
    only the generic ``reason``.
    """
    logger.warning("%s (%s: %s)", reason, type(exc).__name__, exc)
    return JSONResponse(content={"error": reason}, status_code=status_code)


def _generate_room_id() -> int:
    """Random u63 ID for the per-request session (SGLang's bootstrap_room,
    vLLM connectors' transfer_id)."""
    return random.randrange(2**63)


def _rid_header(proto_name: str) -> str:
    """Header the engine adopts the forged request id from.

    SGLang only honours ``x-override-rid``; it ignores ``X-Request-Id``, so a
    rid sent that way never becomes the scheduler's rid and ``/abort_request``
    has nothing to match. vLLM and MoRIIO connectors read ``X-Request-Id``.
    """
    return _SGLANG_RID_HEADER if proto_name == _SGLANG_BOOTSTRAP else _REQUEST_ID_HEADER


def _leg_headers(
    forged_id: str | None,
    target: RouteTarget,
    *,
    proto_name: str,
    session_headers: dict[str, str] | None = None,
) -> dict[str, str] | None:
    """Client session headers (if any) + shared forged request id (if any) +
    this leg's DP-rank pin."""
    headers: dict[str, str] = dict(session_headers or {})
    if forged_id:
        headers[_rid_header(proto_name)] = forged_id
    headers.update(dp_rank_header(target) or {})
    return headers or None


def _sample_count(body: dict) -> int:
    """Return the positive OpenAI parallel-sampling count."""
    value = body.get("n", 1)
    return value if isinstance(value, int) and not isinstance(value, bool) and value > 0 else 1


DEFAULT_PATH = "/v1/chat/completions"
RESPONSES_PATH = "/v1/responses"
_SGLANG_BOOTSTRAP = "sglang-bootstrap"
# SGLang's own override header; every other protocol's engine reads the
# generic one. Named so a rename breaks loudly instead of silently dropping
# the forged rid.
_SGLANG_RID_HEADER = "x-override-rid"
_REQUEST_ID_HEADER = "X-Request-Id"
_DONE_MARKER = b"data: [DONE]"
_RESPONSES_COMPLETED_MARKER = b"event: response.completed"


def _terminal_marker(path: str) -> bytes:
    """SSE bytes that mark a successful end of stream for this endpoint.

    SGLang closes an OpenAI Responses stream with the completion event and
    never sends the chat-completions sentinel, so matching ``[DONE]`` there
    reads a finished response as truncated.
    """
    return _RESPONSES_COMPLETED_MARKER if path == RESPONSES_PATH else _DONE_MARKER


def _with_responses_request_id(
    body: dict,
    proto_name: str,
    path: str,
    forged_id: str | None,
) -> dict:
    """Carry the forged rid as ``request_id`` on SGLang's Responses endpoint.

    ``ResponsesRequest`` has no ``rid`` field and drops it; ``request_id`` is
    the field ``serving_responses`` hands the scheduler, so it is the id
    ``/abort_request`` matches.
    """
    if not forged_id or path != RESPONSES_PATH or proto_name != _SGLANG_BOOTSTRAP:
        return body
    return {**body, "request_id": forged_id}


class DisaggRouter(BaseRouter):
    """Dual-dispatch router for PD-disaggregated workers.

    Delegates body shaping to a ``DisaggProtocol`` resolved from the
    workers' ``disagg_meta["protocol"]`` tag. Router owns connection
    lifecycle, retries, and metrics; protocols are pure functions over
    request bodies.

    Two topologies, picked from ``proto.topology``:
      - ``concurrent``: POST P and D in parallel, stream D back, drain
        P in the background (SGLang, vLLM-mooncake).
      - ``serial-pull``: POST P, await its response, extract handoff
        fields, then POST D (vLLM-mori-read, vLLM-nixl).
    """

    # Pre-flight decode POST is idempotent (engine hasn't parsed the
    # body yet, otherwise it would have started responding), so retry
    # on transport errors. Never retry after any chunk has arrived —
    # engine has committed work and a retry would double-bill.
    _DECODE_OPEN_MAX_RETRIES = 3
    _DECODE_OPEN_INITIAL_BACKOFF_S = 0.05
    _DECODE_OPEN_MAX_BACKOFF_S = 0.5
    # Cap on the shielded close of a decode stream, so a socket that refuses
    # to shut down cannot hold the request's policy slot.
    _STREAM_CLOSE_TIMEOUT_S = 1.0

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        # No connection cap: each request holds two long-lived streams
        # (P + D), so a cap below 2*concurrency deadlocks. Keep-alive off:
        # reusing an idle connection raced engine-side timeout_keep_alive=5
        # — write onto a half-closed socket, decode never lands, but prefill
        # already registered the bootstrap_room → decode hangs on KVPoll for
        # the 300s mooncake timeout.
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(None, connect=60.0),
            limits=httpx.Limits(
                max_connections=None,
                max_keepalive_connections=0,
            ),
        )
        # Strong refs to in-flight prefill POSTs: create_task only holds a
        # weak ref, so a GC'd task aborts the half-sent request
        # (KVTransferError → decode hangs on KVPoll 300s).
        self._pending_prefill_tasks: set[asyncio.Task] = set()

    async def aclose(self) -> None:
        await self._client.aclose()

    def _track_prefill_task(self, task: asyncio.Task) -> asyncio.Task:
        """Keep a detached prefill alive and consume an unobserved exception."""
        self._pending_prefill_tasks.add(task)

        def _done(done: asyncio.Task) -> None:
            self._pending_prefill_tasks.discard(done)
            if not done.cancelled():
                done.exception()

        task.add_done_callback(_done)
        return task

    async def _abort_worker_request(self, worker, rid: str | None, n: int) -> None:
        """Abort one SGLang worker over its registered request transport."""
        if not rid:
            return
        if worker.request_transport != "nats":
            await abort_engine_request(self._client, worker.url, rid, n=n)
            return
        if self.nats_client is None:
            logger.warning("cannot abort NATS worker %s without a NATS client", worker.worker_id)
            return
        for request_id in abort_request_ids(rid, n):
            payload = {
                "path": "/abort_request",
                "stream": False,
                "headers": None,
                "body": {"rid": request_id},
            }
            try:
                async for kind, status, data in self.nats_client.stream(worker.worker_id, payload):
                    if kind == TYPE_ERROR:
                        logger.warning(
                            "PD abort over NATS worker=%s rid=%s failed: %s",
                            worker.worker_id,
                            request_id,
                            data[:200],
                        )
                    elif kind == TYPE_DONE and status and status >= 400:
                        logger.warning(
                            "PD abort over NATS worker=%s rid=%s returned %d",
                            worker.worker_id,
                            request_id,
                            status,
                        )
            except Exception as exc:
                logger.warning(
                    "PD abort over NATS worker=%s rid=%s failed: %s",
                    worker.worker_id,
                    request_id,
                    exc,
                )

    async def _abort_pair(self, p, d, rid: str | None, n: int) -> None:
        """Abort both SGLang legs without assuming their request transport."""
        if not rid:
            return
        await asyncio.gather(
            self._abort_worker_request(p, rid, n),
            self._abort_worker_request(d, rid, n),
        )

    async def _finish_prefill(
        self,
        p_task: asyncio.Task,
        p,
        d,
        rid: str | None,
        n: int,
        *,
        abort: bool,
    ) -> None:
        """Wait for the prefill POST, or abort it on client drop / timeout."""
        if abort:
            # Cancelling the POST closes the prefill connection, which is the
            # only drop signal for connectors with no remote abort endpoint
            # (vLLM, ATOM). A forged rid additionally lets both engines drop
            # the request by id, so it is an extra step, not a precondition.
            p_task.cancel()
            if rid:
                await self._abort_pair(p, d, rid, n)
            return
        timeout = prefill_drain_timeout_s()
        try:
            if timeout > 0:
                p_resp = await asyncio.wait_for(asyncio.shield(p_task), timeout=timeout)
            else:
                p_resp = await asyncio.shield(p_task)
        except asyncio.TimeoutError:
            # A drain that never lands is the wedged prefill this breaker
            # exists for, whether or not the protocol gave us a rid to abort
            # by: with no rid the request cannot even be reclaimed.
            metrics.pd_bootstrap_failures_total.labels(reason="prefill_drain_timeout").inc()
            self.breaker.record_failure(p.worker_id)
            p_task.cancel()
            if rid:
                logger.warning(
                    "prefill drain timed out after %.0fs; aborting rid=%s",
                    timeout,
                    rid,
                )
                await self._abort_pair(p, d, rid, n)
            else:
                logger.warning(
                    "prefill drain timed out after %.0fs; protocol has no abort "
                    "request id, closing the drain connection",
                    timeout,
                )
            return
        except asyncio.CancelledError:
            # The waiter is cancelled, not the shielded prefill POST. abort=False
            # means decode already finished: tearing the pair down would abort a
            # request the client already accepted.
            raise
        except Exception as exc:
            logger.warning(
                "prefill leg %s failed: %s: %s",
                p.url,
                type(exc).__name__,
                exc or "<no message>",
            )
            metrics.pd_bootstrap_failures_total.labels(reason="prefill_exception").inc()
            self.breaker.record_failure(p.worker_id)
            return
        p_status = getattr(p_resp, "status_code", None)
        if p_status is None:
            return
        if p_status >= 400:
            logger.warning(
                "prefill leg %s returned %d (decode will hang on KVPoll)",
                p.url,
                p_status,
            )
            metrics.pd_bootstrap_failures_total.labels(reason="prefill_5xx").inc()
        self._score_leg(p.worker_id, p_status)

    async def _release_prefill_drain(
        self,
        p_task: asyncio.Task,
        p,
        d,
        rid: str | None,
        n: int,
        *,
        abort: bool,
    ) -> None:
        """Run ``_finish_prefill`` without letting its failure reach the caller.

        A cancel is left to propagate: callers release their inflight
        accounting from a ``finally`` of their own, so swallowing it here would
        only strand the task cancelled-but-not-raising.
        """
        try:
            await self._finish_prefill(p_task, p, d, rid, n, abort=abort)
        except Exception:
            pass

    async def dispatch(
        self,
        body: dict,
        *,
        stream: bool,
        path: str = "/v1/chat/completions",
    ) -> Response:
        model = body.get("model")
        with metrics.track_request(router="disagg", model=str(model or "")) as obs:
            prefills = self.pool.list_active(model=model, mode=DisaggMode.PREFILL)
            decodes = self.pool.list_active(model=model, mode=DisaggMode.DECODE)
            # Independently per role: a wedged prefill and a wedged decode are
            # different events against different pools, and one open breaker
            # must not remove the other role's healthy workers.
            prefills = self.breaker.filter(prefills)
            decodes = self.breaker.filter(decodes)
            if not prefills or not decodes:
                obs["outcome"] = metrics.outcome_label(503)
                metrics.pd_bootstrap_failures_total.labels(reason="no_pd_workers").inc()
                return JSONResponse(
                    content={"error": f"need both prefill and decode workers for model={model!r}"},
                    status_code=503,
                )

            # role_hint lets cost-aware policies weight P (cache-heavy: a hit
            # skips prefill) vs D (load-heavy) differently.
            p_target, p_blocks = self.policy.pick(prefills, body, role_hint="prefill")
            d_target, d_blocks = self.policy.pick(decodes, body, role_hint="decode")
            for target, role in ((p_target, "prefill"), (d_target, "decode")):
                obs.on_failure(
                    partial(self.policy.on_request_failed, target.route_key, body, role_hint=role)
                )
            return await self._dispatch_pd(
                obs, p_target, d_target, p_blocks, d_blocks, body, stream, path
            )

    async def dispatch_direct(
        self,
        body: dict,
        *,
        stream: bool,
        path: str,
        prefill_id: str,
        decode_id: str,
    ) -> Response:
        """PD dispatch with workers already chosen upstream (GAIE EPP direct
        mode). Looks the prefill/decode workers up by id and runs the same
        protocol/topology/transport machinery as :meth:`dispatch`, but skips
        ``policy.pick`` — selection happened in the EPP. Empty block lists make
        the policy in-flight refcounting a no-op (the EPP owns bookkeeping)."""
        with metrics.track_request(router="disagg", model=str(body.get("model") or "")) as obs:
            p = self.pool.get(prefill_id)
            d = self.pool.get(decode_id)
            if p is None or d is None:
                obs["outcome"] = metrics.outcome_label(503)
                metrics.pd_bootstrap_failures_total.labels(reason="direct_worker_missing").inc()
                missing = prefill_id if p is None else decode_id
                return JSONResponse(
                    content={
                        "error": f"PD worker {missing!r} from gateway not found (stale routing?)"
                    },
                    status_code=503,
                )
            return await self._dispatch_pd(
                obs, RouteTarget(p), RouteTarget(d), [], [], body, stream, path
            )

    def _score_leg_headers(self, worker_id: str, status: int) -> None:
        """Score a streaming leg from its response headers.

        Headers are the pre-first-byte moment, so a failure recorded here is
        exactly what the breaker wants. Success is not: a 200 header says the
        request was accepted, nothing more, and the worker this class exists to
        catch is the one that accepts a request and then produces nothing. That
        profile would otherwise be scored as recovery -- resetting the failure
        count and closing an open breaker -- so a 2xx is neutral here and the
        success is recorded once the stream has actually delivered something.
        """
        if status < 400:
            self.breaker.record_neutral(worker_id)
        else:
            self._score_leg(worker_id, status)

    def _score_leg(self, worker_id: str, status: int) -> None:
        """Record one PD leg's HTTP outcome against the worker that produced it.

        The two legs are two different workers whose health is independent, so
        each has to be scored from its own response. A decode that answers
        cannot vouch for a prefill that did not: scoring both off one status
        code let a prefill 500-ing every request be reset to healthy by the
        decode leg beside it, and there is no status code at all for the
        client-facing streaming response, whose 200 is a framework default set
        before either leg has been dispatched.

        A 5xx is the worker's fault. A 4xx is the request's -- every worker
        would answer the same, so it frees the probe slot without counting
        either way. Anything below 400 is the evidence of health that resets
        the consecutive-failure count.
        """
        if is_worker_fault(status):
            self.breaker.record_failure(worker_id)
        elif status < 400:
            self.breaker.record_success(worker_id)
        else:
            self.breaker.record_neutral(worker_id)

    async def _dispatch_pd(
        self,
        obs,
        p_target: RouteTarget,
        d_target: RouteTarget,
        p_blocks: list[int],
        d_blocks: list[int],
        body: dict,
        stream: bool,
        path: str,
    ) -> Response:
        """Run the PD dual-dispatch for already-selected prefill/decode targets:
        resolve the protocol, forge the bootstrap room/request id, and hand off
        to the concurrent or serial-pull dispatcher. Shared by the policy-driven
        :meth:`dispatch` and the gateway-driven :meth:`dispatch_direct`."""
        p, d = p_target.worker, d_target.worker
        # Both legs of one request travel the same channel: the dispatchers
        # pick HTTP or NATS for the pair, not per leg. Refuse before any
        # accounting or dispatch rather than silently sending a NATS worker's
        # leg over HTTP, where nothing is listening and decode waits out its
        # KV timeout.
        if p.request_transport != d.request_transport:
            obs["outcome"] = metrics.outcome_label(503)
            metrics.pd_bootstrap_failures_total.labels(reason="mixed_request_transport").inc()
            return JSONResponse(
                content={
                    "error": (
                        "PD pair must share one request transport: prefill "
                        f"{p.worker_id} is {p.request_transport!r}, decode "
                        f"{d.worker_id} is {d.request_transport!r}"
                    )
                },
                status_code=503,
            )
        try:
            proto = resolve_protocol(p, d)
        except (ProtocolMismatch, UnknownProtocol) as exc:
            obs["outcome"] = metrics.outcome_label(500)
            metrics.pd_bootstrap_failures_total.labels(reason="protocol_unresolved").inc()
            return _sanitized_error("protocol resolution failed", exc, status_code=500)

        # SGLang's follow_bootstrap_room balancer ties the prefill DP rank to
        # bootstrap_room % dp_size; encode the steered rank so the prefill
        # sender's consistency check passes (no engine env var needed).
        room_id = align_room_to_prefill_rank(_generate_room_id(), p_target)

        base = dict(body)
        hints = base.pop("_infera_cache_hints", None) or parse_cache_hints(body)
        base.pop("_infera_request_id", None)
        session_headers = base.pop("_infera_session_headers", None)
        base.pop("_infera_direct_worker", None)
        base.pop("_infera_direct_prefill", None)

        p_url = f"{p.url}{path}"
        d_url = f"{d.url}{path}"

        # Fallback ISL for the streaming path, where the reply carries no usage.
        obs.observe_blocks(p_blocks, p.kv_block_size)
        obs.set_workers(prefill_worker=p.worker_id, decode_worker=d.worker_id)

        # request_id_for may raise (e.g. malformed disagg_meta); compute before
        # on_request_started so no started/finished bookkeeping is needed on
        # the failure path.
        try:
            forged_id = proto.request_id_for(p, d, room_id)
        except ValueError as exc:
            obs["outcome"] = metrics.outcome_label(500)
            metrics.pd_bootstrap_failures_total.labels(reason="protocol_request_id_failed").inc()
            return _sanitized_error("protocol request-id generation failed", exc, status_code=500)

        self.policy.on_request_started(p_target.route_key, p_blocks)
        self.policy.on_request_started(d_target.route_key, d_blocks)

        dispatcher = (
            self._dispatch_concurrent if proto.topology == "concurrent" else self._dispatch_serial
        )
        return await dispatcher(
            obs,
            proto,
            base,
            hints,
            p_target,
            p_blocks,
            p_url,
            d_target,
            d_blocks,
            d_url,
            room_id,
            stream,
            forged_id,
            path=path,
            session_headers=session_headers,
        )

    async def _dispatch_concurrent(
        self,
        obs,
        proto,
        base,
        hints,
        p_target,
        p_blocks,
        p_url,
        d_target,
        d_blocks,
        d_url,
        room_id,
        stream,
        forged_id: str | None,
        *,
        path: str = DEFAULT_PATH,
        session_headers: dict[str, str] | None = None,
    ) -> Response:
        p, d = p_target.worker, d_target.worker
        p_headers = _leg_headers(
            forged_id, p_target, proto_name=proto.name, session_headers=session_headers
        )
        d_headers = _leg_headers(
            forged_id, d_target, proto_name=proto.name, session_headers=session_headers
        )
        try:
            p_body = inject_engine_priority(
                proto.annotate_prefill(base, p, d, room_id), hints, p.engine
            )
            d_body = inject_disagg_prefill_dp_rank(
                inject_engine_priority(
                    proto.annotate_decode(base, p, d, room_id, None), hints, d.engine
                ),
                prefill_target=p_target,
                decode_engine=d.engine,
            )
        except ValueError as exc:
            self.policy.on_request_finished(p_target.route_key, p_blocks)
            self.policy.on_request_finished(d_target.route_key, d_blocks)
            obs["outcome"] = metrics.outcome_label(500)
            metrics.pd_bootstrap_failures_total.labels(reason="protocol_annotate_failed").inc()
            return _sanitized_error("protocol annotation failed", exc, status_code=500)

        p_body = _with_responses_request_id(p_body, proto.name, path, forged_id)
        d_body = _with_responses_request_id(d_body, proto.name, path, forged_id)
        p_body = inject_dp_rank(p_body, p_target)
        d_body = inject_dp_rank(d_body, d_target)

        # Deliver both legs over NATS when both workers registered for it. KV
        # transfer stays engine<->engine (bootstrap_room in the bodies), so the
        # delivery channel doesn't matter; just publish each body and stream D.
        if (
            self.nats_client is not None
            and p.request_transport == "nats"
            and d.request_transport == "nats"
        ):
            # Optional admission throttle (INFERA_NATS_REQ_MAX_PENDING): refuse
            # if either leg's worker is at its in-NATS backlog limit.
            if not (
                await self.nats_client.admit(p.worker_id)
                and await self.nats_client.admit(d.worker_id)
            ):
                self.policy.on_request_finished(p_target.route_key, p_blocks)
                self.policy.on_request_finished(d_target.route_key, d_blocks)
                obs["outcome"] = metrics.outcome_label(429)
                return JSONResponse(
                    content={"error": "PD worker request backlog over limit"},
                    status_code=429,
                    headers={"Retry-After": "1"},
                )
            return await self._concurrent_nats(
                obs,
                p_target,
                p_blocks,
                d_target,
                d_blocks,
                p_body,
                d_body,
                stream,
                p_headers,
                d_headers,
                path=path,
            )

        if stream:
            obs["outcome"] = "ok"  # commit at hand-off
            obs.claim_stream()
            return StreamingResponse(
                self._stream_dual(
                    obs,
                    p_target,
                    p_blocks,
                    d_target,
                    d_blocks,
                    p_url,
                    d_url,
                    p_body,
                    d_body,
                    p_headers,
                    d_headers,
                    path=path,
                ),
                media_type="text/event-stream",
            )

        try:

            async def _post(url, leg, worker_id, leg_body, leg_headers):
                with metrics.track_pd_leg(leg=leg, worker_id=worker_id):
                    return await self._client.post(url, json=leg_body, headers=leg_headers)

            # Gathered with return_exceptions so a failure can be attributed to
            # the leg that produced it. Letting gather raise surfaces whichever
            # one failed first with no way to tell which that was, and blaming a
            # fixed leg means a decode outage evicts the healthy prefill worker
            # while the broken decode is never scored at all.
            p_resp, d_resp = await asyncio.gather(
                _post(p_url, "prefill", p.worker_id, p_body, p_headers),
                _post(d_url, "decode", d.worker_id, d_body, d_headers),
                return_exceptions=True,
            )
            failed = None
            for worker_id, leg, result in (
                (p.worker_id, "prefill", p_resp),
                (d.worker_id, "decode", d_resp),
            ):
                if isinstance(result, BaseException):
                    self.breaker.record_failure(worker_id)
                    if failed is None:
                        failed = (leg, result)
                else:
                    self._score_leg(worker_id, result.status_code)
            pair_failed = failed is not None or any(
                not isinstance(result, BaseException) and result.status_code >= 500
                for result in (p_resp, d_resp)
            )
            if pair_failed:
                await self._abort_pair(
                    p,
                    d,
                    p_body.get("rid"),
                    _sample_count(p_body),
                )
            if failed is not None:
                leg, exc = failed
                if not isinstance(exc, httpx.HTTPError):
                    raise exc
                obs["outcome"] = metrics.outcome_label(502)
                metrics.pd_bootstrap_failures_total.labels(reason="worker_unreachable").inc()
                return _sanitized_error(f"PD {leg} leg failed", exc, status_code=502)
            if p_resp.status_code >= 400:
                logger.warning(
                    "prefill worker %s returned %d (decode may fail)",
                    p.worker_id,
                    p_resp.status_code,
                )
                metrics.pd_bootstrap_failures_total.labels(reason="prefill_5xx").inc()

            try:
                payload = d_resp.json()
            except ValueError:
                obs["outcome"] = metrics.outcome_label(502)
                return JSONResponse(
                    content={
                        "error": f"decode worker {d.worker_id} returned non-JSON",
                        "raw": d_resp.text[:500],
                    },
                    status_code=502,
                )
            obs["outcome"] = metrics.outcome_label(d_resp.status_code)
            obs.observe_usage(payload)
            return JSONResponse(content=payload, status_code=d_resp.status_code)
        except asyncio.CancelledError:
            # The client dropped: cancelling the POSTs closes our sockets but
            # tells neither engine, so both keep the request inflight (prefill
            # until its KV transfer timeout). Abort under a shield, since the
            # cleanup itself is an await on a cancelled path.
            with anyio.CancelScope(shield=True):
                await self._abort_pair(p, d, p_body.get("rid"), _sample_count(p_body))
            raise
        finally:
            self.policy.on_request_finished(p_target.route_key, p_blocks)
            self.policy.on_request_finished(d_target.route_key, d_blocks)

    def _start_prefill_drain_nats(self, p, p_payload):
        """Fire the prefill leg over NATS and drain its reply in the background.
        Must run to completion (never cancel): the prefill engine needs the full
        request to register the bootstrap_room and push KV to decode, exactly
        like the HTTP path. Strong ref guards against GC mid-flight."""

        async def _drain():
            # Scored here for the same reason the HTTP legs are scored at their
            # own responses: this transport never touches the HTTP client, so
            # nothing else observes how this worker did.
            try:
                async for kind, st, data in self.nats_client.stream(p.worker_id, p_payload):
                    if kind == TYPE_ERROR:
                        logger.warning("prefill leg (nats) %s failed: %s", p.worker_id, data[:200])
                        metrics.pd_bootstrap_failures_total.labels(reason="prefill_exception").inc()
                        self.breaker.record_failure(p.worker_id)
                        return
                    if kind == TYPE_DONE:
                        # `done` means the request finished, not that it
                        # succeeded: the worker proxies whatever its engine
                        # returned, so a 500 arrives here exactly as a 200 does.
                        # Scoring on the frame alone read every failed prefill
                        # as health -- on the one leg whose reply is discarded,
                        # so nothing else would ever notice.
                        status = st or 200
                        if status >= 400:
                            logger.warning(
                                "prefill leg (nats) %s returned %d (decode may hang on KVPoll)",
                                p.worker_id,
                                status,
                            )
                            metrics.pd_bootstrap_failures_total.labels(
                                reason="prefill_status"
                            ).inc()
                        self._score_leg(p.worker_id, status)
                        return
            except Exception as exc:
                logger.warning("prefill nats drain %s failed: %s", p.worker_id, exc)
                self.breaker.record_failure(p.worker_id)

        return self._track_prefill_task(asyncio.create_task(_drain(), name="nats-prefill-drain"))

    async def _concurrent_nats(
        self,
        obs,
        p_target,
        p_blocks,
        d_target,
        d_blocks,
        p_body,
        d_body,
        stream,
        p_headers,
        d_headers,
        *,
        path: str = DEFAULT_PATH,
    ) -> Response:
        """Concurrent PD over NATS: publish p_body to prefill + d_body to decode
        on their per-instance subjects, stream decode back. KV transfer is
        engine<->engine (mori) via the bootstrap_room in the bodies."""
        p, d = p_target.worker, d_target.worker
        p_payload = {"path": path, "stream": False, "headers": p_headers, "body": p_body}
        d_payload = {"path": path, "stream": stream, "headers": d_headers, "body": d_body}
        p_task = self._start_prefill_drain_nats(p, p_payload)
        n = _sample_count(p_body)

        if stream:
            obs["outcome"] = "ok"
            obs.claim_stream()
            return StreamingResponse(
                self._stream_dual_nats(
                    obs,
                    p_target,
                    p_blocks,
                    d_target,
                    d_blocks,
                    d_payload,
                    p_task,
                    rid=p_body.get("rid"),
                    n=n,
                ),
                media_type="text/event-stream",
            )

        pair_failed = False
        cancelled = False
        try:
            chunks: list[bytes] = []
            status = 200
            async for kind, st, data in self.nats_client.stream(d.worker_id, d_payload):
                if kind == TYPE_DATA:
                    chunks.append(data)
                elif kind == TYPE_ERROR:
                    # st carries 504 on inactivity timeout; worker errors -> 502.
                    code = st or 502
                    pair_failed = True
                    self._score_leg(d.worker_id, code)
                    obs["outcome"] = metrics.outcome_label(code)
                    return JSONResponse(
                        content={
                            "error": f"decode {d.worker_id} nats failed",
                            "raw": data[:500].decode("utf-8", "replace"),
                        },
                        status_code=code,
                    )
                else:  # done
                    status = st or 200
                    pair_failed = status >= 500
                    break
            raw = b"".join(chunks)
            try:
                payload = json.loads(raw) if raw else {}
            except ValueError:
                pair_failed = True
                obs["outcome"] = metrics.outcome_label(502)
                return JSONResponse(
                    content={
                        "error": f"decode {d.worker_id} non-JSON over nats",
                        "raw": raw[:500].decode("utf-8", "replace"),
                    },
                    status_code=502,
                )
            self._score_leg(d.worker_id, status)
            obs["outcome"] = metrics.outcome_label(status)
            obs.observe_usage(payload)
            return JSONResponse(content=payload, status_code=status)
        except asyncio.CancelledError:
            # The client dropped: our awaits are cancelled, but neither engine
            # hears about it, so both keep the request inflight. The cleanup is
            # itself an await on a cancelled path, hence the shield.
            cancelled = True
            with anyio.CancelScope(shield=True):
                await self._release_prefill_drain(
                    p_task,
                    p,
                    d,
                    p_body.get("rid"),
                    n,
                    abort=True,
                )
            raise
        finally:
            if not cancelled:
                if pair_failed:
                    await self._abort_pair(p, d, p_body.get("rid"), n)
                await self._release_prefill_drain(
                    p_task,
                    p,
                    d,
                    p_body.get("rid"),
                    n,
                    abort=False,
                )
            self.policy.on_request_finished(p_target.route_key, p_blocks)
            self.policy.on_request_finished(d_target.route_key, d_blocks)

    async def _stream_dual_nats(
        self,
        obs,
        p_target,
        p_blocks,
        d_target,
        d_blocks,
        d_payload,
        p_task,
        *,
        rid=None,
        n=1,
    ):
        """Stream decode's reply over NATS while prefill drains in background."""
        d = d_target.worker
        p = p_target.worker
        served = False
        completed = False
        try:
            async for kind, st, data in self.nats_client.stream(d.worker_id, d_payload):
                if kind == TYPE_DATA:
                    if data:
                        if not served:
                            # Bytes are flowing, so this worker is doing the
                            # work; an accepted request alone would not show it.
                            self.breaker.record_success(d.worker_id)
                            served = True
                        obs.observe_stream_chunk(data)
                        yield data
                elif kind == TYPE_ERROR:
                    logger.warning("decode (nats) %s stream failed: %s", d.worker_id, data[:200])
                    metrics.pd_bootstrap_failures_total.labels(reason="decode_stream_broken").inc()
                    if not served:
                        self.breaker.record_failure(d.worker_id)
                    obs.mark_failed()
                    yield (
                        f'data: {{"error":"decode {d.worker_id} nats stream failed"}}\n\n'
                    ).encode()
                    return
                else:  # done
                    # `done` means the request finished, not that it
                    # succeeded. A 5xx is the decode worker's fault and its
                    # pair still holds engine slots, so it is not a completion:
                    # the finally below aborts both legs. A 4xx is the
                    # request's fault and aborts nothing, as on the unary path.
                    status = st or 200
                    completed = status < 500
                    if not completed:
                        logger.warning(
                            "decode (nats) %s returned %d mid-stream",
                            d.worker_id,
                            status,
                        )
                        self._score_leg(d.worker_id, status)
                    return
        finally:
            if not completed:
                # An unfinished stream leaves both engines holding the request,
                # and the cancellation that ended it would cancel the abort too.
                with anyio.CancelScope(shield=True):
                    await self._release_prefill_drain(p_task, p, d, rid, n, abort=True)
            try:
                if completed:
                    # The client already has its answer; draining under a shield
                    # would pin the policy slots for the full drain timeout on a
                    # cancel that arrives after the stream ended.
                    await self._release_prefill_drain(p_task, p, d, rid, n, abort=False)
            finally:
                self.policy.on_request_finished(p_target.route_key, p_blocks)
                self.policy.on_request_finished(d_target.route_key, d_blocks)
                obs.close()

    async def _dispatch_serial(
        self,
        obs,
        proto,
        base,
        hints,
        p_target,
        p_blocks,
        p_url,
        d_target,
        d_blocks,
        d_url,
        room_id,
        stream,
        forged_id: str | None,
        *,
        path: str = DEFAULT_PATH,
        session_headers: dict[str, str] | None = None,
    ) -> Response:
        """Serial-pull topology: D needs handoff fields from P's response
        before its body can be assembled, so the two legs cannot be
        parallelised. Flow:

          1. ``annotate_prefill`` → POST P, await full JSON response.
          2. ``extract_handoff(P's body)`` → connector-specific dict
             (e.g. ``remote_block_ids``, ``remote_engine_id`` for MoRIIO).
          3. ``annotate_decode(handoff)`` → POST D, stream its response.

        On P 4xx/5xx we never call D — its body would be ill-formed and
        we'd just burn engine queue slots. ``track_pd_leg`` still wraps
        each leg so timings line up with the concurrent path.
        """
        p, d = p_target.worker, d_target.worker
        p_headers = _leg_headers(
            forged_id, p_target, proto_name=proto.name, session_headers=session_headers
        )
        d_headers = _leg_headers(
            forged_id, d_target, proto_name=proto.name, session_headers=session_headers
        )
        # P-leg first. Any failure here finishes BOTH workers (we never
        # call D, so D's slot is freed immediately). Once P succeeds we
        # finish P right away — serial-pull means it's truly done at
        # that point, no background task to drain.
        try:
            p_body = inject_engine_priority(
                proto.annotate_prefill(base, p, d, room_id), hints, p.engine
            )
            p_body = inject_dp_rank(p_body, p_target)
        except ValueError as exc:
            self.policy.on_request_finished(p_target.route_key, p_blocks)
            self.policy.on_request_finished(d_target.route_key, d_blocks)
            obs["outcome"] = metrics.outcome_label(500)
            metrics.pd_bootstrap_failures_total.labels(reason="protocol_annotate_failed").inc()
            return _sanitized_error("protocol annotation failed", exc, status_code=500)

        p_failed = False
        try:
            with metrics.track_pd_leg(leg="prefill", worker_id=p.worker_id):
                try:
                    p_resp = await self._client.post(p_url, json=p_body, headers=p_headers)
                except httpx.HTTPError as exc:
                    p_failed = True
                    obs["outcome"] = metrics.outcome_label(502)
                    metrics.pd_bootstrap_failures_total.labels(reason="prefill_unreachable").inc()
                    self.breaker.record_failure(p.worker_id)
                    return _sanitized_error("prefill leg failed", exc, status_code=502)
                except asyncio.CancelledError:
                    # The client dropped while the prefill was still running.
                    # Serial-pull holds both slots until the response lands, so
                    # both are released on the way out; the cancellation closes
                    # the prefill connection, which is how connectors with no
                    # remote abort endpoint learn to drop the request.
                    p_failed = True
                    raise

            self._score_leg(p.worker_id, p_resp.status_code)
            if p_resp.status_code >= 400:
                p_failed = True
                obs["outcome"] = metrics.outcome_label(p_resp.status_code)
                metrics.pd_bootstrap_failures_total.labels(
                    reason=f"prefill_{p_resp.status_code // 100}xx"
                ).inc()
                logger.warning(
                    "prefill worker %s returned %d in serial-pull; aborting",
                    p.worker_id,
                    p_resp.status_code,
                )
                return JSONResponse(
                    content={"error": (f"prefill {p_resp.status_code}: {p_resp.text[:500]}")},
                    status_code=p_resp.status_code,
                )

            try:
                p_payload = p_resp.json()
            except ValueError:
                p_failed = True
                obs["outcome"] = metrics.outcome_label(502)
                return JSONResponse(
                    content={
                        "error": f"prefill worker {p.worker_id} returned non-JSON",
                        "raw": p_resp.text[:500],
                    },
                    status_code=502,
                )

            try:
                handoff = proto.extract_handoff(p_payload)
            except (KeyError, ValueError) as exc:
                p_failed = True
                obs["outcome"] = metrics.outcome_label(502)
                metrics.pd_bootstrap_failures_total.labels(reason="handoff_extract_failed").inc()
                logger.warning("handoff extraction failed (%s: %s)", type(exc).__name__, exc)
                return JSONResponse(
                    content={
                        "error": "handoff extraction failed",
                        "prefill_payload": p_payload,
                    },
                    status_code=502,
                )
        finally:
            if p_failed:
                self.policy.on_request_finished(p_target.route_key, p_blocks)
                self.policy.on_request_finished(d_target.route_key, d_blocks)

        # P done & freed. From here on only D is in-flight.
        self.policy.on_request_finished(p_target.route_key, p_blocks)

        try:
            d_body = inject_disagg_prefill_dp_rank(
                inject_engine_priority(
                    proto.annotate_decode(base, p, d, room_id, handoff),
                    hints,
                    d.engine,
                ),
                prefill_target=p_target,
                decode_engine=d.engine,
            )
            d_body = inject_dp_rank(d_body, d_target)
        except ValueError as exc:
            self.policy.on_request_finished(d_target.route_key, d_blocks)
            obs["outcome"] = metrics.outcome_label(500)
            metrics.pd_bootstrap_failures_total.labels(reason="protocol_annotate_failed").inc()
            return _sanitized_error("protocol annotation failed", exc, status_code=500)

        if stream:
            obs["outcome"] = "ok"  # commit at hand-off
            obs.claim_stream()
            # No prefill task to babysit (already finished); D's stream
            # is self-contained. _stream_decode_only's finally finishes D.
            return StreamingResponse(
                self._stream_decode_only(
                    obs, d_target, d_blocks, d_url, d_body, d_headers, path=path
                ),
                media_type="text/event-stream",
            )

        try:
            with metrics.track_pd_leg(leg="decode", worker_id=d.worker_id):
                try:
                    d_resp = await self._client.post(d_url, json=d_body, headers=d_headers)
                except httpx.HTTPError as exc:
                    obs["outcome"] = metrics.outcome_label(502)
                    metrics.pd_bootstrap_failures_total.labels(reason="decode_unreachable").inc()
                    self.breaker.record_failure(d.worker_id)
                    return _sanitized_error("decode leg failed", exc, status_code=502)

            self._score_leg(d.worker_id, d_resp.status_code)
            try:
                d_payload = d_resp.json()
            except ValueError:
                obs["outcome"] = metrics.outcome_label(502)
                return JSONResponse(
                    content={
                        "error": f"decode worker {d.worker_id} returned non-JSON",
                        "raw": d_resp.text[:500],
                    },
                    status_code=502,
                )
            obs["outcome"] = metrics.outcome_label(d_resp.status_code)
            obs.observe_usage(d_payload)
            return JSONResponse(content=d_payload, status_code=d_resp.status_code)
        finally:
            self.policy.on_request_finished(d_target.route_key, d_blocks)

    async def _stream_decode_only(
        self,
        obs,
        d_target,
        d_blocks: list[int],
        d_url: str,
        d_body: dict,
        d_headers: dict[str, str] | None = None,
        *,
        path: str = DEFAULT_PATH,
    ):
        """Serial-pull streaming path — P has already finished and freed
        its scheduler slot, so all we need to do is stream D and not
        babysit a background prefill task. Reuses the same pre-flight
        retry + post-terminal-marker suppression as `_stream_dual` for parity.
        """
        d_resp: httpx.Response | None = None
        done_seen = False
        try:
            try:
                d_resp = await self._open_decode_stream(d_url, d_body, d_headers)
            except (httpx.TransportError, httpx.RemoteProtocolError) as exc:
                logger.warning(
                    "decode leg %s unreachable after %d retries: %s: %s",
                    d_url,
                    self._DECODE_OPEN_MAX_RETRIES,
                    type(exc).__name__,
                    exc or "<no message>",
                )
                metrics.pd_bootstrap_failures_total.labels(reason="decode_unreachable").inc()
                self.breaker.record_failure(d_target.worker.worker_id)
                err = json.dumps({"error": "decode unreachable"})
                obs.mark_failed()
                yield f"data: {err}\n\n".encode()
                return

            self._score_leg_headers(d_target.worker.worker_id, d_resp.status_code)
            if d_resp.status_code >= 400:
                try:
                    body_bytes = await d_resp.aread()
                except Exception:
                    body_bytes = b""
                logger.warning(
                    "decode leg %s returned %d before streaming: %r",
                    d_url,
                    d_resp.status_code,
                    body_bytes[:500],
                )
                metrics.pd_bootstrap_failures_total.labels(
                    reason=f"decode_{d_resp.status_code // 100}xx"
                ).inc()
                err = json.dumps(
                    {
                        "error": (
                            f"decode {d_resp.status_code}: "
                            f"{body_bytes.decode('utf-8', errors='replace')[:500]}"
                        )
                    }
                )
                obs.mark_failed()
                yield f"data: {err}\n\n".encode()
                return

            needle = _terminal_marker(path)
            tail_keep = len(needle) - 1
            tail = b""
            served = False
            try:
                async for chunk in d_resp.aiter_raw():
                    if not served and chunk:
                        # Bytes are flowing, so the worker is doing the work --
                        # which the headers alone did not establish.
                        self.breaker.record_success(d_target.worker.worker_id)
                        served = True
                    if not done_seen:
                        window = tail + chunk
                        if needle in window:
                            done_seen = True
                        tail = window[-tail_keep:]
                    obs.observe_stream_chunk(chunk)
                    yield chunk
            except httpx.HTTPError as exc:
                if done_seen:
                    logger.debug(
                        "decode stream from %s closed after its terminal marker (%s)",
                        d_url,
                        type(exc).__name__,
                    )
                    return
                logger.warning(
                    "decode stream from %s failed mid-response: %s: %s",
                    d_url,
                    type(exc).__name__,
                    exc or "<no message>",
                )
                metrics.pd_bootstrap_failures_total.labels(reason="decode_stream_broken").inc()
                err = json.dumps({"error": "decode stream failed"})
                obs.mark_failed()
                yield f"data: {err}\n\n".encode()
        finally:
            if d_resp is not None:
                # The cancellation that ended the stream would cancel this
                # teardown too, leaving the decode connection open and the
                # engine generating. Shield it, bounded so a wedged socket
                # cannot pin the policy slot released below.
                try:
                    with anyio.move_on_after(self._STREAM_CLOSE_TIMEOUT_S, shield=True):
                        await d_resp.aclose()
                except Exception:
                    pass
            self.policy.on_request_finished(d_target.route_key, d_blocks)
            obs.close()

    async def _open_decode_stream(
        self,
        d_url: str,
        d_body: dict,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """POST the decode leg, retrying only connection-establishment errors.

        Returns the streaming Response; caller must aclose() it exactly
        once. Read, write, and protocol errors are ambiguous: the engine may
        already own the request id, so replaying would hit duplicate-id checks.
        """
        backoff = self._DECODE_OPEN_INITIAL_BACKOFF_S
        last_exc: BaseException | None = None
        for attempt in range(self._DECODE_OPEN_MAX_RETRIES + 1):
            req = self._client.build_request("POST", d_url, json=d_body, headers=headers)
            try:
                resp = await self._client.send(req, stream=True)
            except (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout) as exc:
                last_exc = exc
                if attempt >= self._DECODE_OPEN_MAX_RETRIES:
                    raise
                logger.info(
                    "decode leg open retry %d/%d for %s: %s: %s",
                    attempt + 1,
                    self._DECODE_OPEN_MAX_RETRIES,
                    d_url,
                    type(exc).__name__,
                    exc or "<no message>",
                )
                metrics.pd_bootstrap_failures_total.labels(reason="decode_open_retried").inc()
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, self._DECODE_OPEN_MAX_BACKOFF_S)
                continue
            return resp
        # Loop always returns or raises; this satisfies type checkers.
        assert last_exc is not None
        raise last_exc

    async def _stream_dual(
        self,
        obs,
        p_target,
        p_blocks: list[int],
        d_target,
        d_blocks: list[int],
        p_url: str,
        d_url: str,
        p_body: dict,
        d_body: dict,
        p_headers: dict[str, str] | None = None,
        d_headers: dict[str, str] | None = None,
        *,
        path: str = DEFAULT_PATH,
    ):
        """Stream D's response while P runs concurrently in the background.

        P's HTTP connection stays open as long as KV is being transferred;
        we don't read its body, only its task lifetime matters. p_body and
        d_body differ only in engine-specific priority injection.
        """
        p = p_target.worker
        d = d_target.worker
        rid = p_body.get("rid") if isinstance(p_body, dict) else None
        p_task = self._track_prefill_task(
            asyncio.create_task(self._client.post(p_url, json=p_body, headers=p_headers))
        )
        n = _sample_count(p_body)
        # Once we've forwarded the endpoint's terminal marker downstream, any
        # subsequent httpx.ReadError is the client closing its half of a
        # successful response — drop silently instead of warning.
        done_seen = False
        d_resp: httpx.Response | None = None
        try:
            try:
                # Pre-flight is retryable (engine hasn't seen us); a
                # mid-stream read is not (would double-bill).
                try:
                    d_resp = await self._open_decode_stream(d_url, d_body, d_headers)
                except (httpx.TransportError, httpx.RemoteProtocolError) as exc:
                    # Engine never saw this body; finally still drains p_task.
                    # Emit a clean SSE error so the client records Failed.
                    logger.warning(
                        "decode leg %s unreachable after %d retries: %s: %s",
                        d_url,
                        self._DECODE_OPEN_MAX_RETRIES,
                        type(exc).__name__,
                        exc or "<no message>",
                    )
                    metrics.pd_bootstrap_failures_total.labels(reason="decode_unreachable").inc()
                    self.breaker.record_failure(d_target.worker.worker_id)
                    # json.dumps: exc text may contain chars that break SSE.
                    err = json.dumps({"error": "decode unreachable"})
                    obs.mark_failed()
                    yield f"data: {err}\n\n".encode()
                    return

                self._score_leg_headers(d_target.worker.worker_id, d_resp.status_code)
                if d_resp.status_code >= 400:
                    # Engine accepted but rejected; surface its body verbatim.
                    try:
                        body_bytes = await d_resp.aread()
                    except Exception:
                        body_bytes = b""
                    logger.warning(
                        "decode leg %s returned %d before streaming: %r",
                        d_url,
                        d_resp.status_code,
                        body_bytes[:500],
                    )
                    metrics.pd_bootstrap_failures_total.labels(
                        reason=f"decode_{d_resp.status_code // 100}xx"
                    ).inc()
                    err = json.dumps(
                        {
                            "error": (
                                f"decode {d_resp.status_code}: "
                                f"{body_bytes.decode('utf-8', errors='replace')[:500]}"
                            )
                        }
                    )
                    obs.mark_failed()
                    yield f"data: {err}\n\n".encode()
                    return

                # aiter_raw yields raw bytes, so the marker can straddle
                # chunks; a tail buffer keeps the match across splits.
                needle = _terminal_marker(path)
                tail_keep = len(needle) - 1
                tail = b""
                served = False
                async for chunk in d_resp.aiter_raw():
                    if not served and chunk:
                        # Bytes are flowing, so the worker is doing the work --
                        # which the headers alone did not establish.
                        self.breaker.record_success(d_target.worker.worker_id)
                        served = True
                    if not done_seen:
                        window = tail + chunk
                        if needle in window:
                            done_seen = True
                        tail = window[-tail_keep:]
                    obs.observe_stream_chunk(chunk)
                    yield chunk
            except httpx.HTTPError as exc:
                if done_seen:
                    # Engine has already sent its terminal marker; this is the
                    # client tearing down a successful response. Drop silently.
                    logger.debug(
                        "decode stream from %s closed after its terminal marker (%s)",
                        d_url,
                        type(exc).__name__,
                    )
                    return
                # Mid-stream failure: can't retry (would double-bill). Emit an
                # SSE error so truncation isn't mistaken for success; include
                # exc class since httpx stream errors often stringify to "".
                logger.warning(
                    "decode stream from %s failed mid-response: %s: %s",
                    d_url,
                    type(exc).__name__,
                    exc or "<no message>",
                )
                metrics.pd_bootstrap_failures_total.labels(reason="decode_stream_broken").inc()
                err = json.dumps({"error": "decode stream failed"})
                obs.mark_failed()
                yield f"data: {err}\n\n".encode()
        finally:
            if d_resp is not None:
                # Shielded so a cancel cannot leave the decode connection open
                # and the engine generating, but bounded: a wedged socket would
                # otherwise hold this scope forever, and everything below --
                # the pair abort and both policy releases -- is downstream of
                # it.
                try:
                    with anyio.move_on_after(self._STREAM_CLOSE_TIMEOUT_S, shield=True):
                        await d_resp.aclose()
                except Exception:
                    pass
            if not done_seen:
                # An unfinished stream leaves both engines holding the
                # request, and the cancellation that ended it would cancel
                # the abort too.
                with anyio.CancelScope(shield=True):
                    await self._release_prefill_drain(p_task, p, d, rid, n, abort=True)
            try:
                if done_seen:
                    # The client already has its answer; draining under a shield
                    # would pin the policy slots for the full drain timeout on a
                    # cancel that arrives after the stream ended.
                    await self._release_prefill_drain(p_task, p, d, rid, n, abort=False)
            finally:
                self.policy.on_request_finished(p_target.route_key, p_blocks)
                self.policy.on_request_finished(d_target.route_key, d_blocks)
                obs.close()
