###############################################################################
# Copyright (c) 2026, Advanced Micro Devices, Inc. All rights reserved.
#
# SPDX-License-Identifier: MIT
###############################################################################
"""Prometheus metrics for Infera.

All metric definitions live in this module so there's exactly one
place to look for "what does the server expose to ops". The router
and policy code calls these helpers; the FastAPI app mounts the
exposition endpoint at /metrics.

Naming follows the Prometheus convention:
    infera_<subsystem>_<thing>_<unit>

Labels are kept low-cardinality. ``worker_id`` and served ``model`` are bounded
by the deployment; free-form fields such as request_id are NOT label values.
"""

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import Callable
from contextlib import contextmanager

from prometheus_client import (
    CollectorRegistry,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)
from prometheus_client.exposition import CONTENT_TYPE_LATEST

REGISTRY = CollectorRegistry()
# Serving metrics (TTFT/ITL/ISL/OSL/tokens) are on by default so Prometheus
# scrapes are useful without an extra flag. The SLA planner consumes the same
# histograms; ``--no-enable-sla-metrics`` turns the per-token path off.
_sla_metrics_enabled = True


def set_sla_metrics_enabled(enabled: bool) -> None:
    """Enable or disable per-token serving observations (TTFT/ITL/ISL/OSL)."""
    global _sla_metrics_enabled
    _sla_metrics_enabled = bool(enabled)


# ----------------------------------------------------------------------
# Routing decisions
# ----------------------------------------------------------------------

router_picks_total = Counter(
    "infera_router_picks_total",
    "Total number of pick() decisions made by the router, per role and worker.",
    labelnames=("role", "worker_id"),  # role ∈ {prefill, decode, mixed}
    registry=REGISTRY,
)

router_pick_cache_hits = Histogram(
    "infera_router_pick_cache_hits",
    "Number of cache blocks the picked worker already had (chained-prefix hits).",
    labelnames=("role",),
    buckets=(0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, float("inf")),
    registry=REGISTRY,
)

router_pick_request_blocks = Histogram(
    "infera_router_pick_request_blocks",
    "Total request block count seen at pick time.",
    labelnames=("role",),
    buckets=(0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, float("inf")),
    registry=REGISTRY,
)


# ----------------------------------------------------------------------
# Request lifecycle
# ----------------------------------------------------------------------

request_duration_seconds = Histogram(
    "infera_request_duration_seconds",
    "End-to-end server-observed request latency (server.pick + worker round-trip).",
    labelnames=("router", "outcome"),  # router ∈ {mixed, disagg}; outcome ∈ {ok, 5xx, 4xx, error}
    buckets=(
        0.005,
        0.01,
        0.025,
        0.05,
        0.1,
        0.25,
        0.5,
        1.0,
        2.5,
        5.0,
        10.0,
        30.0,
        60.0,
        float("inf"),
    ),
    registry=REGISTRY,
)

request_inflight = Gauge(
    "infera_request_inflight",
    "Currently in-flight requests at the server.",
    labelnames=("router",),
    registry=REGISTRY,
)

requests_total = Counter(
    "infera_requests_total",
    "Completed requests by router and outcome. QPS = rate(infera_requests_total[1m]).",
    labelnames=("router", "outcome"),
    registry=REGISTRY,
)

prompt_tokens_total = Counter(
    "infera_prompt_tokens_total",
    "Prompt tokens observed on successful requests. "
    "Prompt throughput (tok/s) = rate(infera_prompt_tokens_total[1m]).",
    labelnames=("router", "model", "prefill_worker"),
    registry=REGISTRY,
)

generation_tokens_total = Counter(
    "infera_generation_tokens_total",
    "Generated tokens observed on successful requests. "
    "Decode throughput (tok/s) = rate(infera_generation_tokens_total[1m]).",
    labelnames=("router", "model", "decode_worker"),
    registry=REGISTRY,
)

prefix_cache_blocks_hit_total = Counter(
    "infera_prefix_cache_blocks_hit_total",
    "Cached KV blocks the router credited to the picked worker at pick time.",
    labelnames=("role",),
    registry=REGISTRY,
)

prefix_cache_blocks_total = Counter(
    "infera_prefix_cache_blocks_total",
    "Request KV blocks seen at pick time. Hit rate = rate(hit_total) / rate(blocks_total).",
    labelnames=("role",),
    registry=REGISTRY,
)

# ----------------------------------------------------------------------
# Engine gauges (scraped from worker /metrics into the frontend exposition)
# ----------------------------------------------------------------------

engine_kv_cache_usage = Gauge(
    "infera_engine_kv_cache_usage",
    "Engine-reported KV-cache pool occupancy fraction (0-1). "
    "SGLang: sglang:token_usage; vLLM: vllm:kv_cache_usage_perc.",
    labelnames=("worker_id", "engine", "disagg_mode"),
    registry=REGISTRY,
)

engine_prefix_cache_hit_rate = Gauge(
    "infera_engine_prefix_cache_hit_rate",
    "Engine-reported prefix cache hit rate when published (e.g. sglang:cache_hit_rate).",
    labelnames=("worker_id", "engine", "disagg_mode"),
    registry=REGISTRY,
)

engine_kv_transfer_queue_reqs = Gauge(
    "infera_engine_kv_transfer_queue_reqs",
    "Engine PD KV transfer / bootstrap queue depth from worker /metrics.",
    labelnames=("worker_id", "queue"),
    registry=REGISTRY,
)


# ----------------------------------------------------------------------
# Serving / SLA signals (consumed by Prometheus and infera.planner)
# ----------------------------------------------------------------------
# The SLA planner reads only the _sum / _count of these four histograms and
# window-differences them, so the bucket layout is for humans/dashboards.
# Percentiles (p50/p90/p99) are computed in Prometheus/Grafana via
# histogram_quantile — they are not exported as separate gauges.

time_to_first_token_seconds = Histogram(
    "infera_time_to_first_token_seconds",
    "Server-observed time from dispatch to the first token of the reply. "
    "For PD-disaggregated requests this spans prefill + KV transfer + the "
    "decode engine's first forward pass. Labeled by the prefill worker; "
    "decode time is on infera_inter_token_latency_seconds.",
    labelnames=("router", "model", "prefill_worker"),
    buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, float("inf")),
    registry=REGISTRY,
)

inter_token_latency_seconds = Histogram(
    "infera_inter_token_latency_seconds",
    "Mean per-request inter-token latency: (total stream time - TTFT) spread "
    "over the generated tokens. Only observed for requests that produced at "
    "least two output tokens. Labeled by the decode worker.",
    labelnames=("router", "model", "decode_worker"),
    buckets=(0.001, 0.0025, 0.005, 0.01, 0.02, 0.04, 0.08, 0.16, 0.32, 1.0, float("inf")),
    registry=REGISTRY,
)

input_sequence_tokens = Histogram(
    "infera_input_sequence_tokens",
    "Prompt length in tokens (ISL). Exact when the engine reports "
    "`usage.prompt_tokens`; otherwise estimated from the router's KV block "
    "count, which rounds up to a block boundary.",
    labelnames=("router", "model"),
    buckets=(64, 256, 1024, 4096, 16384, 65536, 262144, 1048576, float("inf")),
    registry=REGISTRY,
)

output_sequence_tokens = Histogram(
    "infera_output_sequence_tokens",
    "Generated length in tokens (OSL). Exact when the engine reports "
    "`usage.completion_tokens`; otherwise counted as SSE data frames, which "
    "assumes one token per frame.",
    labelnames=("router", "model"),
    buckets=(4, 16, 64, 256, 1024, 4096, 16384, 65536, float("inf")),
    registry=REGISTRY,
)


# ----------------------------------------------------------------------
# PD-disaggregation specifics
# ----------------------------------------------------------------------

pd_dispatch_duration_seconds = Histogram(
    "infera_pd_dispatch_duration_seconds",
    "Per-worker duration of a PD-dispatched request (P or D leg from server "
    "POST to response complete). Roughly: P leg = prefill + KV push start; "
    "D leg = KV pull + decode generation. The gap between P and D "
    "completion times approximates KV transfer latency.",
    labelnames=("leg", "worker_id"),  # leg ∈ {prefill, decode}
    buckets=(0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0, float("inf")),
    registry=REGISTRY,
)

migrations_total = Counter(
    "infera_migrations_total",
    "Live generations carried from one worker to another, by what prompted it.",
    labelnames=("reason",),  # reason ∈ {stream_broken, worker_draining}
    registry=REGISTRY,
)

migrations_failed_total = Counter(
    "infera_migrations_failed_total",
    "Generations that could not be carried, and so ended visibly to the client.",
    labelnames=("reason",),  # reason ∈ {no_candidate, not_nats, no_first_byte, limit, poisoned}
    registry=REGISTRY,
)

pd_bootstrap_failures_total = Counter(
    "infera_pd_bootstrap_failures_total",
    "PD bootstrap protocol failures (missing bootstrap_addr, P unreachable, etc.).",
    labelnames=("reason",),  # reason ∈ {missing_bootstrap_addr, p_unreachable, d_unreachable,
    #                decode_5xx, decode_stream_broken, prefill_exception, prefill_5xx, ...}
    registry=REGISTRY,
)


# ----------------------------------------------------------------------
# Worker pool state
# ----------------------------------------------------------------------

active_workers = Gauge(
    "infera_active_workers",
    "Number of workers in ACTIVE status, by disagg_mode.",
    labelnames=("disagg_mode", "model"),
    registry=REGISTRY,
)


worker_breaker_state = Gauge(
    "infera_router_worker_breaker_state",
    "Router-side circuit breaker per worker: 0=closed, 1=half_open, 2=open. "
    "Non-zero means the router is routing around a worker that discovery still "
    "reports ACTIVE — the gap this metric exists to make visible.",
    labelnames=("worker_id",),
    registry=REGISTRY,
)

worker_breaker_trips_total = Counter(
    "infera_router_worker_breaker_trips_total",
    "Times a worker's breaker has opened. A worker tripping repeatedly while "
    "staying ACTIVE is broken for inference but healthy to the platform.",
    labelnames=("worker_id",),
    registry=REGISTRY,
)


# ----------------------------------------------------------------------
# KV-aware policy internals
# ----------------------------------------------------------------------

policy_active_blocks = Gauge(
    "infera_policy_active_blocks",
    "Per-worker count of distinct in-flight block hashes — the load term in "
    "KvEventAwarePolicy's cost function. Lower = less loaded by the policy's view.",
    labelnames=("worker_id",),
    registry=REGISTRY,
)

policy_cache_view_size = Gauge(
    "infera_policy_cache_view_size",
    "Per-worker count of cached blocks in the router-side KvEventClient view. "
    "Reflects what BlockStored / BlockRemoved events have applied so far.",
    labelnames=("worker_id",),
    registry=REGISTRY,
)

render_parity = Gauge(
    "infera_router_render_parity",
    "Whether this worker confirmed at registration that the router renders the "
    "same prompt it does: 1 = confirmed, 0 = DIVERGED, -1 = could not be "
    "checked. 0 means kv-aware routing is silently off for this worker — every "
    "block hash misses, the policy degrades to load balancing, and no other "
    "signal shows it. Alert on 0; -1 is expected on engines without a tokenize "
    "endpoint.",
    labelnames=("worker_id", "model"),
    registry=REGISTRY,
)

render_variant = Gauge(
    "infera_router_render_variant",
    "The server-side --default-chat-template-kwargs the router read back from "
    "this worker and hashes its requests under. Always 1; the label carries "
    "the value. The number to watch is how many DISTINCT `variant` labels a "
    "model exports: 1 means the fleet is uniform and a single router-side flag "
    "would have been right, 2+ means it would not have been — and before this "
    "existed the minority group's cache lookups all missed, silently.",
    labelnames=("worker_id", "variant"),
    registry=REGISTRY,
)

render_parity_diverged_total = Counter(
    "infera_router_render_parity_diverged_total",
    "Workers that failed the startup render-parity check, by model. Unlike the "
    "gauge this survives the worker going away, so a fleet that rolls through "
    "broken replicas leaves a trace.",
    labelnames=("model",),
    registry=REGISTRY,
)

# ----------------------------------------------------------------------
# Client cache-control hints (retention)
# ----------------------------------------------------------------------

cache_control_seen_total = Counter(
    "infera_cache_control_seen_total",
    "Count of requests by retention level observed in the request body "
    "(parsed from Anthropic cache_control / OpenAI prompt_cache_retention). "
    "Lets ops correlate workload mix with cache hit rate.",
    labelnames=("retention",),  # ∈ {none, short, long}
    registry=REGISTRY,
)

cache_locality_skipped_total = Counter(
    "infera_cache_locality_skipped_total",
    "Count of routing decisions where cache locality was intentionally "
    "ignored (overlap_weight forced to 0). Most common reason today is "
    "`multimodal` — see Phase 4.7(b): until router + engine adopt MM-aware "
    "hashing, vision/audio requests fall back to pure load balance to "
    "avoid wrong-KV reuse from same-text-different-image collisions.",
    labelnames=("reason",),
    registry=REGISTRY,
)


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def record_pick(*, role: str, worker_id: str, cache_hits: int, request_blocks: int) -> None:
    """Single entry point the router calls on every policy.pick() decision."""
    router_picks_total.labels(role=role, worker_id=worker_id).inc()
    router_pick_cache_hits.labels(role=role).observe(cache_hits)
    router_pick_request_blocks.labels(role=role).observe(request_blocks)
    if request_blocks > 0:
        prefix_cache_blocks_hit_total.labels(role=role).inc(cache_hits)
        prefix_cache_blocks_total.labels(role=role).inc(request_blocks)


def outcome_label(status: int | None = None) -> str:
    """Map an HTTP status (or absence of one) onto the shared outcome label set.

    Labels are ``ok`` / ``4xx`` / ``5xx`` / ``error`` so Python and Rust
    frontends stay interchangeable in Grafana error-rate panels.
    """
    if status is None:
        return "error"
    if status < 400:
        return "ok"
    if status < 500:
        return "4xx"
    if status < 600:
        return "5xx"
    return "error"


_SSE_DATA = b"data:"
_SSE_DONE = b"data: [DONE]"
# An SSE frame that grows past this without a newline is not a token frame
# (or the peer is misbehaving); drop the partial rather than buffer forever.
_MAX_PARTIAL_FRAME = 1 << 16


class RequestObserver(dict):
    """Per-request accumulator for the SLA signals the planner consumes.

    Subclasses ``dict`` so the established ``obs["outcome"] = ...`` idiom in
    the routers keeps working untouched.

    Streaming responses outlive the ``track_request`` block — ``dispatch``
    returns a ``StreamingResponse`` and the generator runs afterwards — so the
    SLA histograms are emitted by :meth:`close` rather than at context exit.
    A generator that owns the token stream calls :meth:`claim_stream` and then
    :meth:`close` from its own ``finally``.
    """

    def __init__(self, router: str, model: str = "") -> None:
        super().__init__(outcome="error")
        self._router = router
        self._model = model
        self._start = time.perf_counter()
        self._ttft: float | None = None
        self._isl: int | None = None
        self._osl: int | None = None
        self._frames = 0
        self._partial = b""
        self._deferred = False
        self._closed = False
        self._prefill_worker = ""
        self._decode_worker = ""
        self._on_failure: list[Callable[[], None]] = []
        self.cancelled = False

    def on_failure(self, callback: Callable[[], None]) -> None:
        """Run ``callback`` at :meth:`close` if the request did not end "ok".
        A client that went away (``cancelled``) is not a failure."""
        self._on_failure.append(callback)

    @property
    def deferred(self) -> bool:
        """True once a streaming generator took over responsibility for close()."""
        return self._deferred

    def claim_stream(self) -> None:
        self._deferred = True

    def set_workers(self, *, prefill_worker: str = "", decode_worker: str = "") -> None:
        """Record the workers chosen for this request (for per-worker SLA labels)."""
        if prefill_worker:
            self._prefill_worker = prefill_worker
        if decode_worker:
            self._decode_worker = decode_worker

    def mark_failed(self, outcome: str = "stream_failed") -> None:
        """Disown a request that failed after its outcome was committed.

        The streaming routers set ``outcome`` to "ok" at hand-off, before the
        generator has run, because that is the point past which the client can
        no longer be failed over. A decode leg that then turns out to be
        unreachable would otherwise be closed as a success: it inflates the
        request count the planner divides by, and contributes a one-frame OSL.
        Under a decode outage that is most of the window, and the planner sizes
        the fleet from it.
        """
        self["outcome"] = outcome

    def first_token(self) -> None:
        """Mark the arrival of the first reply token. Idempotent."""
        if not _sla_metrics_enabled:
            return
        if self._ttft is None:
            self._ttft = time.perf_counter() - self._start

    def set_input_tokens(self, n: int) -> None:
        if not _sla_metrics_enabled:
            return
        if n > 0:
            self._isl = int(n)

    def set_output_tokens(self, n: int) -> None:
        """Record an exact OSL, overriding any SSE frame count."""
        if not _sla_metrics_enabled:
            return
        if n > 0:
            self._osl = int(n)

    def observe_blocks(self, blocks: list[int] | None, block_size: int | None) -> None:
        """Estimate ISL from the router's KV block list, used when the engine
        reply carries no ``usage`` (the streaming default). Rounds up to a
        block boundary, and is a no-op for stateless policies that return no
        blocks."""
        if not _sla_metrics_enabled:
            return
        if self._isl is None and blocks and block_size:
            self._isl = len(blocks) * int(block_size)

    def observe_usage(self, payload: object) -> None:
        """Pull exact ISL/OSL out of an OpenAI-shaped ``usage`` object."""
        if not _sla_metrics_enabled:
            return
        if not isinstance(payload, dict):
            return
        usage = payload.get("usage")
        if not isinstance(usage, dict):
            return
        prompt = usage.get("prompt_tokens")
        completion = usage.get("completion_tokens")
        if isinstance(prompt, int):
            self.set_input_tokens(prompt)
        if isinstance(completion, int):
            self.set_output_tokens(completion)

    def observe_stream_chunk(self, chunk: bytes) -> None:
        """Count complete SSE data frames in a raw stream chunk as tokens.

        Frames are split on newlines and the trailing partial is carried over,
        so a chunk boundary never double-counts. ``[DONE]`` and any trailing
        usage frame are excluded, but the one-frame-per-token assumption still
        makes this an estimate; ``set_output_tokens`` supersedes it when the
        engine reports usage.
        """
        if not _sla_metrics_enabled or not chunk:
            return
        buf = self._partial + chunk
        frames = buf.split(b"\n")
        tail = frames.pop()
        self._partial = tail if len(tail) <= _MAX_PARTIAL_FRAME else b""
        for frame in frames:
            frame = frame.strip()
            if not frame.startswith(_SSE_DATA) or frame.startswith(_SSE_DONE):
                continue
            self._inspect_frame(frame)

    def _inspect_frame(self, frame: bytes) -> None:
        """Classify one OpenAI chat/completions SSE data frame.

        Usage supersedes frame counting. Error frames disown the request. For
        estimated OSL, count chat ``delta`` frames only when they carry content
        (not role/finish metadata), and completion frames when ``text`` is
        non-empty.
        """
        try:
            payload = json.loads(frame[len(_SSE_DATA) :])
        except ValueError:
            return
        if not isinstance(payload, dict):
            return
        if payload.get("error") is not None:
            self.mark_failed("engine_error")
            return
        self.observe_usage(payload)
        choices = payload.get("choices")
        if not isinstance(choices, list):
            return
        token_frames = 0
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            text = choice.get("text")
            if isinstance(text, str) and text:
                token_frames += 1
                continue
            delta = choice.get("delta")
            if not isinstance(delta, dict):
                continue
            if any(
                key != "role" and value not in (None, "", [], {}) for key, value in delta.items()
            ):
                token_frames += 1
        if token_frames:
            self.first_token()
            self._frames += token_frames

    def close(self) -> None:
        """Emit lifecycle + SLA metrics. Idempotent.

        For deferred (streaming) observers this is the only place
        ``requests_total`` / duration / inflight are updated, so mid-stream
        ``mark_failed()`` still wins. SLA histograms still only observe
        successful requests.
        """
        if self._closed:
            return
        self._closed = True
        router, model = self._router, self._model
        outcome = self["outcome"]
        if outcome != "ok" and not self.cancelled:
            for callback in self._on_failure:
                callback()
        if self._deferred:
            request_inflight.labels(router=router).dec()
            request_duration_seconds.labels(router=router, outcome=outcome).observe(
                time.perf_counter() - self._start
            )
            requests_total.labels(router=router, outcome=outcome).inc()
        if not _sla_metrics_enabled:
            return
        if outcome != "ok":
            return

        osl = self._osl if self._osl is not None else self._frames
        prefill_worker = self._prefill_worker
        decode_worker = self._decode_worker
        if self._isl is not None:
            input_sequence_tokens.labels(router=router, model=model).observe(self._isl)
            prompt_tokens_total.labels(
                router=router, model=model, prefill_worker=prefill_worker
            ).inc(self._isl)
        if osl > 0:
            output_sequence_tokens.labels(router=router, model=model).observe(osl)
            generation_tokens_total.labels(
                router=router, model=model, decode_worker=decode_worker
            ).inc(osl)

        if self._ttft is None:
            # Non-streaming reply: the whole response landed at once, so there
            # is no observable first-token boundary to report.
            return
        time_to_first_token_seconds.labels(
            router=router,
            model=model,
            prefill_worker=prefill_worker,
        ).observe(self._ttft)
        if osl > 1:
            decode_time = max(0.0, time.perf_counter() - self._start - self._ttft)
            inter_token_latency_seconds.labels(
                router=router, model=model, decode_worker=decode_worker
            ).observe(decode_time / (osl - 1))


@contextmanager
def track_request(router: str, model: str = ""):
    """Context manager that wraps a request's server-side lifetime to
    populate `request_duration_seconds` (with outcome) and the in-flight
    gauge. Use like::

        with track_request(router="mixed") as obs:
            resp = await dispatch(...)
            obs["outcome"] = outcome_label(resp.status_code)

    Yields a :class:`RequestObserver`, whose extra methods feed the SLA
    histograms. For a streaming reply the observer is handed to the stream
    generator, which closes it once the last token has been forwarded.
    """
    obs = RequestObserver(router, model)
    request_inflight.labels(router=router).inc()
    try:
        yield obs
    except asyncio.CancelledError:
        obs.cancelled = True
        raise
    finally:
        # Streaming generators claim the observer and call close() after the
        # last token. Recording requests_total here would lock in "ok" before
        # mark_failed() can run on a mid-stream error.
        if not obs.deferred:
            request_inflight.labels(router=router).dec()
            outcome = obs["outcome"]
            request_duration_seconds.labels(router=router, outcome=outcome).observe(
                time.perf_counter() - obs._start
            )
            requests_total.labels(router=router, outcome=outcome).inc()
            obs.close()


@contextmanager
def track_pd_leg(*, leg: str, worker_id: str):
    """Time a single PD leg (P or D). Used inside `DisaggRouter`.

    The gap between the P leg's end-time and the D leg's first-token
    time is the closest proxy we have to KV-transfer latency without
    hooking inside SGLang.
    """
    start = time.perf_counter()
    try:
        yield
    finally:
        pd_dispatch_duration_seconds.labels(leg=leg, worker_id=worker_id).observe(
            time.perf_counter() - start
        )


def apply_engine_scrape(
    *,
    worker_id: str,
    engine: str,
    disagg_mode: str,
    text: str,
) -> None:
    """Update engine gauges from one worker's Prometheus text exposition."""
    from infera.common.engine_metrics import (
        mean_metric,
        metric_names,
        parse_metric,
        transfer_queue_names,
    )
    from infera.common.worker_pool import EngineType

    try:
        eng = EngineType(engine)
    except ValueError:
        return

    mode = disagg_mode or "mixed"
    kv_val = None
    for name in metric_names("kv_cache_usage", eng):
        kv_val = mean_metric(text, name)
        if kv_val is None:
            kv_val = parse_metric(text, name)
        if kv_val is not None:
            break
    if kv_val is not None:
        engine_kv_cache_usage.labels(worker_id=worker_id, engine=engine, disagg_mode=mode).set(
            kv_val
        )

    for name in metric_names("prefix_cache_hit_rate", eng):
        hit = mean_metric(text, name)
        if hit is not None:
            engine_prefix_cache_hit_rate.labels(
                worker_id=worker_id, engine=engine, disagg_mode=mode
            ).set(hit)
            break

    for queue, name in transfer_queue_names(eng):
        depth = parse_metric(text, name)
        if depth is not None:
            engine_kv_transfer_queue_reqs.labels(worker_id=worker_id, queue=queue).set(depth)


def prune_departed_workers(active_worker_ids: set[str]) -> None:
    """Drop SLA series whose worker id is no longer active.

    Child series stay registered until removed, and a replaced pod gets a new
    worker id. An empty worker label is the series used before a worker is
    known and is left in place. Labels may be a bare ``worker_id`` or a DP
    ``route_key`` (``worker_id#dpN``); the ``#dpN`` suffix is ignored when
    matching against the active set.
    """
    _drop_worker_series(time_to_first_token_seconds, "prefill_worker", active_worker_ids)
    _drop_worker_series(inter_token_latency_seconds, "decode_worker", active_worker_ids)
    _drop_worker_series(prompt_tokens_total, "prefill_worker", active_worker_ids)
    _drop_worker_series(generation_tokens_total, "decode_worker", active_worker_ids)
    _drop_worker_series(router_picks_total, "worker_id", active_worker_ids)


def _worker_id_base(label: str) -> str:
    """Strip a ``#dpN`` route_key suffix so DP ranks map to their worker."""
    head, sep, _ = label.partition("#dp")
    return head if sep else label


def _drop_worker_series(metric, label: str, active: set[str]) -> None:
    """Remove children of ``metric`` whose ``label`` is outside ``active``."""
    index = metric._labelnames.index(label)
    stale = [
        labels
        for labels in list(metric._metrics)
        if labels[index] and _worker_id_base(labels[index]) not in active
    ]
    for labels in stale:
        metric.remove(*labels)


def render_metrics() -> tuple[bytes, str]:
    """Return (body, content_type) for the /metrics endpoint."""
    return generate_latest(REGISTRY), CONTENT_TYPE_LATEST
