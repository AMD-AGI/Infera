###############################################################################
# Copyright (c) 2025, Advanced Micro Devices, Inc. All rights reserved.
#
# See LICENSE for license information.
###############################################################################
"""Explicit inference communication model (feature B: custom collective ops).

The training profiler folds tensor-parallel AllReduce and expert-parallel
AllToAll *into* the per-layer forward time.  For serving we want comm to be a
first-class, reportable quantity so users can:

  * see a per-phase **communication breakdown** (TP AllReduce, EP AllToAll,
    PP send/recv, and KV-cache transfer for disaggregation),
  * **force a collective algorithm** (ring / one-shot / two-shot /
    hierarchical) instead of the auto-selected fastest,
  * **overlap** comm with compute (a fraction hidden behind GEMMs), and
  * apply a **custom fused-op** speedup (e.g. AllReduce+RMSNorm fusion or
    DeepEP-style overlapped dispatch/combine).

All times are returned in **milliseconds**.  At default knob values this model
reproduces the implicit cost computed inside ``transformer_layer`` so totals
stay consistent; the delta only appears when a knob is changed.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass

import numpy as np

from infera.projection.core.projection.module_profilers import collective_model as cm
from infera.projection.core.projection.module_profilers.collective_args import get_default_args
from infera.projection.core.projection.training_config import (
    InferenceCollectiveConfig,
    ModelConfig,
    ModelParallelConfig,
)

_PROTOCOLS = ("simple", "ll", "ll64", "ll128")

# Representative extra TP-AllReduce speedups for custom collective ops.
_QUICK_REDUCE_SPEEDUP = 0.6  # ROCm low-latency quantized AR (small msgs).
_FUSED_RMSNORM_AR_SPEEDUP = 0.8  # RMSNorm+AR fusion hides part of the AR.

# Intra-node serving collective latency floor.
#
# The base fixed collective overhead is calibrated for training's large messages;
# a graph-captured intra-node serving collective does not pay it, so the intra-node
# path uses ``max(floor, bandwidth)`` instead. Multi-node keeps the base model.
#
# The AllReduce floor was 26 us, from an 8-GPU **RCCL** microbenchmark. That is
# the wrong kernel for a serving projection: vLLM runs with
# ``disable_custom_all_reduce=False`` by default and dispatches decode messages
# to its own one-shot/two-shot all-reduce for anything under 8 MB, not to RCCL.
# Charging the RCCL latency put a flat 1.872 ms (2 AR/layer x 26 us x 36 layers)
# into every gpt-oss decode step at TP>1 -- independent of batch *and* of TP,
# since the floor always won over the bandwidth term even at a 1.5 MB message.
_INFER_AR_OVERHEAD_US = float(os.getenv("INFERASIM_INFER_AR_FLOOR_US", "10.0") or 10.0)
_INFER_A2A_OVERHEAD_US = float(os.getenv("INFERASIM_INFER_A2A_FLOOR_US", "30.0") or 30.0)

# Intra-node decode all-reduce, measured on MI355X against vLLM's own custom
# all-reduce -- the kernel a decode step actually runs -- over the message sizes
# a decode step actually produces (6 KB to 3 MB, i.e. batch 1 to 512 at hidden
# 2880). Maps world size -> (floor_us, effective GB/s), fitting
#
#     t_us = floor_us + bytes / bw
#
# at r^2 >= 0.99 on every world size.
#
# Two things here were wrong before and both mattered. The composition is
# *additive*, not ``max(floor, bandwidth)``: at 1.5 MB the transfer and the
# floor are within 2x of each other, so taking the max drops a term that is
# genuinely there. And the bandwidth is far below the 717 GB/s node link --
# these messages are too small to saturate it, and no clean ring or one-shot
# factor maps one onto the other, so the achieved figure has to be measured
# rather than derived. Together those put the modelled all-reduce 3-5x under
# measurement at batch 256, which was the entire batch-256 TP residual.
_INFER_AR_MEASURED_GBPS = {2: (7.81, 65.9), 4: (10.06, 120.7), 8: (11.40, 117.6)}

# Above this message size vLLM stops using its own all-reduce and hands the
# message to RCCL, so the fit above no longer describes the kernel that runs.
# The distinction matters far more than it sounds: a decode message is a couple
# of MB, but a prefill message is tokens x hidden, which at batch 64 is 377 MB --
# 250x larger and nowhere near the sizes the fit was measured over. Applying the
# small-message bandwidth there charged 232 ms of all-reduce to a prefill that
# measured 177 ms in total, i.e. more communication than the whole step.
_VLLM_CUSTOM_AR_MAX_BYTES = float(os.getenv("INFERASIM_CUSTOM_AR_MAX_MB", "8") or 8) * 1024 * 1024

# Intra-node expert-parallel all-to-all, measured the same way and fitted to
# the same ``t_us = floor_us + bytes / bw`` shape, at r^2 >= 0.996. Maps world
# size -> (floor_us, effective GB/s), against the bytes that actually cross a
# link -- ``(N-1)/N`` of the buffer, since a rank's own shard never moves.
#
# The all-reduce got measured here and the all-to-all did not, and the asymmetry
# was expensive. The all-to-all kept a guessed 30 us constant composed as
# ``max(floor, bandwidth)``, and since a decode message never gets big enough for
# the bandwidth term to win, the constant set the price at every batch. A gpt-oss
# step runs 36 MoE layers with a dispatch and a combine each, so that was
# 72 x 30 us = 2.16 ms of fixed cost per step against a ~3 ms step -- while the
# measured cost of turning expert parallelism on at batch 1 is about 0.25 ms.
# The model therefore priced EP as catastrophic at low batch (-63% at TP4 batch 1
# against -10% measured) and, because the phantom cost did not grow with the
# batch, as a *win* at high batch where measurement says it loses. That inverted
# real ranking decisions, which is the one failure mode a search cannot absorb.
_INFER_A2A_MEASURED_GBPS = {2: (26.59, 57.2), 4: (22.52, 148.3), 8: (18.6, 290.3)}

# The fit above was taken on decode-scale dispatches -- a few MB -- and its
# bandwidths are a fifth to a half of the node link precisely because messages
# that small cannot saturate it. Extrapolated to a prefill dispatch, which is
# tokens x hidden x top-k and reaches 1.6 GB, that small-message bandwidth is no
# longer a property of the link and charges seconds of all-to-all to a prefill
# that measures far less. The all-reduce already guards its own fit for the same
# reason (see ``_VLLM_CUSTOM_AR_MAX_BYTES``); above this size the analytical
# bandwidth model describes the transfer better than the small-message fit.
_INFER_A2A_MEASURED_MAX_BYTES = (
    float(os.getenv("INFERASIM_A2A_MEASURED_MAX_MB", "32") or 32) * 1024 * 1024
)


def _measured_intra_node_a2a_us(msg_bytes: float, gpus: int) -> float | None:
    """Measured intra-node all-to-all bandwidth term (us), or ``None``.

    Bandwidth only, for exactly the reason the all-reduce is bandwidth only: the
    fitted floor is what a *standalone* collective costs, and most of it is the
    per-kernel launch and occupancy that the decode step already charges for
    every kernel it runs, this one included. Charging it twice is what the 30 us
    constant was doing.

    ``msg_bytes`` is the whole buffer; only ``(N-1)/N`` of it leaves the device.
    Falls back to the largest measured world size at or below ``gpus`` so an odd
    EP degree still gets a measured shape rather than a training-scale constant.
    ``None`` also means "past the measured regime": above
    ``_INFER_A2A_MEASURED_MAX_BYTES`` the caller should use the analytical
    bandwidth model instead of extrapolating a small-message fit.
    """
    if gpus < 2:
        return 0.0
    if msg_bytes > _INFER_A2A_MEASURED_MAX_BYTES:
        return None
    keys = [w for w in sorted(_INFER_A2A_MEASURED_GBPS) if w <= gpus]
    if not keys:
        return None
    _floor_us, bw_gbps = _INFER_A2A_MEASURED_GBPS[keys[-1]]
    crossing = msg_bytes * (gpus - 1) / gpus
    return (crossing / (bw_gbps * 1e9)) * 1e6


def _measured_intra_node_ar_us(msg_bytes: float, gpus: int) -> float | None:
    """Measured intra-node all-reduce latency (us), or ``None`` if unmeasured.

    ``None`` also means "not this kernel": above vLLM's custom all-reduce size
    limit the message goes to RCCL, whose large-message bandwidth the base
    collective model already describes, so the caller should fall back to it.

    Falls back to the largest measured world size at or below ``gpus`` so an
    odd TP degree still gets a measured shape rather than the training model.
    """
    if gpus < 2:
        return 0.0
    if msg_bytes > _VLLM_CUSTOM_AR_MAX_BYTES:
        return None
    keys = [w for w in sorted(_INFER_AR_MEASURED_GBPS) if w <= gpus]
    if not keys:
        return None
    _floor_us, bw_gbps = _INFER_AR_MEASURED_GBPS[keys[-1]]
    # Only the bandwidth term. The fitted floor is what a *standalone* all-reduce
    # costs, and most of it is the per-kernel occupancy every kernel pays -- which
    # the decode step already charges for all of its kernels, this one included.
    # Adding both counted it twice, and visibly: the resulting step floor rose
    # from 1.91 ms at TP=1 to 2.73 ms at TP=8, while the measured floor is flat
    # at 2.72 ms +/- 0.2 across all four rungs, as a fixed cost should be.
    return (msg_bytes / (bw_gbps * 1e9)) * 1e6


def deepep_overlap_efficiency(model_config) -> float:
    """Fraction of EP All-to-All hidden behind compute under DeepEP/SyncFree.

    DeepEP issues the dispatch/combine asynchronously so the All-to-All
    overlaps with grouped-GEMM expert compute. SyncFree stages progressively
    remove CPU sync stalls and push the overlap higher. Returns ``0.0`` when
    neither ``use_turbo_deepep`` nor ``turbo_sync_free_moe_stage`` is set.

    The efficiency ladder mirrors the training projection's
    ``_get_deepep_overlap_efficiency`` so serving and training agree.
    """
    sync_free_stage = getattr(model_config, "turbo_sync_free_moe_stage", 0) or 0
    if not (getattr(model_config, "use_turbo_deepep", False) or sync_free_stage > 0):
        return 0.0
    if sync_free_stage >= 3:
        return 0.85
    if sync_free_stage >= 2:
        return 0.80
    if sync_free_stage >= 1:
        return 0.75
    return 0.65


def _min_over_protocols(fn, args, msg_size, gpus, groups) -> float:
    """Run a low-level collective ``fn`` over every protocol, return the min (us)."""
    best = float("inf")
    for p in _PROTOCOLS:
        try:
            t = fn(args, msg_size, gpus, groups=groups, protocol=p)
        except TypeError:
            # Some helpers don't take ``groups`` (e.g. single_shot_*).
            t = fn(args, msg_size, gpus, protocol=p)
        if t < best:
            best = t
    return best


def _allreduce_overhead_us(args, msg_size, gpus) -> float:
    """Fixed AllReduce overhead matching ``collective_model.allreduce``.

    Forced-algorithm paths must add the same RCCL setup + NIC warmup cost the
    auto-selected path adds, otherwise *choosing* an algorithm spuriously
    appears faster than ``auto`` (which is the min over algorithms + overhead).
    """
    overhead = getattr(args, "rccl_overhead_us", 0.0)
    if gpus > args.node_size:
        nics = getattr(args, "nics_per_node", None) or args.node_size
        num_nodes = gpus // args.node_size
        node_steps = max(1, int(np.ceil(np.log2(num_nodes))))
        per_nic_bytes = msg_size / (nics * node_steps)
        warmup = getattr(args, "nic_warmup_bytes", 32 * 1024 * 1024)
        ratio = min(1.0, per_nic_bytes / warmup) if warmup > 0 else 1.0
        if ratio < 1.0:
            setup_us = getattr(args, "nic_rdma_setup_us", 0.0) * node_steps
            overhead += setup_us * (1.0 - ratio**2.5)
    return overhead


def _alltoall_overhead_us(args, gpus) -> float:
    """Fixed AllToAll overhead matching ``collective_model.alltoall``."""
    gpus_per_node = args.node_size
    intra_node_peers = min(gpus - 1, gpus_per_node - 1)
    inter_node_peers = max(0, gpus - gpus_per_node)
    intra_sync = getattr(args, "a2a_intra_sync_overhead", 50.0)
    intra_per_peer = getattr(args, "a2a_intra_node_peer_lat", 2.5)
    intra_overhead = (
        (intra_sync + intra_per_peer * intra_node_peers) if intra_node_peers > 0 else 0.0
    )
    inter_per_peer = getattr(args, "a2a_peer_lat", 0.45)
    inter_overhead = inter_per_peer * inter_node_peers
    return intra_overhead + inter_overhead + getattr(args, "a2a_rccl_overhead_us", 0.0)


@dataclass
class CommBreakdown:
    """Per-forward communication time (ms), split by collective op."""

    tp_allreduce_ms: float = 0.0
    ep_a2a_ms: float = 0.0
    pp_p2p_ms: float = 0.0

    @property
    def total_ms(self) -> float:
        return self.tp_allreduce_ms + self.ep_a2a_ms + self.pp_p2p_ms


class InferenceCollectiveModel:
    """Explicit per-forward communication model for inference."""

    def __init__(
        self,
        model_config: ModelConfig,
        mp_config: ModelParallelConfig,
        coll_config: InferenceCollectiveConfig,
        *,
        num_nodes: int | None = None,
        gpus_per_node: int | None = None,
    ):
        self.mc = model_config
        self.mp = mp_config
        self.cc = coll_config

        self.tp = max(1, mp_config.tensor_model_parallel_size)
        self.pp = max(1, mp_config.pipeline_model_parallel_size)
        self.ep = max(1, getattr(mp_config, "expert_model_parallel_size", 1) or 1)
        self.cp = max(1, getattr(mp_config, "context_model_parallel_size", 1) or 1)
        self.attn_dp = max(1, getattr(mp_config, "attention_data_parallel_size", 1) or 1)
        self.dcp = max(1, getattr(mp_config, "decode_context_parallel_size", 1) or 1)
        self.hidden = model_config.hidden_size
        self.topk = getattr(model_config, "moe_router_topk", 2) or 2

        # DeepEP / SyncFree overlap the EP All-to-All behind expert compute;
        # the exposed A2A cost is scaled down by this fraction (0 = disabled).
        self._deepep_overlap = deepep_overlap_efficiency(model_config)

        # Datasheet interconnect for this GPU, if one is known. It supplies the
        # switched domain the links reach and their bandwidth; an explicit
        # ``hardware_config`` still wins, since that is the user's own machine.
        ic = dict(coll_config.interconnect or {})
        gpn = (
            gpus_per_node
            or int(ic.get("domain_gpus") or 0)
            or int(os.environ.get("GPUS_PER_NODE", "8"))
        )
        nn = num_nodes if num_nodes else int(os.environ.get("NNODES", "1"))
        hw = dict(coll_config.hardware_config or {})
        # A calibrated system profile (JSON object, or a path to one), e.g. the
        # one-parameter xGMI mesh fit {"node_bw": 594.5, "node_topology": "mesh"}.
        prof = os.environ.get("INFERASIM_COLL_HW", "").strip()
        if prof:
            hw.update(json.load(open(prof)) if os.path.isfile(prof) else json.loads(prof))
        for key in ("node_bw", "pod_bw"):
            if key in ic:
                hw.setdefault(key, ic[key])
        hw = hw or None
        self._args = get_default_args(
            num_nodes=nn,
            gpus_per_node=gpn,
            tp=self.tp,
            pp=self.pp,
            ep=self.ep,
            cp=self.cp,
            hardware_config=hw,
        )
        # The EP all-to-all runs over exactly ``ep`` ranks, and that group size is
        # already handed to the collective as its ``gpus`` argument. The ``tp``
        # argument only sets ``hp``, which the collective multiplies by the group
        # size to pick the domain the transfer crosses, so anything above ``1``
        # inflates a collective that ``ep`` ranks alone perform and can price an
        # on-node dispatch at pod bandwidth. ``1`` makes the test read
        # ``ep <= node_size``, the question actually being asked; where ``ep``
        # genuinely exceeds a node, the crossing is still charged.
        self._args_intra = get_default_args(
            num_nodes=1,
            gpus_per_node=gpn,
            tp=self.tp,
            pp=self.pp,
            ep=self.ep,
            cp=self.cp,
            hardware_config=hw,
        )
        self._a2a_args = get_default_args(
            num_nodes=nn,
            gpus_per_node=gpn,
            tp=1,
            pp=self.pp,
            ep=self.ep,
            cp=self.cp,
            hardware_config=hw,
        )

    # -- TP AllReduce ----------------------------------------------------------

    def tp_allreduce_ms(self, batch: int, tokens: int) -> float:
        """2 AllReduces per layer (post-attention + post-MLP), forward only.

        Data-parallel attention pays one instead. Its attention output is
        already whole -- a rank owns entire requests, so there is nothing to sum
        across ranks -- and the tokens it must hand the tensor-parallel MLP are
        gathered before it and scattered back after, which together move exactly
        one AllReduce worth of bytes.
        """
        if self.tp <= 1:
            return 0.0
        msg = max(1, batch * tokens * self.hidden * 2 // self.cp)
        algo = (self.cc.tp_allreduce_algo or "auto").lower()
        if algo == "auto":
            # cm.allreduce already includes the fixed RCCL/NIC overheads.
            us = cm.allreduce(self._args, msg, self.tp, groups=["tp"])
        else:
            if algo == "ring":
                raw = _min_over_protocols(cm.RingAllreduce, self._args, msg, self.tp, ["tp"])
            elif algo == "one_shot":
                raw = _min_over_protocols(
                    cm.single_shot_allreduce, self._args, msg, self.tp, ["tp"]
                )
            elif algo == "two_shot":
                rs = _min_over_protocols(cm.run_reduce_scatter, self._args, msg, self.tp, ["tp"])
                ag = _min_over_protocols(cm.run_allgather, self._args, msg, self.tp, ["tp"])
                raw = rs + ag
            elif algo == "hierarchical":
                raw = _min_over_protocols(
                    cm.hierarchical_allreduce, self._args, msg, self.tp, ["tp"]
                )
            else:
                raw = _min_over_protocols(cm.RingAllreduce, self._args, msg, self.tp, ["tp"])
            # Forced algorithms must carry the same fixed overhead as ``auto``.
            us = raw + _allreduce_overhead_us(self._args, msg, self.tp)
        # Small decode messages: swap the training-scale fixed overhead for the
        # measured intra-node latency floor (no-op for large / multi-node msgs).
        us = self._floor_small_msg_overhead(us, msg, self.tp, is_a2a=False)
        # Custom-op speedups: quick-reduce (small-message quantized AR) and
        # fused RMSNorm+AllReduce both shave the exposed TP-AR time.
        eff = float(self.cc.tp_allreduce_efficiency)
        if getattr(self.cc, "quick_reduce", False):
            eff *= _QUICK_REDUCE_SPEEDUP
        if getattr(self.cc, "fuse_rmsnorm_allreduce", False):
            eff *= _FUSED_RMSNORM_AR_SPEEDUP
        count = 1.0 if self.attn_dp > 1 else 2.0
        return count * (us / 1000.0) * eff

    # -- EP AllToAll -----------------------------------------------------------

    def dcp_combine_ms(self, batch: int, tokens: int) -> float:
        """Decode context parallelism, per attention layer, decode only.

        A rank holds a slice of every sequence's cache, so it gathers the
        queries of every head over the DCP group, attends over its slice, and
        reduce-scatters the partial outputs (with their log-sum-exp) back to
        the heads' owners.
        """
        if self.dcp <= 1:
            return 0.0
        heads = int(getattr(self.mc, "num_attention_heads", 0) or 0)
        width = int(getattr(self.mc, "kv_lora_rank", 0) or 0) or int(
            getattr(self.mc, "kv_channels", 0) or self.hidden // max(1, heads)
        )
        msg = max(1, batch * tokens * heads * width * 2)
        raw = _min_over_protocols(
            cm.run_allgather, self._args, msg, self.dcp, ["tp"]
        ) + _min_over_protocols(cm.run_reduce_scatter, self._args, msg, self.dcp, ["tp"])
        us = raw + 2 * _allreduce_overhead_us(self._args, msg, self.dcp)
        us = self._floor_small_msg_overhead(us, msg, self.dcp, is_a2a=False)
        return us / 1000.0

    def ep_a2a_ms(self, batch: int, tokens: int) -> float:
        """Dispatch + combine AllToAll per MoE layer, forward only."""
        if self.ep <= 1:
            return 0.0
        # Attention-DP splits requests across ranks; this rank only dispatches
        # its share. Replica ``batch`` here prices an 8x AllToAll at DP=8.
        batch = max(1, (int(batch) + self.attn_dp - 1) // self.attn_dp)
        msg = max(1, batch * tokens * self.hidden * self.topk * 2)
        algo = (self.cc.ep_a2a_algo or "auto").lower()
        if algo == "auto":
            # cm.alltoall already includes the fixed RCCL/peer overheads.
            one = cm.alltoall(self._a2a_args, msg, self.ep, groups=["ep"])
        else:
            if algo == "direct":
                raw = _min_over_protocols(cm.run_alltoall, self._a2a_args, msg, self.ep, ["ep"])
            elif algo == "single_shot":
                raw = _min_over_protocols(
                    cm.single_shot_alltoall, self._a2a_args, msg, self.ep, ["ep"]
                )
            elif algo == "hierarchical":
                raw = _min_over_protocols(
                    cm.hierarchical_alltoall, self._a2a_args, msg, self.ep, ["ep"]
                )
            else:
                raw = _min_over_protocols(cm.run_alltoall, self._a2a_args, msg, self.ep, ["ep"])
            # Forced algorithms must carry the same fixed overhead as ``auto``.
            one = raw + _alltoall_overhead_us(self._a2a_args, self.ep)
        # Small decode messages: swap the training-scale fixed overhead for the
        # measured intra-node latency floor (no-op for large / multi-node msgs).
        one = self._floor_small_msg_overhead(one, msg, self.ep, is_a2a=True)
        # dispatch + combine, scaled by the custom-op efficiency and reduced by
        # the DeepEP/SyncFree compute-overlap fraction (exposed A2A only).
        return (
            2.0 * (one / 1000.0) * float(self.cc.ep_a2a_efficiency) * (1.0 - self._deepep_overlap)
        )

    def _floor_small_msg_overhead(self, us: float, msg: int, gpus: int, *, is_a2a: bool) -> float:
        """Replace the training-scale fixed overhead with the measured intra-node floor.

        The base collective model carries a fixed RCCL overhead calibrated for
        training's very large messages (hundreds of MB), where it is negligible
        next to the transfer.  A graph-captured intra-node serving collective does
        not pay it at any size, so it is stripped and the cost becomes
        ``max(measured latency floor, bandwidth transfer)``: the floor dominates
        the small decode messages the microbenchmark covered, and the bandwidth
        term takes over smoothly as the message grows (prefill-scale messages are
        bandwidth-dominated, so the result is unchanged there).

        Applying this continuously matters: keying it on a message-size crossover
        made the fixed overhead reappear in one step, so a 1.25x larger message
        could cost ~8x more and then stay flat — the constant, not bandwidth, was
        setting the price.

        The all-reduce is measured directly on the kernel vLLM runs, so it uses
        that fit in preference to the training model's bandwidth term.

        Multi-node used to keep the base model whole, on the grounds that its NIC
        overheads are real and were not part of the intra-node measurement. The
        network terms are indeed real and are kept. The *fixed* terms are not:
        RCCL setup is algorithm selection, communicator state and the kernel
        launch chain, which is host-side work that does not know whether a peer
        is across the node or across the room. Intra-node measurement prices that
        same work at about 10 us; the training-calibrated constant charges 200,
        plus a 260 us NIC warmup adder for messages below 32 MB. A decode message
        is a couple of MB and a step runs one per layer, so on a 48-layer model
        that was 22 ms of fixed cost per token -- and it never amortises, because
        the adder is charged again on every step of a stream that has already
        moved gigabytes through a warm communicator.

        The visible effect was that TP16 projected 6.5x slower than TP8 for the
        same model, which would have told a Hyperloom search never to go
        multi-node. Note this path remains the least validated part of the model:
        there is no inter-node inference measurement in the artifact set, so the
        network terms here are analytical where the intra-node ones are measured.
        """
        if gpus > self._args.node_size:
            baked = (
                _alltoall_overhead_us(self._args, gpus)
                if is_a2a
                else _allreduce_overhead_us(self._args, msg, gpus)
            )
            floor = _INFER_A2A_OVERHEAD_US if is_a2a else _INFER_AR_OVERHEAD_US
            return max(floor, us - baked)
        measured = (
            _measured_intra_node_a2a_us(msg, gpus)
            if is_a2a
            else _measured_intra_node_ar_us(msg, gpus)
        )
        if measured is not None:
            return measured
        if is_a2a:
            peers = min(gpus - 1, self._args.node_size - 1)
            baked = (
                getattr(self._args, "a2a_intra_sync_overhead", 50.0)
                + getattr(self._args, "a2a_intra_node_peer_lat", 2.5) * max(0, peers)
                + getattr(self._args, "a2a_rccl_overhead_us", 0.0)
            )
            floor = _INFER_A2A_OVERHEAD_US
        else:
            baked = getattr(self._args, "rccl_overhead_us", 0.0)
            floor = _INFER_AR_OVERHEAD_US
        # Bandwidth-only time (strip the training-scale fixed overhead); the floor
        # dominates for tiny messages, the bandwidth term takes over near the knee.
        bandwidth_us = max(0.0, us - baked)
        return max(floor, bandwidth_us)

    # -- Pipeline P2P ----------------------------------------------------------

    def pp_p2p_ms(self, batch: int, tokens: int) -> float:
        """Activation send/recv across (pp-1) stage boundaries per forward, and
        the last stage's sampled tokens back to the first, which cannot
        schedule that micro-batch again until they land."""
        if self.pp <= 1 or not self.cc.include_pp_p2p:
            return 0.0
        msg = max(1, batch * tokens * self.hidden * 2 // self.cp)
        ov = float(getattr(self.cc, "pp_stage_overhead_us", 0.0) or 0.0)
        tok = max(1, batch * 8)
        nodes = self.pp_nodes()
        if nodes <= 1:
            fwd = (self.pp - 1) * (cm.sendrecv(self._args, msg) + ov)
            back = cm.sendrecv(self._args, tok) + ov
            return (fwd + back) / 1000.0
        # Stages are placed contiguously, so a pipeline over n nodes has n-1
        # forward boundaries on the NIC, and the token return from the last
        # stage to the first crosses it too; the rest stay on xGMI.
        cross = nodes - 1
        intra = cm.sendrecv(self._args_intra, msg) + ov
        fwd = (self.pp - 1 - cross) * intra + cross * (self._nic_sendrecv_us(msg) + ov)
        back = self._nic_sendrecv_us(tok) + ov
        return (fwd + back) / 1000.0

    def pp_nodes(self) -> int:
        """Nodes the pipeline spans: ``INFERASIM_PP_NODES`` when the placement
        is given, else as many as ``tp * pp`` GPUs fill."""
        env = os.getenv("INFERASIM_PP_NODES")
        if env:
            return max(1, min(self.pp, int(env)))
        gpn = max(1, int(self._args.node_size))
        return max(1, min(self.pp, -(-self.tp * self.pp // gpn)))

    def _nic_sendrecv_us(self, msg: float) -> float:
        """One point-to-point transfer over a single NIC (us)."""
        a = self._args
        raw_pod = getattr(a, "_raw_pod_bw", a.pod_bw / a.bw_eff)
        bw = raw_pod * getattr(a, "p2p_bw_eff", 0.80)
        return (msg / bw) * 1.0e-3 + a.pod_lat + a.kernel_launch_latency

    # -- KV-cache transfer (disaggregation) ------------------------------------

    def kv_transfer_ms(
        self, kv_bytes: float, *, bw_gbps: float | None = None, latency_us: float = 0.0
    ) -> float:
        """Time to move ``kv_bytes`` of KV cache prefill→decode worker.

        Uses the inter-node (pod) bandwidth from the collective args unless an
        explicit ``bw_gbps`` override is supplied.  ``bw`` is GB/s, so bytes
        are converted to GB; result in ms.
        """
        if kv_bytes <= 0:
            return 0.0
        bw = bw_gbps if (bw_gbps and bw_gbps > 0) else self._args.pod_bw
        bw = max(bw, 1e-6)
        gb = kv_bytes / (1024.0**3)
        return (gb / bw) * 1000.0 + latency_us / 1000.0

    # -- combined per-layer ----------------------------------------------------

    def layer_comm_ms(self, batch: int, tokens: int, *, is_moe: bool) -> CommBreakdown:
        """Per-*layer* comm (TP AllReduce always; EP A2A only on MoE layers).

        A MoE layer keeps the post-expert TP all-reduce only while experts stay
        TP-sharded (``expert_tp = tp // ep > 1``, e.g. EP=1). Once experts are
        fully expert-parallel (``expert_tp == 1``, EP == TP) the expert output
        is combined by the EP all-to-all instead, leaving just the attention
        all-reduce — so charging the full 2-AR + A2A there double-counts.
        """
        tp_ar = self.tp_allreduce_ms(batch, tokens)
        if is_moe and self.ep > 1 and (self.tp // self.ep) <= 1:
            tp_ar *= 0.5  # drop the post-expert AR (combined by the A2A)
        return CommBreakdown(
            tp_allreduce_ms=tp_ar,
            ep_a2a_ms=self.ep_a2a_ms(batch, tokens) if is_moe else 0.0,
            pp_p2p_ms=0.0,
        )
