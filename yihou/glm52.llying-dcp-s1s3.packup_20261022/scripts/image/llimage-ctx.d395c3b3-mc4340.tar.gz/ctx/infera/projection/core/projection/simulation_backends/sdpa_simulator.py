###############################################################################
# Copyright (c) 2025, Advanced Micro Devices, Inc. All rights reserved.
#
# See LICENSE for license information.
###############################################################################

"""
SDPA simulation backend modelling the **FAv3** (Flash Attention v3) kernels.

The forward and backward kernel parameters are extracted from FAv3 kernel
configurations:

  Forward:
      Config : BF16 ; FMHA FWD ; D128 ; 1TG ; 8W ; 32m×8 ; 64n×1 ; 32×32×16
      • 1 Thread-Group, 8 Wavefronts per workgroup (512 threads)
      • Q-tile  = 256 rows   (32m × 8 wavefronts)
      • KV-tile = 64 columns  per loop iteration
      • 64 MFMAs per loop iteration  (QKᵀ + softmax + PV, pipelined)
      • Workgroups = ⌈S / 256⌉ × B × H

  Backward:
      Config : BF16 ; FMHA BWD ; D128 ; 1TG ; 4W ; 16m×1 ; 64n×4 ; A32
      • 1 Thread-Group, 4 Wavefronts per workgroup (256 threads)
      • Q-tile  = 16 rows   per inner loop step
      • KV-tile = 256 columns  per workgroup  (64n × 4)
      • 256 MFMAs per inner-loop iteration  (dV, dP, dS, dQ, dK phases)
      • Workgroups = ⌈S / 256⌉ × B × H
      • Inner-loop iterations = ⌈S / 16⌉  (over Q blocks)

Tile-level simulation using Origami with a 1-CU backend.
Flash Attention is a fused kernel where sub-operations (QKᵀ, softmax, PV)
execute **sequentially** within each workgroup tile.  By running Origami on
a single CU for each per-tile GEMM and then multiplying by the number of
waves (workgroups / N_CU), we capture the additive cost structure and
per-tile wave quantisation effects that a global roofline misses.

**Origami is required** — this simulator cannot operate without it.

In the backward pass, the dQ gradient is accumulated across KV-workgroups
using ``buffer_atomic_add_f32`` (72 atomic instructions in the kernel).
Each KV-workgroup processes all Q positions and atomically adds its partial
dQ contribution, leading to contention proportional to ⌈S / 256⌉ concurrent
writers per dQ cache line.  The atomic overhead is modelled as an additive
cost on top of the compute/memory time.
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass

from infera.projection.core.projection.simulation_backends.base import (
    SDPASimulationBackend,
    SimulationResult,
)

# =========================================================================
# FAv3 kernel tile parameters
# =========================================================================


@dataclass(frozen=True)
class _FAv3TileConfig:
    """Tile & occupancy parameters extracted from a FAv3 kernel."""

    q_tile_m: int  # Q rows per workgroup
    kv_tile_n: int  # K/V positions per loop iteration
    n_wavefronts: int  # Wavefronts per workgroup
    mfma_m: int = 32  # MFMA instruction M
    mfma_n: int = 32  # MFMA instruction N
    mfma_k: int = 16  # MFMA instruction K  (BF16 on gfx950)


# Forward:  256 Q-rows, 64 KV-cols/iter, 8 wavefronts
_FAV3_FWD = _FAv3TileConfig(q_tile_m=256, kv_tile_n=64, n_wavefronts=8)


# =========================================================================
# GPU hardware specs
# =========================================================================


@dataclass
class GPUHardwareSpec:
    """Hardware specification for roofline modelling."""

    # Peak compute throughput in TFLOPS (tera floating-point ops / sec)
    peak_tflops_bf16: float = 1307.0  # MI300X BF16 peak
    peak_tflops_fp16: float = 1307.0
    peak_tflops_fp8: float = 2614.0

    # HBM bandwidth in GB/s
    hbm_bandwidth_gbps: float = 5300.0  # MI300X HBM3

    # Total CUs on the device
    n_cu: int = 304  # MI300X

    # Number of XCDs on the device (cross-die atomics are more expensive)
    n_xcd: int = 8  # MI300X has 8 XCDs


# Achievable fraction of peak HBM bandwidth for the KV stream. Kept equal to the
# GEMM path's ``_ROOFLINE_MEM_EFF`` so a single number governs achievable HBM
# across the whole cost model rather than two that can drift apart.
_SDPA_MEM_EFF = 0.70


# Pre-defined hardware profiles
_HW_PROFILES: dict[str, GPUHardwareSpec] = {
    "mi300x": GPUHardwareSpec(
        peak_tflops_bf16=1307.0,
        peak_tflops_fp16=1307.0,
        peak_tflops_fp8=2614.0,
        hbm_bandwidth_gbps=5300.0,
        n_cu=304,
        n_xcd=8,
    ),
    "gfx942": GPUHardwareSpec(  # same as MI300X
        peak_tflops_bf16=1307.0,
        peak_tflops_fp16=1307.0,
        peak_tflops_fp8=2614.0,
        hbm_bandwidth_gbps=5300.0,
        n_cu=304,
        n_xcd=8,
    ),
    "mi325x": GPUHardwareSpec(  # gfx942 die, HBM3E (use --gpu-clock-mhz to override clock)
        peak_tflops_bf16=1307.0,
        peak_tflops_fp16=1307.0,
        peak_tflops_fp8=2614.0,
        hbm_bandwidth_gbps=6000.0,  # HBM3E ~6 TB/s (vs 5.3 on MI300X)
        n_cu=304,
        n_xcd=8,
    ),
    "mi355x": GPUHardwareSpec(
        peak_tflops_bf16=2384.0,
        peak_tflops_fp16=2384.0,
        peak_tflops_fp8=4768.0,
        hbm_bandwidth_gbps=8000.0,
        n_cu=256,
        n_xcd=4,
    ),
    "gfx950": GPUHardwareSpec(  # same as MI355X
        peak_tflops_bf16=2384.0,
        peak_tflops_fp16=2384.0,
        peak_tflops_fp8=4768.0,
        hbm_bandwidth_gbps=8000.0,
        n_cu=256,
        n_xcd=4,
    ),
    # TEMPORARY, for comparing against NVIDIA's published GB300 numbers only.
    # Blackwell Ultra peaks; the tile model has no Blackwell target, so this
    # reproduces GB300's roofline rather than its kernels.
    "gb300": GPUHardwareSpec(
        peak_tflops_bf16=2250.0,
        peak_tflops_fp16=2250.0,
        peak_tflops_fp8=4500.0,
        hbm_bandwidth_gbps=8000.0,
        n_cu=160,
        n_xcd=8,
    ),
}


def _get_hardware_spec(
    gpu_arch: str | None = None,
    gpu_clock_mhz: int | None = None,
) -> GPUHardwareSpec:
    """Get hardware spec for the given (or detected) GPU architecture.

    If *gpu_clock_mhz* is provided, the profile's TFLOPS values are scaled
    proportionally (compute throughput is linear in clock frequency).
    """
    arch = gpu_arch or os.getenv("INFERASIM_GPU_ARCH", "mi300x")
    arch = arch.lower().strip()
    spec = _HW_PROFILES.get(arch, _HW_PROFILES["mi300x"])

    # Apply clock override — scale TFLOPS linearly
    clock_override = gpu_clock_mhz or (
        int(v) if (v := os.getenv("INFERASIM_GPU_CLOCK_MHZ")) else None
    )
    if clock_override is not None:
        # Derive the profile's implicit clock from a known reference.
        _PROFILE_CLOCK_MHZ = {
            "mi300x": 2100,
            "gfx942": 2100,
            "mi325x": 2100,  # same gfx942 compute die as MI300X
            "mi355x": 2100,
            "gfx950": 2100,
            "mi300a": 2100,
            "gb300": 1900,
        }
        base_clock = _PROFILE_CLOCK_MHZ.get(arch, 2100)
        scale = clock_override / base_clock
        spec = GPUHardwareSpec(
            peak_tflops_bf16=spec.peak_tflops_bf16 * scale,
            peak_tflops_fp16=spec.peak_tflops_fp16 * scale,
            peak_tflops_fp8=spec.peak_tflops_fp8 * scale,
            hbm_bandwidth_gbps=spec.hbm_bandwidth_gbps,  # BW doesn't change with clock
            n_cu=spec.n_cu,
            n_xcd=spec.n_xcd,
        )
    return spec


# =========================================================================
# SDPASimulator — FAv3-based analytical model
# =========================================================================


class SDPASimulator(SDPASimulationBackend):
    """
    Analytical SDPA simulation modelling the FAv3 kernel structure.

    Uses an Origami GEMM backend with ``n_cu=1`` to simulate per-tile
    GEMM execution time.  Flash Attention is modelled as a fused kernel
    where QKᵀ, softmax, and PV are sequential within each workgroup.
    The total time = (per-tile-QKᵀ + per-tile-PV) × num_waves.  This
    naturally captures wave quantisation and per-tile efficiency without
    needing an empirical ``compute_efficiency`` parameter.

    Forward-only (serving): the backward pass is not modelled.

    **Origami is required** — instantiation will fail if the Origami
    backend is not available.
    """

    def __init__(
        self,
        gpu_arch: str | None = None,
        hardware_spec: GPUHardwareSpec | None = None,
        gpu_clock_mhz: int | None = None,
    ):
        """
        Args:
            gpu_arch: GPU architecture string (e.g. "mi300x", "gfx942",
                "mi355x", "gfx950").
            hardware_spec: Override hardware spec directly.
            gpu_clock_mhz: Override the GPU compute clock frequency in MHz.
                If provided, the profile's TFLOPS are scaled proportionally.

        Raises:
            RuntimeError: If the Origami backend is not available.
        """
        self._hw = hardware_spec or _get_hardware_spec(gpu_arch, gpu_clock_mhz)

        # Create the Origami 1-CU backend for tile-level simulation.
        # This is required — SDPA simulation cannot proceed without it.
        self._tile_gemm = self._create_tile_gemm_backend(gpu_arch, gpu_clock_mhz)
        if self._tile_gemm is None:
            raise RuntimeError(
                "SDPASimulator requires the Origami backend but it is not "
                "available.  Install it with: pip install "
                "'git+https://github.com/ROCm/rocm-libraries.git"
                "#subdirectory=shared/origami/python' (building it requires "
                "ROCm/HIP on the host), or ensure infera.projection.core."
                "projection.simulation_backends.origami_backend is importable."
            )

    def name(self) -> str:
        return "sdpa_simulator (FAv3)"

    def is_available(self) -> bool:
        return self._tile_gemm is not None and self._tile_gemm.is_available()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def simulate_sdpa(
        self,
        batch_size: int,
        num_heads: int,
        seq_len: int,
        head_dim: int,
        causal: bool = True,
        dtype: str = "bf16",
        seq_len_kv: int | None = None,
        num_heads_kv: int | None = None,
        head_dim_v: int | None = None,
        kv_bytes_per_token: float | None = None,
    ) -> SimulationResult:
        """
        Simulate FAv3 SDPA execution time using Origami 1-CU tile-level
        simulation parameterised by the actual FAv3 tile configuration.

        Args:
            batch_size: Batch size (B).
            num_heads: Number of query heads (H_Q).
            seq_len: Query sequence length (S_Q).
            head_dim: Head dimension for Q·Kᵀ (D_qk).  For standard
                MHA/GQA this is ``kv_channels``; for MLA this is
                ``qk_head_dim + qk_pos_emb_head_dim`` (e.g. 192).
            causal: Whether causal masking is applied.
            dtype: Data type ("bf16", "fp16", "fp8", "fp32").
            seq_len_kv: Key/Value sequence length (S_K).  Defaults to
                ``seq_len`` (self-attention).  Set differently for
                cross-attention or prefill with separate KV cache length.
            num_heads_kv: Number of KV heads.  Defaults to ``num_heads``
                (MHA).  Set lower for GQA/MQA.
            head_dim_v: Value head dimension for P·V (D_v).  Defaults to
                ``head_dim`` (standard attention).  For MLA set to
                ``v_head_dim`` (e.g. 128).
            kv_bytes_per_token: Bytes the KV cache actually holds per token per
                rank, for the HBM roofline. Defaults to the per-head K+V size,
                which is right for MHA/GQA. MLA must pass its own value: the
                cache holds one compressed latent shared by every head, so
                deriving it from head counts overstates it by ~an order of
                magnitude and turns the roofline into the dominant term.
        """
        B = batch_size
        H_Q = num_heads
        S_Q = seq_len
        S_K = seq_len_kv if seq_len_kv is not None else seq_len
        H_K = num_heads_kv if num_heads_kv is not None else num_heads
        D_qk = head_dim
        D_v = head_dim_v if head_dim_v is not None else head_dim
        bpe = self._bytes_per_element(dtype)

        return self._simulate_tile_level(
            B,
            H_Q,
            S_Q,
            S_K,
            H_K,
            D_qk,
            D_v,
            causal,
            dtype,
            bpe,
            kv_bytes_per_token,
        )

    # ------------------------------------------------------------------
    # Tile-level simulation (primary mode — requires Origami)
    # ------------------------------------------------------------------

    def _create_tile_gemm_backend(
        self,
        gpu_arch: str | None,
        gpu_clock_mhz: int | None,
    ):
        """Try to create an Origami backend with 1 CU for per-tile simulation.

        Returns the backend on success, or ``None`` if Origami is not available.
        """
        try:
            from infera.projection.core.projection.simulation_backends.origami_backend import (
                OrigamiGEMMBackend,
            )

            backend = OrigamiGEMMBackend(
                gpu_arch=gpu_arch,
                gpu_clock_mhz=gpu_clock_mhz,
                n_cu_override=1,
            )
            if backend.is_available():
                is_rank_0 = int(os.getenv("RANK", "0")) == 0
                if is_rank_0:
                    print(
                        "[inferasim:SDPA] Using Origami 1-CU tile-level simulation "
                        "for Flash Attention"
                    )
                return backend
        except Exception as exc:
            # If Origami is not available or fails to initialize, fall back to
            # the analytic SDPA model by returning None here.
            is_rank_0 = int(os.getenv("RANK", "0")) == 0
            if is_rank_0:
                print(
                    "[inferasim:SDPA] Origami 1-CU tile-level simulation disabled "
                    f"due to error: {exc}"
                )
        return None

    def _one_cu_gemm_floor_ms(self, m: int, n: int, k: int, dtype: str) -> float:
        """Lower bound on one CU's time for a GEMM of shape (m, n, k).

        Origami on a 256×64×192 FAv3 tile returns ~30 ns -- 20× below even a
        single CU's peak -- so multiplying by the KV-loop count still leaves
        long-context prefill attention memory-bound on a few hundred kilobytes
        of KV. The loop count is right; the per-tile time was not. Flooring at
        70% of one-CU peak (the same efficiency the HBM roofline uses) is the
        compute analogue of that bound.
        """
        flops = 2.0 * max(1, m) * max(1, n) * max(1, k)
        peak = (
            self._hw.peak_tflops_fp8
            if "fp8" in (dtype or "").lower()
            else self._hw.peak_tflops_bf16
        )
        peak_cu = peak / max(1, self._hw.n_cu)
        return flops / (peak_cu * 1e12 * _SDPA_MEM_EFF) * 1e3

    def _simulate_tile_level(
        self,
        B: int,
        H_Q: int,
        S_Q: int,
        S_K: int,
        H_K: int,
        D_qk: int,
        D_v: int,
        causal: bool,
        dtype: str,
        bpe: int,
        kv_bytes_per_token: float | None = None,
    ) -> SimulationResult:
        """
        Tile-level SDPA simulation using Origami on a single CU.

        Flash Attention is a **fused** kernel — within each workgroup, the
        sub-operations (QKᵀ, softmax, PV) execute **sequentially** and the
        intermediate S/P matrices stay in LDS/registers (never written to
        HBM).  This means the correct timing model is **additive** across
        sub-operations per tile, not a global ``max(compute, memory)``
        roofline.

        Approach:
          1. Simulate each per-tile GEMM using Origami with ``n_cu=1``.
             This captures tile-level wave quantisation, LDS traffic, and
             pipeline effects that a global FLOP-rate model misses.
          2. Sum the per-tile GEMM times (additive, sequential execution).
          3. Multiply by ``num_waves = ⌈workgroups / N_CU⌉`` to account for
             CU-level parallelism across tiles.

        Forward per-workgroup (q_tile rows, sweeps its slice of S_K):
          QKᵀ: Q_tile[q_tile, D_qk] × Kᵀ[D_qk, S_K_tile] → S[q_tile, S_K_tile]
          PV:  P_tile[q_tile, S_K_tile] × V[S_K_tile, D_v] → O[q_tile, D_v]
          Workgroups = ⌈S_Q / q_tile⌉ × B × H_Q × kv_splits
        """
        assert self._tile_gemm is not None
        N_CU = self._hw.n_cu
        # Causal masking only zeros the upper triangle of the S_Q × S_Q suffix
        # block. Scores against a cached prefix (S_K - S_Q, when S_K >= S_Q)
        # are all live, so the 0.5 that is right for a square prefill would
        # halve a 9k-attends-130k suffix for no reason.
        if causal and S_K > 0:
            causal_factor = 1.0 - 0.5 * min(S_Q, S_K) / float(S_K)
        else:
            causal_factor = 1.0

        # ==============================================================
        # FORWARD
        # ==============================================================
        # A flash-decode kernel does not pad its 1-2 query rows out to a full
        # tile; it splits the KV across the idle CUs instead, leaving the step
        # bounded by the KV stream. Charging the pad let the compute term beat
        # the bandwidth roofline below and set the answer.
        q_tile = min(_FAV3_FWD.q_tile_m, S_Q)
        q_wgs = math.ceil(S_Q / q_tile) * B * H_Q
        kv_splits = max(1, N_CU // max(1, q_wgs))
        s_k_tile = max(1, math.ceil(S_K / kv_splits))
        fwd_n_wgs = q_wgs * kv_splits
        fwd_waves = math.ceil(fwd_n_wgs / N_CU)

        # Prefill workgroups run the FAv3 KV loop: 64 KV columns per iteration,
        # sequential inside the workgroup. Passing the whole S_K as the GEMM N
        # dimension was supposed to be equivalent if Origami scaled linearly in
        # N, but it does not -- a 122k-wide N saturates and returns ~the same
        # time as an 8k-wide one, so long-context prefill attention was nearly
        # flat in KV (13 ms at 8k → 21 ms at 122k) while FLOPs grew 15x.
        # ``kv_tile_n`` was already in this file's kernel parameters and in the
        # result metadata; it was never used to price the loop.
        #
        # Decode (S_Q = 1) keeps the existing one-GEMM-over-the-KV-split path:
        # it is HBM-bound, the tests pin that bound, and a 1-row × 64-col tile
        # loop would turn it into a launch-bound count of tiny GEMMs.
        kv_iters = 1
        if S_Q >= _FAV3_FWD.q_tile_m:
            kv_n = _FAV3_FWD.kv_tile_n
            kv_iters = max(1, math.ceil(s_k_tile / kv_n))
            r_fwd_qk = self._tile_gemm.simulate_gemm(
                m=q_tile,
                n=kv_n,
                k=D_qk,
                dtype=dtype,
            )
            r_fwd_pv = self._tile_gemm.simulate_gemm(
                m=q_tile,
                n=D_v,
                k=kv_n,
                dtype=dtype,
            )
            qk_ms = max(
                r_fwd_qk.forward_time_ms, self._one_cu_gemm_floor_ms(q_tile, kv_n, D_qk, dtype)
            )
            pv_ms = max(
                r_fwd_pv.forward_time_ms, self._one_cu_gemm_floor_ms(q_tile, kv_n, D_v, dtype)
            )
            fwd_tile_ms = (qk_ms + pv_ms) * kv_iters * fwd_waves * causal_factor
        else:
            r_fwd_qk = self._tile_gemm.simulate_gemm(
                m=q_tile,
                n=s_k_tile,
                k=D_qk,
                dtype=dtype,
            )
            r_fwd_pv = self._tile_gemm.simulate_gemm(
                m=q_tile,
                n=D_v,
                k=s_k_tile,
                dtype=dtype,
            )
            fwd_tile_ms = (r_fwd_qk.forward_time_ms + r_fwd_pv.forward_time_ms) * fwd_waves

        # ==============================================================
        # METADATA (FLOPs, bytes — for achieved-TFLOPS reporting)
        # ==============================================================
        fwd_flops = (
            2.0 * B * H_Q * S_Q * S_K * D_qk  # QKᵀ
            + 2.0 * B * H_Q * S_Q * S_K * D_v  # PV
            + 5.0 * B * H_Q * S_Q * S_K  # softmax
        ) * causal_factor

        # KV cache footprint per token. MHA/GQA store K and V per KV head; MLA
        # stores a single compressed latent that all heads share, so its caller
        # supplies the real figure instead of letting head counts imply one.
        kv_per_token = (
            float(kv_bytes_per_token)
            if kv_bytes_per_token is not None
            else H_K * (D_qk + D_v) * bpe
        )

        fwd_bytes = (
            B * H_Q * S_Q * D_qk * bpe  # Q
            + B * S_K * kv_per_token  # K and V from the cache
            + B * H_Q * S_Q * D_v * bpe  # O
            + B * H_Q * S_Q * 4  # logsumexp (fp32)
        )

        # HBM roofline on the KV stream.
        #
        # The tile model prices the per-workgroup GEMMs on one CU and scales by
        # wave count, which captures compute but never bounds the result by the
        # bandwidth of the device the KV cache actually lives in. At decode that
        # is the whole cost: S_Q=1, so there is no arithmetic intensity to hide
        # behind, and every resident sequence's K and V must be read from HBM.
        # Without this bound the model returned 0.27 ms for 19.3 GB of KV at
        # batch 256 on gpt-oss-120b — 71 TB/s against an 8 TB/s part.
        #
        # Prefill is compute-bound once the KV loop is priced at the FAv3 tile
        # (64 columns × ⌈S_K/64⌉ iterations); the max is then a no-op there.
        bw = max(1e-6, self._hw.hbm_bandwidth_gbps) * _SDPA_MEM_EFF
        fwd_mem_ms = fwd_bytes / (bw * 1e9) * 1e3
        fwd_time_ms = max(fwd_tile_ms, fwd_mem_ms)

        fwd_achieved_tflops = (fwd_flops / (fwd_time_ms * 1e-3)) / 1e12 if fwd_time_ms > 0 else 0

        return SimulationResult(
            forward_time_ms=fwd_time_ms,
            tflops=fwd_achieved_tflops,
            bandwidth_gbps=((fwd_bytes / (fwd_time_ms * 1e-3)) / 1e9 if fwd_time_ms > 0 else 0),
            metadata={
                "backend": "sdpa_simulator (FAv3 tile-level, Origami 1-CU)",
                # Standard metadata keys (for compatibility)
                "fwd_compute_bound": fwd_tile_ms >= fwd_mem_ms,
                "fwd_compute_ms": fwd_tile_ms,
                "fwd_memory_ms": fwd_mem_ms,
                "fwd_flops": fwd_flops,
                "fwd_bytes": fwd_bytes,
                "seq_len_q": S_Q,
                "seq_len_kv": S_K,
                "num_heads_q": H_Q,
                "num_heads_kv": H_K,
                "causal": causal,
                # Tile-level details
                "fwd_waves": fwd_waves,
                "fwd_n_workgroups": fwd_n_wgs,
                "fwd_kv_iters": kv_iters,
                "fwd_qk_per_tile_ms": r_fwd_qk.forward_time_ms,
                "fwd_pv_per_tile_ms": r_fwd_pv.forward_time_ms,
                "n_cu": N_CU,
                # FAv3 tile parameters
                "fwd_q_tile_m": _FAV3_FWD.q_tile_m,
                "fwd_kv_tile_n": _FAV3_FWD.kv_tile_n,
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _bytes_per_element(self, dtype: str) -> int:
        return {"bf16": 2, "fp16": 2, "fp32": 4, "fp8": 1}.get(dtype, 2)
