###############################################################################
# Copyright (c) 2025, Advanced Micro Devices, Inc. All rights reserved.
#
# See LICENSE for license information.
###############################################################################

import logging
import os

from infera.projection.core.projection.base_module_profiler import BaseModuleProfiler
from infera.projection.core.projection.profiler_spec import ModuleProfilerSpec
from infera.projection.core.projection.training_config import TrainingConfig

from . import collective_model as cm
from .attention import AttentionProfiler
from .collective_args import get_default_args
from .dense_mlp import DenseMLPProfiler
from .layer_norm import LayerNormProfiler
from .moe_mlp import MoEMLPProfiler
from .residual_add import ResidualAddProfiler
from .router import RouterProfiler

# ── Fallback HBM bandwidth for elementwise overhead estimation ──
_FALLBACK_HBM_BW_GBPS = 5300.0  # MI300X default
_LOGGER = logging.getLogger(__name__)


def _estimate_layernorm_residual_time_ms(
    config, batch_size: int, seq_len: int, gemm_backend=None
) -> float:
    """
    Estimate the combined LayerNorm (×2) and Residual Add (×2) forward time
    per transformer layer, returning ``fwd_ms``.

    Each transformer layer has:
    - 2 LayerNorm ops  (input LN, pre-MLP LN)
    - 2 Residual Adds  (post-attention, post-MLP)

    These are element-wise, memory-bandwidth-bound operations.  Each reads
    and writes a tensor of shape ``[batch_tokens, hidden_size]`` in BF16.

    We use the same HBM bandwidth efficiency as the activation function
    model (``_ACTIVATION_BW_FRACTION``) since these are similar sequential
    element-wise streaming operations over contiguous buffers.

    **Forward memory passes**:
      - 2× RMSNorm fwd: read input + write output + write variance ≈ 3 passes each → 6
      - 2× Residual Add fwd: read 2 inputs + write output ≈ 3 passes each → 6
      - Total: 12 passes
    """
    from .moe_mlp import _ACTIVATION_BW_FRACTION

    tp = config.model_parallel_config.tensor_model_parallel_size
    cp = getattr(config.model_parallel_config, "context_parallel_size", 1) or 1
    hidden = config.model_config.hidden_size
    batch_tokens = batch_size * seq_len // tp // cp
    bytes_per_el = 2  # BF16

    # Get peak HBM bandwidth from the GEMM backend if available
    peak_hbm = _FALLBACK_HBM_BW_GBPS
    if gemm_backend is not None:
        bw = getattr(gemm_backend, "hbm_bandwidth_gbps", None)
        if bw is not None:
            peak_hbm = bw

    tensor_bytes = batch_tokens * hidden * bytes_per_el
    eff_bw = peak_hbm * _ACTIVATION_BW_FRACTION  # GB/s

    # Forward: 12 memory passes
    fwd_ms = 12 * tensor_bytes / (eff_bw * 1e6)

    return fwd_ms


def _attention_allreduce_dropped(config) -> int:
    """1 when data-parallel attention removes a layer's attention all-reduce.

    A DP-attention rank owns whole requests rather than a slice of every
    request's heads, so its attention output needs no cross-rank sum. The tokens
    it owes the tensor-parallel MLP are gathered before it and scattered back
    after, which costs one all-reduce worth of bytes -- exactly what the MLP's
    own reduction already charges.
    """
    mp = config.model_parallel_config
    return 1 if max(1, getattr(mp, "attention_data_parallel_size", 1) or 1) > 1 else 0


def _dense_tp_allreduce_count(config) -> int:
    """Number of TP all-reduces on a dense layer's forward (attention + MLP)."""
    return 2 - _attention_allreduce_dropped(config)


def _moe_tp_allreduce_count(config) -> int:
    """Number of TP all-reduces on a MoE layer's forward (0, 1 or 2).

    A dense/MoE layer has two row-parallel reductions: after attention and
    after the MLP/expert down-projection. The expert down-projection is only
    TP-sharded (and thus TP-all-reduced) while ``expert_tp = tp // ep > 1``
    (e.g. EP=1: experts sharded across the whole TP group). Once experts are
    fully expert-parallel (``expert_tp == 1``, EP == TP) their outputs are
    combined by the EP all-to-all *instead of* a TP all-reduce, so only the
    attention all-reduce remains. Charging 2 TP-AR + A2A at EP>1 double-counts
    the expert reduction and makes EP look slower than silicon.
    """
    mp = config.model_parallel_config
    tp = max(1, mp.tensor_model_parallel_size)
    ep = max(1, getattr(mp, "expert_model_parallel_size", 1) or 1)
    base = 2 if (tp // ep) > 1 else 1
    return max(0, base - _attention_allreduce_dropped(config))


def _estimate_tp_allreduce_time_ms(config, batch_size: int, seq_len: int) -> float:
    """
    Estimate TP AllReduce time for a single AllReduce operation (in ms).

    In Megatron-style tensor parallelism each transformer layer performs
    2 AllReduces in forward (after attention row-parallel output projection,
    after MLP row-parallel down projection) and 2 in backward.
    With sequence parallelism the AllReduce is replaced by
    ReduceScatter + AllGather pairs, but the total data volume is equivalent.

    Returns 0.0 when TP <= 1 (no communication needed).
    """
    tp = config.model_parallel_config.tensor_model_parallel_size
    if tp <= 1:
        return 0.0

    cp = getattr(config.model_parallel_config, "context_parallel_size", 1) or 1
    pp = config.model_parallel_config.pipeline_model_parallel_size
    ep = getattr(config.model_parallel_config, "expert_model_parallel_size", 1) or 1
    hidden_size = config.model_config.hidden_size

    # Message size: activations after row-parallel projection
    # Shape: [batch_size * seq_len / CP, hidden_size], BF16 (2 bytes)
    message_size_bytes = batch_size * seq_len * hidden_size * 2 // cp

    # Setup collective communication args
    gpus_per_node = int(os.environ.get("GPUS_PER_NODE", "8"))
    num_nodes = int(os.environ.get("NNODES", "1"))

    coll_args = get_default_args(
        num_nodes=num_nodes,
        gpus_per_node=gpus_per_node,
        tp=tp,
        pp=pp,
        ep=ep,
        cp=cp,
    )

    # TP AllReduce is across tp ranks (typically intra-node)
    ar_time_us = cm.allreduce(coll_args, message_size_bytes, tp, groups=["tp"])
    return ar_time_us / 1000.0  # Convert microseconds → milliseconds


def _estimate_moe_a2a_time_ms(config, batch_size: int, seq_len: int, gemm_backend=None) -> float:
    """
    Estimate MoE All-to-All time (dispatch + combine) per layer per direction (in ms).

    Each MoE layer performs two A2A operations per direction:
      1. **Dispatch**: scatter tokens to the EP ranks that own the assigned experts.
      2. **Combine**: gather expert outputs back to the originating ranks.

    In benchmark mode this cost is captured inside the measured layer time.
    In simulation mode we must add it explicitly because the layer profiler
    only simulates GEMM / SDPA compute and TP AllReduce.

    This function returns the analytical A2A communication time only. Routing
    overhead (token permutation) is kept separate and not included here. The
    analytical model provides the base communication time for scaling purposes.

    Returns 0.0 when EP <= 1 (all experts are local, no A2A needed).
    """
    ep = getattr(config.model_parallel_config, "expert_model_parallel_size", 1) or 1
    if ep <= 1:
        return 0.0

    tp = config.model_parallel_config.tensor_model_parallel_size
    pp = config.model_parallel_config.pipeline_model_parallel_size
    cp = getattr(config.model_parallel_config, "context_parallel_size", 1) or 1
    hidden_size = config.model_config.hidden_size
    moe_router_topk = getattr(config.model_config, "moe_router_topk", 2)

    # A2A message size: each rank sends/receives all routed tokens
    # Shape: [batch_size * seq_len * topk, hidden_size], BF16 (2 bytes)
    tokens_per_batch = batch_size * seq_len
    dispatch_size_bytes = tokens_per_batch * hidden_size * moe_router_topk * 2

    # Setup collective communication args
    gpus_per_node = int(os.environ.get("GPUS_PER_NODE", "8"))
    num_nodes = int(os.environ.get("NNODES", "1"))

    coll_args = get_default_args(
        num_nodes=num_nodes,
        gpus_per_node=gpus_per_node,
        tp=tp,
        pp=pp,
        ep=ep,
        cp=cp,
    )

    # Analytical A2A communication time (base model only)
    a2a_dispatch_us = cm.alltoall(coll_args, dispatch_size_bytes, ep, groups=["ep"])
    a2a_combine_us = cm.alltoall(coll_args, dispatch_size_bytes, ep, groups=["ep"])
    a2a_ms = (a2a_dispatch_us + a2a_combine_us) / 1000.0

    return a2a_ms


# Transformer Layer Data Flow
#
#             +----------------+
#             |     Input      |
#             +----------------+
#                     | ----------------------
#        +-------------------------+         |
#        |     Input LayerNorm     |         |
#        +-------------------------+         |
#                     |                      |
#        +------------------------+          |
#        |     Self-Attention     |          |
#        +------------------------+          |
#                     |                      |
#            +-----------------+             |
#            |     Dropout     |             |
#            +-----------------+             |
#                     |                      |
#                     o ---------------------|
#         +----------------------+
#         |     Residual Add     |
#         +----------------------+
#                     | ----------------------
#        +-------------------------+         |
#        |    Pre-mlp LayerNorm    |         |
#        +-------------------------+         |
#                     |                      |
#              +-------------+               |
#              |     MLP     |               |
#              +-------------+               |
#                     |                      |
#            +-----------------+             |
#            |     Dropout     |             |
#            +-----------------+             |
#                     |                      |
#                     o ---------------------|
#         +----------------------+
#         |     Residual Add     |
#         +----------------------+
#                     |
#             +----------------+
#             |     Output      |
#             +----------------+


class DenseTransformerLayerProfiler(BaseModuleProfiler):
    def __init__(self, config, sub_profilers=None):
        super().__init__(config, sub_profilers)
        self.layer_module = None  # Will be set during benchmarking
        self._cached_results = None  # Cache for (forward_time, backward_time, activation_memory)
        self._cache_key = None  # Cache key (batch_size, seq_len)
        self._gemm_backend = None  # Optional: GEMM simulation backend
        self._sdpa_backend = None  # Optional: SDPA simulation backend

    def get_sub_profiler(self, name: str):
        return self.sub_profilers.get(name)

    def set_simulation_backends(self, gemm_backend=None, sdpa_backend=None):
        """Set simulation backends and propagate to sub-profilers."""
        self._gemm_backend = gemm_backend
        self._sdpa_backend = sdpa_backend
        # Propagate to sub-profilers
        if "self_attention" in self.sub_profilers:
            attn = self.sub_profilers["self_attention"]
            if gemm_backend is not None and hasattr(attn, "set_gemm_backend"):
                attn.set_gemm_backend(gemm_backend)
            if sdpa_backend is not None and hasattr(attn, "set_sdpa_backend"):
                attn.set_sdpa_backend(sdpa_backend)
        if "mlp" in self.sub_profilers:
            mlp = self.sub_profilers["mlp"]
            if gemm_backend is not None and hasattr(mlp, "set_gemm_backend"):
                mlp.set_gemm_backend(gemm_backend)
        # Invalidate cache
        self._cached_results = None
        self._cache_key = None

    def set_layer_module(self, layer_module):
        """Set the actual transformer layer module for benchmarking."""
        self.layer_module = layer_module
        self.sub_profilers["self_attention"].set_module(layer_module.self_attention)
        self.sub_profilers["mlp"].set_module(layer_module.mlp)

        # Invalidate cache when layer changes
        self._cached_results = None
        self._cache_key = None

    def set_inference_phase(self, phase, kv_seq_len=None):
        """Propagate forward-only inference phase to the attention profiler.

        The layer-level cache is keyed only on ``(batch, seq_len)`` so it
        must be invalidated whenever the attention KV length changes (e.g.
        between decode steps).
        """
        attn = self.sub_profilers.get("self_attention")
        if attn is not None and hasattr(attn, "set_inference_phase"):
            attn.set_inference_phase(phase, kv_seq_len)
        self._cached_results = None
        self._cache_key = None

    def estimated_num_params(self, rank: int | None = None) -> int:
        return (
            self.sub_profilers["layer_norm"].estimated_num_params(rank) * 3
            + self.sub_profilers["self_attention"].estimated_num_params(rank)
            + self.sub_profilers["mlp"].estimated_num_params(rank)
            + self.sub_profilers["residual_add"].estimated_num_params(rank) * 2
        )

    def estimated_activation_memory(self, batch_size: int, seq_len: int) -> int:
        return (
            self.sub_profilers["layer_norm"].estimated_activation_memory(batch_size, seq_len) * 3
            + self.sub_profilers["self_attention"].estimated_activation_memory(batch_size, seq_len)
            + self.sub_profilers["mlp"].estimated_activation_memory(batch_size, seq_len)
            + self.sub_profilers["residual_add"].estimated_activation_memory(batch_size, seq_len)
            * 2
        )

    def _get_simulated_results(self, batch_size: int, seq_len: int) -> tuple[float, int]:
        """Aggregate simulated results from sub-profilers, including TP AllReduce."""
        attn_fwd = self.sub_profilers["self_attention"].measured_forward_time(batch_size, seq_len)
        mlp_fwd = self.sub_profilers["mlp"].measured_forward_time(batch_size, seq_len)

        # Add TP AllReduce communication overhead (simulation only).
        # Each transformer layer has 2 AllReduces per forward:
        #   - After attention row-parallel output projection
        #   - After MLP row-parallel down projection
        # (With sequence parallelism these become RS+AG pairs with equal volume.)
        tp_ar_ms = _estimate_tp_allreduce_time_ms(self.config, batch_size, seq_len)

        # Add LayerNorm + Residual Add overhead (simulation only).
        # These element-wise ops are missing from GEMM/SDPA simulation.
        ln_res_fwd_ms = _estimate_layernorm_residual_time_ms(
            self.config, batch_size, seq_len, self._gemm_backend
        )

        fwd_time = (
            attn_fwd + mlp_fwd + _dense_tp_allreduce_count(self.config) * tp_ar_ms + ln_res_fwd_ms
        )
        activation_memory = self.estimated_activation_memory(batch_size, seq_len)
        return (fwd_time, activation_memory)

    def _get_benchmark_results(self, batch_size: int, seq_len: int) -> tuple[float, int]:
        """Get or compute benchmark results (cached)."""
        cache_key = (batch_size, seq_len)
        if self._cached_results is None or self._cache_key != cache_key:
            if self._gemm_backend is not None or self._sdpa_backend is not None:
                # Use simulation mode
                self._cached_results = self._get_simulated_results(batch_size, seq_len)
            else:
                # Imported here, not at module scope: this pulls in torch, which
                # costs ~0.66 s and is only needed to benchmark on a real GPU. A
                # simulate-only projection should not pay for it -- Hyperloom
                # spawns one process per config, where that import dwarfed the
                # ~28 ms the projection takes.
                from .utils import benchmark_layer

                # Get TransformerConfig from the layer module itself (has fp8 setting)
                transformer_config = getattr(self.layer_module, "config", None)
                self._cached_results = benchmark_layer(
                    self.layer_module,
                    [(seq_len, batch_size, self.config.model_config.hidden_size)],
                    transformer_config=transformer_config,
                )
            self._cache_key = cache_key
        return self._cached_results

    def measured_forward_time(self, batch_size: int, seq_len: int) -> float:
        forward_time, _ = self._get_benchmark_results(batch_size, seq_len)
        return forward_time

    def measured_activation_memory(self, batch_size: int, seq_len: int) -> int:
        _, activation_memory = self._get_benchmark_results(batch_size, seq_len)
        return activation_memory


class MoETransformerLayerProfiler(BaseModuleProfiler):
    def __init__(self, config, sub_profilers=None):
        super().__init__(config, sub_profilers)
        self.layer_module = None  # Will be set during benchmarking
        self._cached_results = None  # Cache for (forward_time, backward_time, activation_memory)
        self._cache_key = None  # Cache key (batch_size, seq_len)
        self._gemm_backend = None  # Optional: GEMM simulation backend
        self._sdpa_backend = None  # Optional: SDPA simulation backend

    def get_sub_profiler(self, name: str):
        return self.sub_profilers.get(name)

    def set_simulation_backends(self, gemm_backend=None, sdpa_backend=None):
        """Set simulation backends and propagate to sub-profilers."""
        self._gemm_backend = gemm_backend
        self._sdpa_backend = sdpa_backend
        # Propagate to sub-profilers
        if "self_attention" in self.sub_profilers:
            attn = self.sub_profilers["self_attention"]
            if gemm_backend is not None and hasattr(attn, "set_gemm_backend"):
                attn.set_gemm_backend(gemm_backend)
            if sdpa_backend is not None and hasattr(attn, "set_sdpa_backend"):
                attn.set_sdpa_backend(sdpa_backend)
        if "mlp" in self.sub_profilers:
            mlp = self.sub_profilers["mlp"]
            if gemm_backend is not None and hasattr(mlp, "set_gemm_backend"):
                mlp.set_gemm_backend(gemm_backend)
        # Invalidate cache
        self._cached_results = None
        self._cache_key = None

    def set_layer_module(self, layer_module):
        """Set the actual transformer layer module for benchmarking."""
        self.layer_module = layer_module
        self.sub_profilers["self_attention"].set_module(layer_module.self_attention)
        self.sub_profilers["mlp"].set_module(layer_module.mlp)

        # Invalidate cache when layer changes
        self._cached_results = None
        self._cache_key = None

    def set_inference_phase(self, phase, kv_seq_len=None):
        """Propagate forward-only inference phase to the attention profiler.

        The layer-level cache is keyed only on ``(batch, seq_len)`` so it
        must be invalidated whenever the attention KV length changes (e.g.
        between decode steps).
        """
        attn = self.sub_profilers.get("self_attention")
        if attn is not None and hasattr(attn, "set_inference_phase"):
            attn.set_inference_phase(phase, kv_seq_len)
        self._cached_results = None
        self._cache_key = None

    def estimated_num_params(self, rank: int | None = None) -> int:
        return (
            self.sub_profilers["layer_norm"].estimated_num_params(rank) * 3
            + self.sub_profilers["self_attention"].estimated_num_params(rank)
            + self.sub_profilers["mlp"].estimated_num_params(rank)
            + self.sub_profilers["router"].estimated_num_params(rank)
            + self.sub_profilers["residual_add"].estimated_num_params(rank) * 2
        )

    def estimated_activation_memory(self, batch_size: int, seq_len: int) -> int:
        return (
            self.sub_profilers["layer_norm"].estimated_activation_memory(batch_size, seq_len) * 3
            + self.sub_profilers["self_attention"].estimated_activation_memory(batch_size, seq_len)
            + self.sub_profilers["mlp"].estimated_activation_memory(batch_size, seq_len)
            + self.sub_profilers["router"].estimated_activation_memory(batch_size, seq_len)
            + self.sub_profilers["residual_add"].estimated_activation_memory(batch_size, seq_len)
            * 2
        )

    def _get_simulated_results(self, batch_size: int, seq_len: int) -> tuple[float, int]:
        """Aggregate simulated results from sub-profilers.

        Includes TP AllReduce, MoE All-to-All communication overhead, and
        LayerNorm / Residual Add element-wise overhead that would be captured
        in the measured layer time during benchmark mode but must be added
        explicitly in simulation mode.
        """
        attn_fwd = self.sub_profilers["self_attention"].measured_forward_time(batch_size, seq_len)
        mlp_fwd = self.sub_profilers["mlp"].measured_forward_time(batch_size, seq_len)

        # Add TP AllReduce communication overhead (simulation only).
        # Each transformer layer has 2 AllReduces per forward:
        #   - After attention row-parallel output projection
        #   - After MLP row-parallel down projection
        # (With sequence parallelism these become RS+AG pairs with equal volume.)
        tp_ar_ms = _estimate_tp_allreduce_time_ms(self.config, batch_size, seq_len)

        # Add MoE All-to-All communication overhead (simulation only).
        # Each MoE layer performs dispatch A2A + combine A2A per direction.
        # In benchmark mode this is captured in the measured layer time;
        # in simulation mode the layer profiler only computes GEMM / SDPA
        # so we must add it here.
        moe_a2a_ms = _estimate_moe_a2a_time_ms(self.config, batch_size, seq_len, self._gemm_backend)

        # Add LayerNorm + Residual Add overhead (simulation only).
        # These element-wise ops are missing from GEMM/SDPA simulation.
        ln_res_fwd_ms = _estimate_layernorm_residual_time_ms(
            self.config, batch_size, seq_len, self._gemm_backend
        )

        # 2 TP all-reduces only while experts stay TP-sharded (EP=1); at EP==TP
        # the expert output is combined by the A2A, leaving just attention's AR.
        n_moe_ar = _moe_tp_allreduce_count(self.config)
        fwd_time = attn_fwd + mlp_fwd + n_moe_ar * tp_ar_ms + moe_a2a_ms + ln_res_fwd_ms
        activation_memory = self.estimated_activation_memory(batch_size, seq_len)
        return (fwd_time, activation_memory)

    def _get_benchmark_composite_results(self, batch_size: int, seq_len: int) -> tuple[float, int]:
        """Aggregate measured sub-profiler times (mirrors :meth:`_get_simulated_results`).

        Isolated attention + decomposed MoE MLP benches match Origami simulation
        and measured serving much more closely than a whole-layer bench.
        """
        attn_fwd = self.sub_profilers["self_attention"].measured_forward_time(batch_size, seq_len)
        mlp_fwd = self.sub_profilers["mlp"].measured_forward_time(batch_size, seq_len)
        tp_ar_ms = _estimate_tp_allreduce_time_ms(self.config, batch_size, seq_len)
        ln_res_fwd_ms = _estimate_layernorm_residual_time_ms(
            self.config, batch_size, seq_len, self._gemm_backend
        )
        # Decomposed MoE MLP benchmark already includes measured dispatch/combine A2A.
        fwd_time = attn_fwd + mlp_fwd + 2 * tp_ar_ms + ln_res_fwd_ms
        activation_memory = self.estimated_activation_memory(batch_size, seq_len)
        return (fwd_time, activation_memory)

    def _get_benchmark_results(self, batch_size: int, seq_len: int) -> tuple[float, int]:
        """Get or compute benchmark results (cached)."""
        cache_key = (batch_size, seq_len)
        if self._cached_results is None or self._cache_key != cache_key:
            if self._gemm_backend is not None or self._sdpa_backend is not None:
                # Use simulation mode
                self._cached_results = self._get_simulated_results(batch_size, seq_len)
            elif os.environ.get("INFERASIM_BENCH_MOE_LAYER_WHOLE", "0").strip().lower() in (
                "1",
                "true",
                "yes",
            ):
                # Legacy whole-layer timing (often ~1.5-1.7x pessimistic on backward).
                transformer_config = getattr(self.layer_module, "config", None)
                routing_restores = []
                from .utils import (
                    _install_balanced_routing_patches,
                    _kernel_pad_enabled,
                    benchmark_layer,
                )

                if _kernel_pad_enabled():
                    routing_restores, _ = _install_balanced_routing_patches(self.layer_module)
                try:
                    self._cached_results = benchmark_layer(
                        self.layer_module,
                        [(seq_len, batch_size, self.config.model_config.hidden_size)],
                        transformer_config=transformer_config,
                    )
                finally:
                    for restore in routing_restores:
                        try:
                            restore()
                        except Exception:
                            # Best-effort cleanup: restore failures should not fail benchmarking.
                            _LOGGER.debug(
                                "Failed to restore routing patch during cleanup.", exc_info=True
                            )
            else:
                self._cached_results = self._get_benchmark_composite_results(batch_size, seq_len)
            self._cache_key = cache_key
        return self._cached_results

    def measured_forward_time(self, batch_size: int, seq_len: int) -> float:
        forward_time, _ = self._get_benchmark_results(batch_size, seq_len)
        return forward_time

    def measured_activation_memory(self, batch_size: int, seq_len: int) -> int:
        _, activation_memory = self._get_benchmark_results(batch_size, seq_len)
        return activation_memory


def get_dense_transformer_layer_profiler_spec(
    config: TrainingConfig,
) -> "ModuleProfilerSpec":
    return ModuleProfilerSpec(
        profiler=DenseTransformerLayerProfiler,
        config=config,
        sub_profiler_specs={
            "layer_norm": LayerNormProfiler,
            "self_attention": AttentionProfiler,
            "residual_add": ResidualAddProfiler,
            "mlp": DenseMLPProfiler,
        },
    )


def get_moe_transformer_layer_profiler_spec(
    config: TrainingConfig,
) -> "ModuleProfilerSpec":
    return ModuleProfilerSpec(
        profiler=MoETransformerLayerProfiler,
        config=config,
        sub_profiler_specs={
            "layer_norm": LayerNormProfiler,
            "self_attention": AttentionProfiler,
            "residual_add": ResidualAddProfiler,
            "router": RouterProfiler,
            "mlp": MoEMLPProfiler,
        },
    )
