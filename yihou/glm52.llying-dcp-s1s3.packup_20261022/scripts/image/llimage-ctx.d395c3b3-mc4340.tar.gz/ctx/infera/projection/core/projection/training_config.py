###############################################################################
# Copyright (c) 2025, Advanced Micro Devices, Inc. All rights reserved.
#
# See LICENSE for license information.
###############################################################################

import os
from dataclasses import dataclass, field, fields


@dataclass
class RuntimeConfig:
    global_batch_size: int = 1
    micro_batch_size: int = 1
    sequence_length: int = 0
    data_parallel_size: int = 1


@dataclass
class ModelParallelConfig:
    tensor_model_parallel_size: int = 1
    pipeline_model_parallel_size: int = 1
    virtual_pipeline_model_parallel_size: int = 1
    context_model_parallel_size: int = 1
    expert_model_parallel_size: int = 1
    # Serving-only axis: attention runs data-parallel over the batch, each rank
    # holding the whole KV for its own share of requests, while the MLP/MoE stay
    # tensor/expert parallel. Standard for MLA models, whose latent KV is
    # replicated by tensor parallelism rather than sharded by it.
    attention_data_parallel_size: int = 1
    # Serving-only axis: one sequence's *context* is split across this many
    # ranks during decode, so a rank stores a slice of each request's KV
    # instead of all of it. The only axis that shrinks an MLA cache, since
    # tensor parallelism replicates the latent rather than sharding it.
    decode_context_parallel_size: int = 1
    use_torch_fsdp2: bool = False
    use_distributed_optimizer: bool = False
    overlap_grad_reduce: bool = True
    overlap_param_gather: bool = False
    # Pipeline stage layer distribution
    decoder_first_pipeline_num_layers: int = None
    decoder_last_pipeline_num_layers: int = None
    pipeline_model_parallel_layout: str = None
    # Recomputation settings
    recompute_granularity: str = None  # "full" or "selective"
    recompute_num_layers: int = 0
    # Megatron selective block recompute: global transformer layer indices (0..num_layers-1)
    recompute_layer_ids: list[int] | None = None
    # Precision-aware optimizer (Megatron `--use-precision-aware-optimizer`).
    # When enabled the optimizer state dtypes follow the *_dtype fields below;
    # the projection's bytes-per-param formula uses these to size the static
    # block correctly instead of assuming default fp32 main params + fp32 m + fp32 v.
    use_precision_aware_optimizer: bool = False
    main_grads_dtype: str = "fp32"  # fp32 | bf16 | fp16
    exp_avg_dtype: str = "fp32"  # 1st moment dtype (fp32 | bf16 | fp16)
    exp_avg_sq_dtype: str = "fp32"  # 2nd moment dtype (fp32 | bf16 | fp16)


@dataclass
class ModelConfig:
    num_layers: int = 0
    hidden_size: int = 0
    padded_vocab_size: int = 0
    ffn_hidden_size: int = 0
    # attention
    num_attention_heads: int = 0
    kv_channels: int = 0
    group_query_attention: bool = False
    num_query_groups: int = 0
    qk_layernorm: bool = False
    multi_latent_attention: bool = False
    use_flash_attn: bool = False
    qk_head_dim: int = 0
    qk_pos_emb_head_dim: int = 0
    v_head_dim: int = 0
    q_lora_rank: int = 0
    kv_lora_rank: int = 0
    # Sliding-window (local) attention: each query attends to at most the last
    # ``sink_sliding_window`` KV tokens (0 = full/global attention). Several
    # models (gpt-oss, Mistral, Gemma-2/3, Qwen2.5) cap the attention span this
    # way, which bounds both decode attention compute and KV-cache footprint at
    # long context. ``sink_window_even_layers_only`` models the common
    # interleave where only alternating layers are windowed (the rest stay
    # full-attention), i.e. half the layers.
    sink_sliding_window: int = 0
    sink_window_even_layers_only: bool = False
    # Hybrid compressed attention (DeepSeek-V4). ``compress_ratios`` is a
    # per-layer schedule naming which attention branch each layer runs, using
    # the same 0 / 4 / 128 encoding the reference implementation accepts (see
    # ``_COMPRESS_RATIO_LAYER_TYPES``). It is a list or the ``"[...]"`` string
    # form the checkpoint ships. The remaining fields size the branches: a
    # compressed layer attends over its local window plus a pool of one entry
    # per ``compress_rate`` source tokens, and a CSA layer additionally runs a
    # lightning indexer (``index_n_heads`` x ``index_head_dim``) over that whole
    # pool to pick ``index_topk`` of it.
    hybrid_attention_enabled: bool = False
    compress_ratios: object = None
    index_topk: int = 0
    index_n_heads: int = 0
    index_head_dim: int = 0
    attn_sliding_window: int = 0
    # Hybrid linear attention (Kimi Delta Attention / gated delta net): a
    # count of layers that keep a fixed-size recurrent state instead of a
    # per-token KV cache. ``linear_attention_layers`` is the explicit count
    # (Kimi-K3: 69 of 93). ``linear_attention_freq`` is the Qwen-style
    # interleave -- full attention every N layers, the rest linear. The
    # head dim is the recurrent state's extent: a d×d state per head has
    # the same arithmetic as attending to ``d`` keys, so it is also the
    # FLOP-equivalent KV length of those layers. None of these are knobs.
    linear_attention_layers: int = 0
    linear_attention_head_dim: int = 0
    linear_attention_conv_kernel: int = 0
    linear_attention_freq: int = 0
    # Which linear layer it is, for pricing its time from its own operations
    # rather than as an attention layer over ``d`` keys: ``"kda"`` (Kimi Delta
    # Attention) or ``"gdn"`` (gated delta net, Qwen3-Next / Qwen3.5). Empty
    # keeps the attention-equivalent blend. The head counts and dims default
    # to ``num_attention_heads`` and ``linear_attention_head_dim``; GDN sets
    # more value heads than key heads, and the state is one dk×dv matrix per
    # value head.
    linear_attention_kind: str = ""
    linear_num_key_heads: int = 0
    linear_num_value_heads: int = 0
    linear_key_head_dim: int = 0
    linear_value_head_dim: int = 0
    # KDA's output gate is either one full hidden->heads*d projection or a
    # rank-``head_dim`` pair; Kimi-K3 ships the full one.
    linear_attention_full_rank_gate: bool = False
    # A sigmoid gate on the attention output, ``o * sigmoid(x @ W_g)``, on the
    # full-attention layers (Qwen3.5 GQA, Kimi-K3 MLA). Its projection is as
    # wide as the attention output, so it is one more O-sized weight read.
    attention_output_gate: bool = False
    # Latent MoE (Kimi-K3): routed experts act on a ``moe_latent_hidden_size``
    # projection of the residual. The expert GEMMs can be sized in residual
    # width equivalents; the hidden->latent and latent->hidden projections
    # around them, and the narrower rows the permutation moves, cannot.
    moe_latent_hidden_size: int = 0
    # Attention residuals (Kimi-K3): before attention and before the MLP, each
    # layer mixes the outputs of every ``attn_res_block_size``-layer block so
    # far with a softmax over them, in place of a plain residual add.
    attn_res_block_size: int = 0
    # Native sparse attention's indexer keeps a *second* per-token cache. To
    # choose which blocks to attend to it scores the query against one small
    # index key per past token, and that key has to be stored, so a token's
    # real footprint is the KV cache plus an index cache.
    #
    # The key is head-shared, like an MLA latent: ``index_n_heads`` in the
    # published configs counts the *query* heads that score against it, not
    # copies of it, so it does not multiply the storage and is not recorded
    # here. What sets the size is the key width (``index_head_dim``, 128 on
    # every model that has one), how many layers carry an indexer, and the
    # dtype the serving stack keeps it in. ``sparse_index_layers`` is 0 for
    # "all layers"; models that leave the first few layers dense, or that
    # share one layer's index keys with the layers after it, pay for fewer.
    #
    # Leaving this out is not a rounding error. On MiniMax-M3 it is a third of
    # the footprint: GQA alone predicts 15,360 bytes per token at TP8 with an
    # fp8 cache where vLLM allocates 30,023. Because the index cache does not
    # follow ``kv_cache_dtype``, the two terms can be read apart from two runs
    # of the same model -- with a bf16 cache the same engine allocates 45,398,
    # and both are matched to under 0.5% once the indexer is charged.
    sparse_index_head_dim: int = 0
    sparse_index_layers: int = 0
    sparse_index_dtype: str = "bf16"
    # The query-head count above, recorded for *time* rather than memory. It
    # does not size the cache -- one key per token serves every head -- but it
    # does set the indexer's arithmetic, because each head scores the whole
    # pool. Published values differ by a factor of sixteen (64 on
    # DeepSeek-V4-Pro, 32 on GLM-5.2, 4 on MiniMax-M3), so a model priced
    # without it is not merely missing a constant, it is missing the term that
    # separates these three.
    sparse_index_n_heads: int = 0
    # FFN & MoE
    swiglu: bool = False
    num_experts: int = 0
    moe_ffn_hidden_size: int = 0
    moe_pattern: list = None
    moe_router_topk: int = 0
    moe_shared_expert_intermediate_size: int = 0
    # How unevenly the router spreads tokens over experts, as the exponent of a
    # Zipf popularity law (0 = uniform). It sets how many *distinct* experts a
    # decode step touches, which is what a weight-bandwidth-bound MoE step costs.
    # Relates to a measured max/mean expert load by ``I(s) = N / H_N(s)``, so an
    # imbalance figure from a profile converts straight into this.
    #
    # Default 0 -- uniform -- because for a load-balanced router that is very
    # nearly right, and the alternative is worse than it looks. Real gpt-oss vLLM
    # sweeps under forced Zipf routing confirm a decode step is linear in this
    # count, so the count is the whole story. But at gpt-oss's 128 experts and
    # top-4, a skew already stronger than a router with an aux balance loss shows
    # barely moves the distinct-expert count away from uniform. Realistic
    # imbalance simply does not move that count much.
    #
    # Worth stating because fitting this to the measured TP ladder *does* find a
    # clean optimum -- but only at an implausible skew, an expert load imbalance
    # no load-balanced router has. What the fit is really doing is absorbing an
    # unrelated error into a knob that happens to have the right shape. The
    # mid-batch residual is not routing skew.
    moe_routing_skew: float = 0.0
    # How many distinct experts the router really reaches, as a fraction of what
    # independent per-token routing predicts, keyed by token count. Measured by
    # pushing token representations through the checkpoint's own router weights
    # -- no GPU needed, since a router is one linear layer per block.
    #
    # It exists because independence is the wrong assumption. Real token
    # representations are correlated, so tokens pick overlapping experts and a
    # step reads fewer distinct ones. For gpt-oss-120b the coverage falls to
    # 0.70 of the independent prediction around batch 32-64 and returns toward 1
    # at both ends -- a shape no marginal-skew law can produce, and the same
    # probe on uncorrelated Gaussian inputs stays at 0.90-1.0, which is what
    # identifies correlation rather than skew as the cause.
    moe_router_coverage: dict = None
    # Busiest EP rank's load over the mean, replayed from the checkpoint's
    # recorded routing: {ep: [[tokens, rows, experts], ...]}. None samples a
    # top-k router instead.
    moe_rank_load: dict = None
    # Speculative decoding. ``mtp_num_layers`` is the checkpoint's own
    # next-token-prediction head (num_nextn_predict_layers), the MTP drafter's
    # depth. ``speculative`` names, per drafter method, the measured
    # acceptance-length file the model is served with and any drafter shape
    # that differs from the method's published one; see ``golden_al``.
    mtp_num_layers: int = 0
    speculative: object = None
    # Misc
    share_embeddings_and_output_weights: bool = False
    # Precision – None means bf16, "hybrid" means FP8-hybrid (linear GEMMs in FP8)
    fp8: str = None

    # Primus Turbo flags — used to select the grouped-GEMM performance model
    enable_primus_turbo: bool = False
    use_turbo_grouped_mlp: bool = False
    # MoE simulate-kernel model: None -> auto (turbo/legacy); "vllm_fused" models
    # the vLLM fused-MoE decode kernel; "legacy"/"turbo" force the Megatron paths.
    moe_sim_kernel: str = None
    use_turbo_deepep: bool = False  # DeepEP enables async A2A with compute overlap
    turbo_sync_free_moe_stage: int = 0  # 0=off, 1=fused router, 2=+DeepEP+grouped, 3=+fused act
    # MoE routing imbalance (hottest EP-rank / mean token load, >= 1.0) and its
    # redundant-experts mitigation, mirrored from the inference request config so
    # the expert-GEMM simulator can apply it *inside* the roofline (scales the
    # busiest rank's token count M, a near no-op at weight-bound decode and full
    # at compute-bound prefill). EP-gated: only meaningful when EP > 1.
    ep_load_balance: float = 1.0
    redundant_experts: int = 0

    # Loss fusion – fuses cross-entropy with output layer avoiding full logits materialisation
    cross_entropy_loss_fusion: bool = False

    def linear_attention_layer_count(self) -> int:
        """How many transformer layers run linear / KDA / GDN attention."""
        n_layers = int(self.num_layers or 0)
        n = int(self.linear_attention_layers or 0)
        if n > 0:
            return min(n, n_layers) if n_layers else n
        freq = int(self.linear_attention_freq or 0)
        if freq > 1 and n_layers:
            n_full = max(1, n_layers // freq)
            return max(0, n_layers - n_full)
        return 0

    def linear_attention_state_len(self) -> int:
        """FLOP-equivalent KV length of a linear-attention layer.

        A gated-delta / KDA layer stores a d×d recurrent state per head and
        updates it with an O(d²) matvec per token -- the same arithmetic as
        attending to ``d`` keys. ``d`` is ``linear_attention_head_dim``,
        falling back to ``kv_channels``. Not a fitted length.
        """
        d = int(self.linear_attention_head_dim or 0) or int(self.kv_channels or 0)
        return max(1, d)

    def linear_attention_geometry(self) -> tuple[int, int, int, int]:
        """``(key heads, value heads, key dim, value dim)`` of a linear layer."""
        d = self.linear_attention_state_len()
        hk = int(self.linear_num_key_heads or 0) or int(self.num_attention_heads or 0)
        hv = int(self.linear_num_value_heads or 0) or hk
        dk = int(self.linear_key_head_dim or 0) or d
        dv = int(self.linear_value_head_dim or 0) or dk
        return max(1, hk), max(1, hv), max(1, dk), max(1, dv)

    def prices_linear_attention_ops(self) -> bool:
        """Whether linear layers are timed from their own operations."""
        kind = str(self.linear_attention_kind or "").lower()
        return kind in ("kda", "gdn") and self.linear_attention_layer_count() > 0

    def sparse_index_layer_count(self) -> int:
        """How many layers store a sparse-attention index cache."""
        if self.sparse_index_head_dim <= 0:
            return 0
        n = int(self.num_layers or 0)
        declared = int(self.sparse_index_layers or 0)
        if declared > 0:
            return min(declared, n) if n else declared
        return n

    def full_attention_layer_fraction(self) -> float:
        """Fraction of layers that store and read a per-token KV cache."""
        n_lin = self.linear_attention_layer_count()
        n = int(self.num_layers or 0)
        if n <= 0 or n_lin <= 0:
            return 1.0
        return max(0.0, min(1.0, (n - n_lin) / n))

    def blend_linear_attn_kv(self, kv_len: int) -> int:
        """Average KV length an attention layer reads under hybrid linear attention.

        Full-attention layers read ``kv_len``. Linear layers read a recurrent
        state whose arithmetic equals attending to ``linear_attention_state_len``
        keys (capped at ``kv_len`` so a short context is not charged more than
        dense). Unlike sliding-window, this *is* the architecture and is
        delivered at both prefill and decode.
        """
        kv = int(max(1, kv_len))
        n_lin = self.linear_attention_layer_count()
        n = int(self.num_layers or 0)
        if n_lin <= 0 or n <= 0:
            return kv
        state = min(self.linear_attention_state_len(), kv)
        n_full = n - n_lin
        return max(1, int(round((n_lin * state + n_full * kv) / n)))


@dataclass
class TrainingConfig:
    """
    Configuration for training the profiler models.
    """

    model_config: ModelConfig
    runtime_config: RuntimeConfig
    model_parallel_config: ModelParallelConfig


# ─────────────────────────────────────────────────────────────────────────────
# Inference / serving configuration
# ─────────────────────────────────────────────────────────────────────────────


def uses_latent_attention(model_config) -> bool:
    """Whether a layer *serves* multi-head latent attention, flag or no flag.

    ``multi_latent_attention`` is a trainer switch rather than a description of
    the served layer. DeepSeek-V4 holds it off so Megatron does not take the V3
    MLA builder -- V4 layers also need CSA/HCA/SWA branches -- but what it
    serves is still latent attention: one compressed K=V vector plus a
    decoupled RoPE head. Anything pricing the served step therefore has to read
    the shape, not the switch.

    ``kv_bytes_per_token_per_layer`` tests this same shape to charge the 576-byte
    latent, and the two have to agree. A decode step that skips MLA's extra
    projections while the cache charges MLA's latent is describing no model that
    exists.
    """
    if getattr(model_config, "multi_latent_attention", False):
        return True
    rope = int(getattr(model_config, "qk_pos_emb_head_dim", 0) or 0)
    return rope > 0 and int(getattr(model_config, "num_query_groups", 0) or 0) == 1


def decode_kernels_per_layer(model_config, sparse_attention_topk: int = 0) -> int:
    """How many kernels one transformer layer issues in a decode step.

    A decode step is largely a stream of small kernels, and their number is set
    by the architecture rather than being the same everywhere. It matters
    because each one holds the GPU for a minimum time no matter how little data
    it touches, so the count multiplies a hardware floor -- and at 61 layers a
    wrong count per layer is milliseconds per step.

    Counted from what the layer has to run, not fitted:

      framing        input norm, post-attention norm, two residual adds
      attention      one fused QKV projection, RoPE, the attention kernel and
                     the output projection. Multi-head latent attention instead
                     splits into down/up projections for Q and KV with a norm on
                     each compressed vector, which is five more.
      MLP            dense: gate/up, activation, down. Mixture-of-experts adds a
                     router projection, top-k selection, the permutation that
                     groups tokens by expert, and the combine that undoes it.
      shared expert  its own gate/up, activation and down, run every step.
      indexer        sparse attention has to decide what to attend to before it
                     can attend: a query projection, the score against the
                     index cache, the top-k, and the gather of the pages it
                     picked. These run every decode step and cannot be skipped,
                     which is why the selection is cheap in arithmetic and not
                     cheap in time.

    Collectives are excluded: they are modelled separately, and charging them
    here as well would count the same microseconds twice.

    Every kernel counts, including the GEMMs and the attention kernel. What the
    occupancy term prices is the device overhead each launch carries -- wave
    launch, memory latency, drain -- which is paid on top of the data movement
    a profiler times, not instead of it. Restricting the count to the
    elementwise kernels looked like it avoided double-counting, but the
    per-kernel constant was solved by dividing a measured step floor by this
    same count, so halving the count silently halved the floor.
    """
    kernels = 4  # two norms, two residual adds

    if uses_latent_attention(model_config):
        # q_a, q_a_norm, q_b, kv_a, kv_a_norm, kv_b, rope, attention, o_proj
        attn = 9
    else:
        attn = 4  # qkv, rope, attention, o_proj
    if getattr(model_config, "attention_output_gate", False):
        attn += 2  # gate projection, sigmoid multiply
    # A linear layer runs none of that attention, it runs its own: KDA has
    # separate q/k/v projections each through a short convolution, a low-rank
    # decay gate, a beta projection, the output gate, the recurrent update, a
    # gated norm and the output projection; GDN fuses its projections into two.
    n_layers = int(getattr(model_config, "num_layers", 0) or 0)
    prices_lin = getattr(model_config, "prices_linear_attention_ops", None)
    n_lin = model_config.linear_attention_layer_count() if prices_lin and prices_lin() else 0
    if n_lin and n_layers:
        if str(model_config.linear_attention_kind).lower() == "kda":
            gate = 1 if getattr(model_config, "linear_attention_full_rank_gate", False) else 2
            lin = 3 + 2 + 1 + gate + 3 + 1 + 1 + 1
        else:
            lin = 2 + 1 + 1 + 1 + 1 + 1  # qkvz, ba, conv, gating, recurrence, norm, o
        attn = ((n_layers - n_lin) * attn + n_lin * lin) / n_layers
    kernels += attn

    num_experts = int(getattr(model_config, "num_experts", 0) or 0)
    if num_experts > 1:
        # router, top-k, permute, grouped gate/up, activation, grouped down,
        # combine
        kernels += 7
        if int(getattr(model_config, "moe_latent_hidden_size", 0) or 0) > 0:
            kernels += 3  # latent down projection, its norm, latent up projection
    else:
        kernels += 3  # gate/up, activation, down
    if int(getattr(model_config, "attn_res_block_size", 0) or 0) > 0:
        kernels += 2  # the block mix before attention and before the MLP

    if int(getattr(model_config, "moe_shared_expert_intermediate_size", 0) or 0) > 0:
        kernels += 3

    if int(sparse_attention_topk or 0) > 0:
        kernels += 4  # index projection, score, top-k, gather

    return int(round(kernels))


def dtype_num_bytes(dtype: str | None) -> float:
    """Return the byte width of a (loosely-named) tensor dtype.

    Accepts the informal names used throughout the projection layer
    (``bf16``, ``fp16``, ``fp8``, ``int8``, ``fp32``).  Unknown / ``None``
    values fall back to bf16 (2 bytes) which is the projection default.

    ``mxfp4`` is block-scaled: 4-bit elements plus one E8M0 scale per block of
    32, i.e. 4 + 8/32 bits = 0.53125 bytes per element. That 6% over the raw
    nibble is the difference between a checkpoint fitting and not.
    """
    if dtype is None:
        return 2.0
    key = str(dtype).lower().strip()
    return {
        "fp32": 4.0,
        "float32": 4.0,
        "bf16": 2.0,
        "bfloat16": 2.0,
        "fp16": 2.0,
        "float16": 2.0,
        "half": 2.0,
        "fp8": 1.0,
        "fp8_e4m3": 1.0,
        "fp8_e5m2": 1.0,
        "int8": 1.0,
        "uint8": 1.0,
        "fp4": 0.5,
        "int4": 0.5,
        "mxfp4": 0.53125,
        "mxfp8": 1.03125,
    }.get(key, 2.0)


@dataclass
class InferenceRequestConfig:
    """Describes the *serving* workload an inference projection targets.

    Unlike :class:`RuntimeConfig` (which models a training microbatch /
    global-batch / gradient-accumulation pipeline) this captures the
    request profile that drives prefill + autoregressive decode.
    """

    # Prompt (prefill) and generation (decode) lengths, in tokens.
    input_seq_len: int = 1024
    output_seq_len: int = 128
    # Number of sequences processed together in one forward (a decode batch).
    batch_size: int = 1
    # Max number of sequences whose KV cache is resident at once (for memory
    # sizing / continuous batching).  Defaults to ``batch_size``.
    max_concurrency: int | None = None
    # Largest context (prompt + generated) any sequence can reach.  Drives
    # KV-cache capacity.  Defaults to ``input_seq_len + output_seq_len``.
    max_context_len: int | None = None
    # Fraction of per-GPU HBM the serving engine may use (vLLM
    # ``gpu_memory_utilization`` / SGLang ``mem_fraction_static``).  Bounds the
    # usable HBM for weights + KV + activations and therefore the max concurrent
    # sequences.  ``None`` = use the full HBM capacity (legacy behaviour).
    kv_cache_memory_fraction: float | None = None
    # Paged-KV block (page) size in tokens.  Real serving engines allocate KV in
    # fixed-size blocks (vLLM ``block_size``, typically 16), so a sequence's
    # context is rounded UP to a whole number of blocks — the last partially
    # filled block still reserves a full block.  This fragmentation inflates the
    # per-sequence KV footprint and lowers max concurrency.  ``0`` = no paging
    # (continuous/contiguous allocation, legacy behaviour).
    kv_block_size: int = 0

    # Host DRAM per GPU holding KV blocks evicted from HBM (TRT-LLM's native
    # "dram" offload, SGLang's HiCache). The tier extends how much prefix an
    # engine can keep cached instead of dropping, and a hit it holds is fetched
    # back over the host link rather than recomputed. ``0`` disables it.
    kv_offload_gb_per_gpu: float = 0.0
    # Host<->device bandwidth for that tier. PCIe 5 x16 is ~64 GB/s and is the
    # default; a cache-coherent host link runs ~900, and on a part that has one
    # the offload is cheap enough to leave on.
    kv_offload_bw_gbps: float = 64.0

    # Mean KV tokens one request of the target workload occupies while it is
    # resident, which is what decides how many requests the pool can admit at
    # once. ``None`` = use the configured context, which is exact for a
    # fixed-length workpoint and is the only thing a single-point projection
    # can know.
    #
    # For a workload with a spread of lengths this is E[L^2]/E[L] and *not* the
    # arithmetic mean, because a request holds the pool for a time proportional
    # to its length: the set resident at a random instant is sampled
    # proportional to length, so a time-average occupancy is length-biased.
    # Against the published AgentX rows -- 572 of them, 7 models, 9 hardware
    # platforms -- predicting occupancy as ``concurrency * this / pool`` matches
    # the reported ``gpu_kv_cache_usage_pct`` with a slope of 0.91 pooled and a
    # median of 0.90 across 48 individual curves, against 1.14 and 1.19 for the
    # arithmetic mean. A statistic that needs no multiplier has slope 1, so this
    # is the one the model uses and it carries no fitted constant.
    #
    # It must NOT be discounted by the prefix-cache hit rate. A 95% block-reuse
    # rate means 95% of the prefill FLOPs are skipped; it does not mean 95% of
    # the blocks are free. Cached blocks live in the same pool as active ones
    # and are held by reference from every request reading them -- used blocks
    # are total minus free, and a shared prefix is counted once but counted.
    # Discounting residency that way needs a 6.1x multiplier to match measured
    # occupancy (interquartile range 2.0 to 13.4) and predicts it worse than
    # assuming the mean.
    workload_resident_tokens: int | None = None

    # The KV pool the engine actually allocated, in tokens, when that is known.
    # Every engine prints it at startup, so anyone validating a projection
    # against a running deployment -- or against a published benchmark that
    # reports it -- has the real number and should not have to get it back out
    # of an HBM figure, a memory fraction and a weight estimate.
    #
    # When it is set the admission bound is evaluated against it directly. That
    # separates the two things that can make the bound wrong, which otherwise
    # arrive together: the admission law itself, and the memory model's answer
    # to how many tokens fit. It is left unset for planning, where the whole
    # point is that no engine has been started yet.
    kv_pool_tokens: int | None = None

    # ---- Precision ----
    weight_dtype: str = "bf16"  # weights kept resident (bf16 | fp8 | ...)
    kv_cache_dtype: str = "bf16"  # KV cache precision (bf16 | fp8 | int8 | ...)

    # ---- Inference features ----
    # Chunked prefill: split a long prompt into chunks of this many tokens
    # (0 disables; the whole prompt is one forward).
    chunked_prefill_size: int = 0
    # Prefix-cache hit rate in [0, 1): the fraction of each prompt's tokens
    # already resident in the paged KV cache (an automatically-cached / reused
    # shared prefix). Cached tokens skip prefill compute -- only the non-cached
    # suffix is run through the network -- so TTFT and the prefill share of
    # continuous-batching pollution scale with ``(1 - prefix_cache_hit_rate)``.
    # The suffix tokens still attend over the FULL context (cached prefix +
    # suffix), so decode/KV sizing is unchanged. ``0`` = cold cache (legacy
    # behaviour). Models vLLM/SGLang automatic prefix caching and Infera's
    # cross-request prefix reuse (shared system prompts, agentic multi-turn).
    prefix_cache_hit_rate: float = 0.0
    # Speculative decoding: number of draft tokens proposed per verify step
    # (0 disables). ``speculative_max_num_tokens`` > 0 instead lets the
    # projector pick the depth up to that bound that emits the most tokens per
    # unit of step time.
    speculative_num_tokens: int = 0
    speculative_max_num_tokens: int = 0
    # The drafter: mtp / eagle3 / dspark / ngram / draft_model. Unset takes the
    # model's own (``golden_al.default_method``). Its cost is its own forward
    # (``speculative.py``); the draft_* fields override the drafter shape the
    # model YAML or the method's published drafter gives.
    speculative_method: str | None = None
    speculative_draft_layers: int = 0
    speculative_draft_vocab: int = 0
    speculative_draft_window: int | None = None
    # Acceptance comes from measured acceptance-length files (``golden_al``):
    # the model's own curve for the method, else the sibling method's (MTP and
    # EAGLE3 stand in for each other), both looked up in INFERASIM_GOLDEN_AL_DIR
    # or fetched from InferenceX on GitHub, else the method's default curve in
    # configs/speculative/defaults.
    # ``speculative_acceptance_curve`` names a file to use instead (a path, or
    # a name in either directory). ``speculative_thinking`` picks the
    # curve's thinking_on / thinking_off sweep. An acceptance stated outright
    # -- ``speculative_acceptance_length`` (tokens per step) or
    # ``speculative_acceptance_rate`` (a flat per-draft rate in [0, 1]), at
    # ``speculative_num_tokens`` -- rescales the curve through that point.
    speculative_acceptance_curve: str | None = None
    speculative_thinking: str = "on"
    speculative_acceptance_length: float = 0.0
    speculative_acceptance_rate: float = 0.0
    # Moves acceptance from coding, where the curves were measured, to another
    # SPEED-Bench entropy class (low / mixed / high, or a number on -1..1).
    # Unset leaves the curve as measured.
    speculative_entropy: str | None = None

    # ---- Serving / continuous-batching dynamics ----
    # How decode latency is modelled:
    #   "continuous" — continuous batching with mixed prefill+decode steps
    #                  (models the TPOT "pollution" real servers like vLLM see).
    #   "static"     — an idealized batch doing pure decode (legacy behaviour;
    #                  prefill is charged once as TTFT only).
    serving_model: str = "continuous"
    # Fixed per-decode-step host/launch overhead (microseconds). At low decode
    # batch the step is launch-bound; CUDA-graph capture shrinks this. Added to
    # every decode/mixed step. 0 = ignore (pure kernel-compute model).
    decode_step_overhead_us: float = 0.0
    # Per-kernel launch latency (microseconds) for the small-tensor launch-bound
    # floor used by the pure-simulate (GPU-free) decode path. A decode step
    # issues ~``kernels_per_layer`` kernels per layer plus a handful for the
    # head/sampling; at low batch the roofline GEMM/attention times underflow
    # the real step, which is set by host-side kernel-launch dispatch. The floor
    # is ``n_kernels * kernel_launch_latency_us`` and is applied as
    # ``step = max(step, floor)`` in simulation only. CUDA-graph replay collapses
    # the launches, so a "full"/"piecewise" ``cudagraph_mode`` disables it and
    # ``fused_kernels`` shrinks it. 0 = disabled (legacy behaviour).
    kernel_launch_latency_us: float = 0.0
    # Representative number of distinct kernel launches per transformer layer
    # (norms, projections, attention, activation, residuals, MoE router/permute/
    # grouped-GEMM/combine). Only consulted for the launch-latency floor above.
    kernels_per_layer: int = 12
    # Per-kernel GPU *occupancy* (microseconds): the minimum wall time a kernel
    # holds the GPU regardless of how little data it touches (wave launch,
    # memory latency, barriers). This is distinct from
    # ``kernel_launch_latency_us`` above in two ways that matter physically:
    #
    #   * it survives CUDA-graph capture. Graph replay removes the *host-side*
    #     dispatch, but the kernels still execute and still occupy the device.
    #   * it is *additive*, not a ``max``. A decode step runs a few large
    #     data-bound kernels (the expert GEMMs) alongside many small
    #     latency-bound ones (norms, rope, KV write, router, activation,
    #     residuals). The large ones are priced by bytes and the small ones by
    #     occupancy, so the two costs are paid together. Taking ``max`` of the
    #     totals makes the small-kernel cost vanish exactly when the batch is
    #     large, which is where it was measured to still be present.
    #
    # Measured on MI355X by solving ``step(tp) = floor + compute(1)/tp`` across
    # TP=1,2,4,8 with real weights.
    #
    # The floor keeps *all* of the fixed cost, including the collectives'. An
    # earlier version subtracted the measured all-reduce from each TP>1 rung to
    # avoid double-counting once comm was modelled explicitly -- but comm is then
    # added back with its own fitted floor, which restores the double count. It
    # showed: the resulting step floor ran from 1.91 ms at TP=1 to 2.73 ms at
    # TP=8, whereas subtracting only each rung's *data movement* leaves a floor
    # of 2.93, 2.56, 2.57, 2.82 ms at TP=1,2,4,8 -- flat, as a fixed cost should
    # be, since sharding does not remove kernels. So the floor is that mean,
    # 2.72 ms, and a small all-reduce now contributes only its bandwidth term,
    # its own occupancy already being one of the kernels counted here.
    #
    # What is calibrated is the *product* of a kernel count and a per-kernel
    # minimum, and only the product was measured. Splitting it wrongly does not
    # show up on the model it was fitted to and does show up on every other one:
    # gpt-oss runs about 15 kernels in a decode layer, so the same 2.72 ms is
    # 4.98 us across ``36 * 15 + 6 = 546`` kernels rather than being spread over
    # an assumed 438. DeepSeek-R1 runs about 23 -- MLA splits the attention
    # projections and a shared expert adds a third GEMM pair -- and at 61 layers
    # that difference is worth 1.7 ms of floor, which is most of why its decode
    # step was under-predicted by 31% at batch 4.
    #
    # So the per-layer count is derived from the model architecture
    # (``decode_kernels_per_layer``) and this stays a hardware figure. The way
    # to stop estimating it is to run the sweep above on each GPU architecture
    # being served: time one decode step per tensor-parallel rung with real
    # weights, solve for the intercept, and divide by the kernels that model
    # issues. Until a given architecture has been through that, cross-model
    # agreement is the only test of whether its value is hardware physics or one
    # model's tuning.
    #
    # Being a hardware figure it is also a *per-architecture* one. The number
    # above was solved on mi355x and does not describe gb300: on GLM-5.2 it
    # prices the 1,800 kernels of a decode step at 8.96 ms, where the measured
    # gb300 deployments report 3.0-3.6 ms per output token at batch 1 -- a fixed
    # cost alone cannot exceed the step that pays it. ``None`` resolves it from the
    # GPU architecture through ``DECODE_OCCUPANCY_PROFILES``; an explicit float
    # still wins, for measuring one specific engine. 0 = disabled.
    decode_kernel_occupancy_us: float | None = None
    # Per-output-token host cost for detokenization + response streaming
    # (microseconds/token). The serving harness (vLLM / InferenceX) measures ITL
    # client-side, so its per-token latency carries detok+stream that the GPU
    # decode step does not. Added to ITL/TPOT and end-to-end latency only -- it
    # overlaps the next server step, so aggregate throughput is unchanged.
    # 0 = ignore (pure GPU-step model).
    detokenize_overhead_us: float = 0.0
    # Per-prompt-token host cost for tokenizing the request text (microseconds/
    # token). The serving harness (vLLM / InferenceX) sends the prompt as text
    # and the server tokenizes it after the TTFT clock starts, so it lands in
    # TTFT. Added to TTFT + end-to-end latency only. 0 = ignore (GPU-prefill
    # model). Symmetric with ``detokenize_overhead_us`` on the decode side.
    tokenize_overhead_us: float = 0.0
    # Fixed per-request host cost on the TTFT path, in milliseconds: everything
    # a server does once per request regardless of how long the prompt is --
    # accept the connection, parse and validate, admit to the scheduler, look up
    # the prefix cache, allocate KV pages, open the SSE stream.
    #
    # It is separated from ``tokenize_overhead_us`` because it does not scale
    # with the prompt, and that is also how it is measured: differencing TTFT
    # across two prompt lengths at concurrency 1 gives the per-token slope, and
    # the intercept left behind is this. On the InferenceX single-turn rows that
    # intercept is ~150-190 ms for the SGLang/atom stacks and ~46-94 ms for the
    # vLLM ones -- an order of magnitude above anything the prompt-length terms
    # can account for at 1k, and the reason a FLOPs-only TTFT reads 0.2x of
    # measurement there.
    #
    # A property of the serving stack rather than of the silicon or the model,
    # so it has no architecture profile to resolve from and defaults to 0: a
    # projection that has not been told which engine it is modelling should not
    # invent one. Latency-only, like the two terms above -- it is host work that
    # overlaps the GPU, so no throughput moves.
    request_overhead_ms: float = 0.0
    # Per-token TTFT latency for the part of a prompt the prefix cache did not
    # serve (microseconds/token). On the AgentX MI355X rows TTFT climbs
    # ~40-130 us for every token a request has to prefill, while ITL on the
    # same stacks at C>=4 shows the GPU is not held for anything like that
    # long, so it is not charged as GPU time. Added to TTFT and end-to-end
    # latency only (not throughput), like the terms above. Default 0.
    uncached_prompt_latency_us: float = 0.0
    # Tokens past which the term above stops growing (0 = no cap). The same rows
    # put a ceiling on it: at C=4 a run whose trace holds several 300-460k-token
    # cold prompts still has a TTFT spread of ~0.6 s.
    uncached_prompt_latency_max_tokens: int = 0
    # The *other* half of that same fit: the per-token slope. Differencing TTFT
    # across two prompt lengths at concurrency 1 yields ``TTFT = C + r*L``; ``C``
    # is the constant above and ``r`` is this -- a measured prefill rate, in
    # microseconds of TTFT per prompt token, for the stack that produced it.
    #
    # It is an anchor on the *level* of prefill compute, not a replacement for
    # the cost model. Prefill is superlinear in the prompt (attention grows with
    # context) and a slope fit over a short span cannot express that, so applying
    # ``r`` directly would misprice long prompts badly in the other direction.
    # Instead the projector computes its own slope over the same two lengths and
    # scales the modelled prefill compute by the ratio: the roofline keeps its
    # shape across context, and only the absolute level moves onto measurement.
    #
    # This matters out of proportion to its size. Under a closed load the TTFT a
    # request sees is the queueing response of a shared prefill station, which
    # runs like ``S/(1-U)``; the InferenceX corpus sits at utilizations of 0.2 to
    # 0.97, where a 1.3x error in the service time ``S`` becomes a 2-4x error in
    # TTFT. The measured slopes run ~14-44 us/token against ~20-25 modelled.
    #
    # Both lengths are recorded so the modelled slope is taken over the same span
    # the measurement was; a rate is meaningless without the span it was fit on.
    # Defaults to 0 (unanchored), for the same reason the constant above does.
    prefill_rate_us_per_token: float = 0.0
    prefill_rate_lo_tokens: int = 0
    prefill_rate_hi_tokens: int = 0
    # Output tokens buffered per streaming flush (vLLM/SGLang
    # ``--stream-interval``). The server detokenizes and flushes the SSE stream
    # only every N tokens, so the client's *first* token -- and therefore the
    # measured TTFT -- lands only after N tokens have been decoded. Serving
    # harnesses raise this to cut host detokenization cost, and it is a leading
    # TTFT term at high N: SGLang's PD default of 30 adds ~29 TPOTs. ``1`` =
    # flush every token (legacy behaviour, no TTFT contribution).
    stream_interval: int = 1
    # Decode-scheduler admission granularity, in decode steps. A request whose
    # prefill is done is not admitted to the running batch immediately: the
    # scheduler polls its receive queue only every ``--scheduler-recv-interval``
    # loop iterations, and each iteration advances ``--num-continuous-decode-
    # steps`` decode steps, so the product bounds the admission delay. The
    # request waits a uniform fraction of that window on average. This is a pure
    # TTFT term (throughput is unaffected -- that is the point of the knob) and
    # it dominates TTFT in disaggregated serving, where prefill compute is off
    # the critical path. ``0`` = admit immediately (legacy behaviour).
    decode_admission_steps: int = 0
    # Extra cost fraction applied to a *mixed* (prefill+decode) step to model
    # vLLM's less-efficient PIECEWISE CUDA-graph path vs the FULL graph used for
    # uniform pure-decode steps. 0 = no penalty.
    mixed_batch_penalty: float = 0.0
    # CUDA-graph capture strategy. A friendly preset over the two low-level
    # knobs above:
    #   "none"      — eager, launch-bound per step (high per-step overhead).
    #   "piecewise" — piecewise graphs; mixed prefill+decode steps fall off the
    #                 captured graph (moderate overhead + a mixed-step penalty).
    #   "full"      — one full graph capture (minimal overhead, no penalty).
    # ``None`` leaves ``decode_step_overhead_us`` / ``mixed_batch_penalty`` at
    # their explicit values (legacy behaviour). An explicit non-zero value of
    # either low-level knob overrides the preset.
    cudagraph_mode: str | None = None
    # Scheduler per-step token budget (vLLM ``--max-num-batched-tokens``).  The
    # scheduler caps the total tokens processed in one engine step: a mixed step
    # carries a prefill chunk plus the decode tokens of every running sequence,
    # and that sum may not exceed this cap.  Oversized steps are split, raising
    # the number of prefill steps (and the mixed-step fraction) → higher TPOT /
    # lower throughput.  ``0`` = unlimited (legacy behaviour).
    max_num_batched_tokens: int = 0
    # Engine cap on concurrently running sequences (vLLM ``--max-num-seqs``,
    # SGLang ``--max-running-requests``). Clients beyond it wait in the
    # server queue, so it bounds the decode batch and adds queue time to TTFT.
    # ``0`` = no cap beyond the client concurrency.
    max_num_seqs: int = 0
    # MoE expert routing imbalance.  On an EP-sharded model the MoE step time is
    # set by the BUSIEST rank, not the average: ``ep_load_balance`` is the ratio
    # of the hottest rank's token load to the average (1.0 = perfectly
    # balanced; 1.3 = the hottest rank does 1.3x the mean).  Inflates the
    # realized MoE expert-compute (grouped-GEMM) time.
    ep_load_balance: float = 1.0
    # Extra replicated expert slots (EPLB / redundant experts) that spread the
    # hottest experts' tokens and so reduce the realized imbalance above.
    # ``0`` = no redundancy (legacy behaviour).
    redundant_experts: int = 0

    # ---- Offered load / request rate (open-loop arrivals) ----
    # Offered load in requests/sec. ``0`` keeps the legacy *closed-loop* model
    # (a fixed resident ``concurrency`` with no arrival queue). When > 0 (and
    # ``arrival_model`` != "closed") a first-order queueing-delay term is added
    # to TTFT: the engine sustains a finite request-completion rate, and offered
    # load approaching that rate inflates waiting time (the latency–throughput
    # knee). This is the primary latency/throughput trade-off knob.
    request_rate: float = 0.0
    # Arrival process for ``request_rate``: "closed" (no queue; legacy),
    # "poisson" (M/M/1-style waiting time), or "deterministic" (D/M/1-ish,
    # lighter queueing). Only consulted when ``request_rate`` > 0.
    arrival_model: str = "closed"

    # ---- Kernel backend selection (ROCm) ----
    # Selectable attention/kernel library. Best choice is shape/recipe
    # dependent on ROCm; modelled as a representative multiplier on attention
    # compute time (simulation path only). ``None`` = engine default (= triton
    # baseline, 1.0). Values: aiter | triton | ck | hip.
    attention_backend: str | None = None

    # ---- Serving engine ----
    # Which engine this projection is asking about: vllm | sglang | atom, or a
    # build of one (`mori-sglang`). Distinct from ``attention_backend``, which
    # names a kernel library inside an engine.
    #
    # Nothing in the analytical model reads this -- simulate mode prices an
    # architecture on a device and returns the same number whichever engine is
    # named. It is a regime axis, so what it decides is which measured anchor
    # benchmark mode is allowed to calibrate from, and there the engine is the
    # whole question: an SGLang anchor does not describe vLLM's scheduler or
    # its paging. Left unset the axis is unknown and matching behaves as it did
    # before, which is why it is optional rather than required.
    serving_engine: str | None = None

    # ---- Native sparse attention (DeepSeek V3.2 / V4 NSA) ----
    # Number of KV tokens each query attends to under native sparse attention
    # (NSA + indexer top-k selection). ``0`` = dense attention (legacy). When
    # > 0 and the context exceeds it, attention compute/KV-read scales toward
    # ``topk / context`` (plus a small indexer overhead), making long-context
    # attention roughly constant in context length.
    sparse_attention_topk: int = 0

    # What the indexer's selection costs on this stack relative to a fused
    # kernel. The arithmetic is fixed by the model, but the kernel is not:
    # the same GLM-5.2 top-k runs fused through aiter on gfx950 and unfused
    # through Torch on gfx942, and the selection is parallelism-starved at
    # the batch sizes a latency-band run uses, so the fallback costs a
    # multiple rather than a margin. 1.0 prices the fused path; raise it to
    # charge a stack serving without one. Only reaches models priced by
    # ``uniform_sparse_attention_scale`` -- a schedule-priced model carries
    # its indexer per layer and is not governed by one number.
    sparse_indexer_cost_scale: float = 1.0

    # ---- Sliding-window / local attention ----
    # Override the model's sliding-window size (KV tokens each query attends to;
    # 0 = full attention). ``None`` follows the model config's
    # ``sink_sliding_window``. When set (or inherited) and the context exceeds
    # the window, decode/prefill attention compute and KV-cache footprint are
    # bounded by the window instead of the full context.
    sliding_window: int | None = None
    # Fraction of attention layers that are windowed (the remainder use full
    # attention) for models that interleave local/global layers. ``None``
    # follows the model's ``sink_window_even_layers_only`` flag (0.5 when set,
    # else 1.0 = every layer windowed).
    sliding_window_layer_fraction: float | None = None

    # ---- MoE expert compute precision ----
    # Expert grouped-GEMM compute dtype (separate from ``weight_dtype`` which
    # sizes resident weights). Models the expert-MLP speedup of low-precision
    # expert kernels: mxfp4 | fp8 | bf16. ``None`` = follow bf16 (no speedup).
    moe_expert_dtype: str | None = None

    # ---- Non-expert linear weight precision ----
    # Attention's projections and the dense MLP: mxfp4 | fp4 | fp8 | bf16.
    # Quantized checkpoints disagree with their experts here -- gpt-oss puts
    # mxfp4 experts behind bf16 attention, an NVFP4 checkpoint quantizes the
    # attention projections as well -- so this cannot be inferred from
    # ``weight_dtype`` or ``moe_expert_dtype``. ``None`` follows the model's own
    # fp8 flag, which is what every model did before the field existed.
    linear_weight_dtype: str | None = None

    # ---- Runtime activation quantization / cast ----
    # Precision the runtime casts activations to before each low-precision GEMM
    # (fp8 | mxfp4). These cast kernels (read bf16, amax, write packed + scale)
    # are memory-bound overhead the GEMM simulator does not see. ``None``
    # auto-detects from ``weight_dtype`` / model fp8; ``"bf16"`` / ``"none"``
    # drops the cast term (e.g. a bf16 serving path).
    act_quant_dtype: str | None = None

    # ---- Speculative decoding draft cost ----
    # ``analytic`` (default) prices the draft as the drafter's own forward.
    # ``flat`` charges ``speculative_draft_cost_factor`` of one target decode
    # token per draft token instead, which is also the fallback when the
    # drafter cannot be priced; a factor of 0 there takes the method's
    # ``speculative.FLAT_DRAFT_COST``.
    speculative_draft_cost_model: str = "analytic"
    speculative_draft_cost_factor: float = 0.0

    # ---- Token sampling / logits post-processing ----
    # The per-step cost of turning LM-head logits into sampled tokens (a
    # memory-bound reduction over the vocabulary). ``sampling_enabled=False``
    # drops the term (e.g. to compare against a logits-free step). ``top_k`` /
    # ``top_p`` / ``temperature`` shape how many streaming passes the sampler
    # makes over the logits (greedy/argmax is the cheapest).
    sampling_enabled: bool = True
    sampling_top_k: int = 0
    sampling_top_p: float = 1.0
    sampling_temperature: float = 1.0

    # ---- Fused custom ops (RMSNorm / RoPE / quant / KV-store+quant) ----
    # Fused elementwise kernels mainly cut per-step kernel-launch overhead.
    # When set, the resolved per-decode-step launch overhead is reduced by
    # ``_FUSED_KERNEL_OVERHEAD_FACTOR`` (representative). No-op when there is no
    # per-step overhead to cut (e.g. full CUDA graph already amortises it).
    fused_kernels: bool = False

    def resolved_max_context_len(self) -> int:
        if self.max_context_len is not None:
            return int(self.max_context_len)
        return int(self.input_seq_len) + int(self.output_seq_len)

    def resolved_max_concurrency(self) -> int:
        if self.max_concurrency is not None:
            return int(self.max_concurrency)
        return int(self.batch_size)

    def resolved_resident_tokens(self) -> int:
        """KV tokens one request holds while resident.

        Falls back to the configured context (prompt plus half the generation,
        the mean over a request's decode span), which is what a fixed-length
        workpoint occupies. A trace-driven planner passes the workload's
        ``E[L^2]/E[L]`` instead; see ``workload_resident_tokens``.
        """
        if self.workload_resident_tokens:
            return max(1, int(self.workload_resident_tokens))
        return max(1, int(self.input_seq_len) + int(self.output_seq_len) // 2)

    def resolved_prefix_cache_hit_rate(self) -> float:
        """Prefix-cache hit rate clamped to ``[0, 0.999]``.

        Capped just below 1.0 so at least one prompt token is always prefilled
        (a request with a 100%-cached prompt still runs one forward to produce
        its first token). ``0`` = cold cache.
        """
        h = float(self.prefix_cache_hit_rate or 0.0)
        if h <= 0.0:
            return 0.0
        return min(h, 0.999)

    def resolved_decode_step_overhead_us(self) -> float:
        """Per-decode-step launch overhead, honoring the cudagraph preset.

        An explicit non-zero ``decode_step_overhead_us`` always wins; otherwise
        the ``cudagraph_mode`` preset (if any) supplies a representative value.
        Fused elementwise kernels (``fused_kernels``) further cut whatever
        launch overhead remains.
        """
        if self.decode_step_overhead_us:
            base = float(self.decode_step_overhead_us)
        else:
            base = _CUDAGRAPH_PRESETS.get(self.cudagraph_mode, (0.0, 0.0))[0]
        if self.fused_kernels:
            base *= _FUSED_KERNEL_OVERHEAD_FACTOR
        return base

    def resolved_kernel_launch_floor_ms(self, num_layers: int) -> float:
        """Small-tensor launch-latency floor (ms) for the pure-simulate decode.

        A launch-bound decode step's wall time is set by dispatching one kernel
        per op rather than the (tiny) small-M GEMM/attention compute. Estimated
        as ``n_kernels * kernel_launch_latency_us`` where ``n_kernels`` scales
        with model depth. Returns 0.0 when disabled, or when CUDA-graph capture
        collapses the launches (``cudagraph_mode`` full/piecewise). Fused
        elementwise kernels shrink the launch count.
        """
        lat_us = float(self.kernel_launch_latency_us or 0.0)
        if lat_us <= 0.0:
            return 0.0
        # Graph replay issues a single launch for the captured region.
        if str(self.cudagraph_mode or "").lower() in ("full", "piecewise"):
            return 0.0
        kpl = max(1, int(self.kernels_per_layer or 12))
        # + a handful for embedding / final norm / LM head / sampling.
        n_kernels = max(1, int(num_layers)) * kpl + 6
        if self.fused_kernels:
            n_kernels *= _FUSED_KERNEL_OVERHEAD_FACTOR
        return n_kernels * lat_us / 1000.0

    def resolved_decode_occupancy_ms(
        self, num_layers: int, kernels_per_layer: int | None = None
    ) -> float:
        """Additive per-kernel GPU occupancy for one decode step (ms).

        Same kernel count as the launch floor, but priced at the device-side
        occupancy minimum and *not* cancelled by graph capture: replay removes
        the host dispatch, not the kernels. Fusing genuinely removes kernels, so
        ``fused_kernels`` still shrinks the count.

        ``kernels_per_layer`` is what the architecture actually issues, counted
        by :func:`decode_kernels_per_layer`. An explicit ``self.kernels_per_layer``
        still wins, for measuring a specific engine.

        An unresolved (``None``) occupancy means no GPU architecture was named,
        so it falls back to the figure the term was first solved on rather
        than to zero: the cost is there whether or not the caller said which
        silicon is paying it.
        """
        occ = self.decode_kernel_occupancy_us
        occ_us = float(DEFAULT_DECODE_OCCUPANCY_US if occ is None else occ)
        if occ_us <= 0.0:
            return 0.0
        kpl = max(1, int(kernels_per_layer or self.kernels_per_layer or 12))
        n_kernels = max(1, int(num_layers)) * kpl + 6
        if self.fused_kernels:
            n_kernels *= _FUSED_KERNEL_OVERHEAD_FACTOR
        return n_kernels * occ_us / 1000.0

    def resolved_mixed_batch_penalty(self) -> float:
        """Mixed-step penalty fraction, honoring the cudagraph preset."""
        if self.mixed_batch_penalty:
            return float(self.mixed_batch_penalty)
        return _CUDAGRAPH_PRESETS.get(self.cudagraph_mode, (0.0, 0.0))[1]

    def resolved_ep_imbalance(self, num_experts: int = 0) -> float:
        """Effective MoE expert-compute imbalance multiplier (always >= 1.0).

        ``ep_load_balance`` is the hottest-rank / mean token-load ratio; the MoE
        step is gated by that busiest rank, so its expert-compute time scales by
        this factor.  ``redundant_experts`` replicates the hottest expert slots,
        diluting the surplus the hot rank carries: the excess ``(ratio - 1)`` is
        shrunk by ``num_experts / (num_experts + redundant_experts)`` (the share
        of routed mass that still lands on a single, non-replicated slot).

        ``1.0`` (perfectly balanced) is a no-op.  ``num_experts`` is supplied by
        the caller (it lives on :class:`ModelConfig`, not the request config).
        """
        bal = float(self.ep_load_balance or 1.0)
        if bal <= 1.0:
            return 1.0
        red = max(0, int(self.redundant_experts or 0))
        if num_experts > 0 and red > 0:
            bal = 1.0 + (bal - 1.0) * num_experts / (num_experts + red)
        return max(1.0, bal)

    def resolved_attention_backend_multiplier(self) -> float:
        """Attention-compute time multiplier for the selected kernel backend.

        ``None`` / unknown → 1.0 (no change). Representative ROCm ratios
        relative to the Triton baseline; override by measuring (benchmark mode)
        for a real number.
        """
        if not self.attention_backend:
            return 1.0
        return _ATTENTION_BACKEND_PRESETS.get(str(self.attention_backend).lower(), 1.0)

    def resolved_sparse_attention_scale(self, context_len: int) -> float:
        """Fraction of dense attention cost under NSA top-k selection.

        Dense (``sparse_attention_topk == 0``) or short context (≤ topk) → 1.0.
        Otherwise attention work scales toward ``topk / context`` with a small
        floor (projections + indexer that do not shrink with the KV window).
        """
        topk = int(self.sparse_attention_topk or 0)
        if topk <= 0 or context_len <= topk:
            return 1.0
        return max(_SPARSE_ATTENTION_FLOOR, float(topk) / float(max(1, context_len)))

    def resolved_sliding_window(self, model_window: int = 0) -> int:
        """Sliding-window size in KV tokens (0 = full attention).

        An explicit ``sliding_window`` override wins; otherwise inherit the
        model's ``sink_sliding_window``. Non-positive values disable windowing.
        """
        w = self.sliding_window
        if w is None:
            w = model_window
        w = int(w or 0)
        return w if w > 0 else 0

    def resolved_sliding_window_fraction(self, even_layers_only: bool = False) -> float:
        """Fraction of attention layers that are windowed, clamped to [0, 1].

        ``sliding_window_layer_fraction`` wins when set; otherwise 0.5 for an
        even-layers-only interleave (e.g. gpt-oss) or 1.0 when every layer is
        windowed.
        """
        f = self.sliding_window_layer_fraction
        if f is None:
            f = 0.5 if even_layers_only else 1.0
        return min(1.0, max(0.0, float(f)))

    def effective_attn_kv(
        self, kv_len: int, model_window: int = 0, even_layers_only: bool = False
    ) -> int:
        """KV length an average attention layer reads under sliding-window.

        Full attention (or short context) returns ``kv_len`` unchanged. When a
        window is active and the context exceeds it, windowed layers read only
        ``window`` tokens while full layers still read ``kv_len``; the two are
        blended by the windowed-layer fraction so a single length represents the
        average layer (attention decode cost is ~linear in KV read). Used for
        both decode and prefill attention compute.
        """
        kv = int(max(1, kv_len))
        w = self.resolved_sliding_window(model_window)
        if w <= 0 or kv <= w:
            return kv
        frac = self.resolved_sliding_window_fraction(even_layers_only)
        return int(round(frac * w + (1.0 - frac) * kv))

    def resolved_moe_expert_dtype_speedup(self) -> float:
        """Expert grouped-GEMM compute multiplier for the expert dtype.

        ``None`` / bf16 → 1.0. fp8 ≈ 0.55 (~2x), mxfp4 ≈ 0.35; representative,
        override via benchmark calibration for a measured number.
        """
        if not self.moe_expert_dtype:
            return 1.0
        return _MOE_EXPERT_DTYPE_SPEEDUP.get(str(self.moe_expert_dtype).lower(), 1.0)

    def resolved_act_quant_dtype(self, model_fp8=None) -> str | None:
        """Precision of the runtime activation cast, or ``None`` to disable.

        An explicit ``act_quant_dtype`` wins (``"bf16"`` / ``"none"`` disables);
        otherwise infer from ``weight_dtype`` (fp8 / mxfp4) or the model's fp8
        flag. bf16 serving has no runtime activation cast.
        """
        v = self.act_quant_dtype
        if v is None:
            wd = str(self.weight_dtype or "").lower()
            if "mxfp4" in wd:
                return "mxfp4"
            if "fp8" in wd:
                return "fp8"
            if model_fp8:
                return "fp8"
            return None
        v = str(v).lower()
        return None if v in ("none", "bf16", "") else v


# Representative attention-backend compute multipliers (relative to Triton).
_ATTENTION_BACKEND_PRESETS = {
    "aiter": 0.85,
    "ck": 0.90,
    "triton": 1.0,
    "hip": 1.10,
}

# Floor on the sparse-attention scale (projections + indexer don't shrink).
# Only reached by models that declare a top-k without a per-layer schedule;
# ``hybrid_attention_scale`` supersedes it where a schedule exists, and states
# in one place why a floor is the wrong shape for the work it stands in for.
_SPARSE_ATTENTION_FLOOR = 0.15

# Per-layer attention branch, keyed by the compression ratio the checkpoint
# records for that layer. Mirrors the reference implementation's own mapping so
# a schedule read here means what it means to the model; an unrecognised ratio
# is a schedule this cost model has not been taught, and is refused rather than
# guessed at (see ``hybrid_attention_scale``).
_COMPRESS_RATIO_LAYER_TYPES = {
    0: "sliding_attention",
    4: "compressed_sparse_attention",
    128: "heavily_compressed_attention",
}

# Schedules whose length has already been reported as unexplained by the layer
# count, so the warning is said once per shape rather than once per forward.
_SCHEDULE_LENGTH_WARNED: set = set()


def parse_compress_ratios(model_config) -> list | None:
    """Per-layer compression schedule as a list of ints, or ``None``.

    Accepts the list form and the ``"[128, 128, 4, ...]"`` string form that the
    checkpoint ships. Returns ``None`` when the model declares no schedule.
    """
    raw = getattr(model_config, "compress_ratios", None)
    if raw is None:
        return None
    if isinstance(raw, str):
        raw = raw.strip().strip("[]")
        if not raw:
            return None
        try:
            return [int(float(x)) for x in raw.split(",") if x.strip()]
        except ValueError:
            return None
    try:
        return [int(x) for x in raw]
    except (TypeError, ValueError):
        return None


def hybrid_attention_scale(model_config, context_len: int) -> float | None:
    """Fraction of dense attention cost under a per-layer compression schedule.

    ``None`` when the model declares no schedule, or declares one this mapping
    does not recognise, so the caller keeps its previous behaviour.

    A compressed layer does not attend over its context. It attends over a local
    window plus a pool holding one entry per ``compress_rate`` source tokens, so
    what it reads is set by the schedule and the window, not by the prompt. The
    two branches differ in how they use that pool: HCA has full visibility over
    it, while CSA runs a lightning indexer across the whole pool to select
    ``index_topk`` entries and attends to those.

    That selection is why a single top-k scale reads this model wrong at long
    context. CSA's *attention* stops growing once the pool exceeds the top-k
    (above 4k context for DeepSeek-V4-Pro, which selects 1024 of ``context/4``),
    but its *indexer* still has to score every entry in the pool, so the term
    that keeps growing with context is the indexer rather than the attention.
    At 8k context the indexer is 9% of a CSA layer and at 130k it is 62%.

    A multiplicative floor cannot express that. The work it stands in for is
    real -- the indexer genuinely does not shrink with the window -- but it
    grows like ``context / compress_rate`` scaled by the indexer's much smaller
    head geometry, whereas flooring the scale makes it grow like dense attention
    over the full context. On DeepSeek-V4-Pro at 130k the schedule costs 0.0157
    of dense against the 0.15 floor, a 9.6x over-read, while at the 8k the floor
    was set against it is only 1.7x and does not show.
    """
    sched = parse_compress_ratios(model_config)
    if not sched:
        return None
    if any(cr not in _COMPRESS_RATIO_LAYER_TYPES for cr in sched):
        return None
    ctx = int(context_len or 0)
    if ctx <= 0:
        return None

    # The schedule covers the MTP head as well as the stack: DeepSeek-V4-Pro
    # declares 61 layers and schedules 62, Flash declares 43 and schedules 44,
    # and both carry ``mtp_num_layers: 1``. In both the surplus entry is the
    # trailing 0, a dense windowed layer, which is what an MTP head is. Only the
    # stack runs in the forward being costed here, so the average is taken over
    # that and the speculative head is left to whoever models speculation.
    declared = int(getattr(model_config, "num_layers", 0) or 0)
    if declared and len(sched) > declared:
        mtp = int(getattr(model_config, "mtp_num_layers", 0) or 0)
        if len(sched) != declared + mtp:
            key = (declared, len(sched))
            if key not in _SCHEDULE_LENGTH_WARNED:
                _SCHEDULE_LENGTH_WARNED.add(key)
                print(
                    f"[inferasim:Inference] WARNING: this model's compression "
                    f"schedule names {len(sched)} layers against {declared} in the "
                    f"stack and {mtp} predicting ahead of it. The first {declared} "
                    f"entries are used; the rest are unexplained. Re-transcribe "
                    f"compress_ratios from the checkpoint's config.json."
                )
        sched = sched[:declared]
    elif declared and len(sched) < declared:
        key = (declared, len(sched))
        if key not in _SCHEDULE_LENGTH_WARNED:
            _SCHEDULE_LENGTH_WARNED.add(key)
            print(
                f"[inferasim:Inference] WARNING: this model's compression schedule "
                f"names only {len(sched)} of {declared} layers. The branch mix is "
                f"weighted over the entries present, which assumes the rest look "
                f"like them. Re-transcribe compress_ratios from the checkpoint."
            )

    heads = int(getattr(model_config, "num_attention_heads", 0) or 0)
    latent = int(getattr(model_config, "kv_channels", 0) or 0)
    rope = int(getattr(model_config, "qk_pos_emb_head_dim", 0) or 0)
    # Absorbed MLA reads the shared latent plus the positional part for the
    # scores and the latent again for the values, per KV entry.
    main_per_entry = heads * ((latent + rope) + latent)
    if main_per_entry <= 0:
        return None
    idx_per_entry = int(getattr(model_config, "index_n_heads", 0) or 0) * int(
        getattr(model_config, "index_head_dim", 0) or 0
    )
    window = int(getattr(model_config, "attn_sliding_window", 0) or 0)
    topk = int(getattr(model_config, "index_topk", 0) or 0)

    local = min(ctx, window) if window > 0 else ctx
    total = 0.0
    for cr in sched:
        kind = _COMPRESS_RATIO_LAYER_TYPES[cr]
        if kind == "sliding_attention":
            total += local * main_per_entry
            continue
        pool = ctx / cr
        if kind == "heavily_compressed_attention":
            # Full visibility over the pool, and no indexer to select with.
            total += (local + pool) * main_per_entry
        else:
            selected = min(topk, pool) if topk > 0 else pool
            total += (local + selected) * main_per_entry + pool * idx_per_entry
    return total / (len(sched) * ctx * main_per_entry)


def uniform_sparse_attention_scale(
    model_config,
    context_len: int,
    topk: int,
    indexer_cost_scale: float = 1.0,
) -> float | None:
    """Fraction of dense prefill attention for a uniform top-k sparse model.

    The counterpart to ``hybrid_attention_scale`` for the models that select
    the same way on every layer instead of running a per-layer compression
    schedule: GLM-5.2 and MiniMax-M3 both keep one window, ``index_topk``,
    and differ only in how many layers compute an index and how wide the
    indexer is.

    Two terms, and the reason to spend a function on this rather than a scale
    is that they move in opposite directions. *Selection* is what attention
    reads once the indexer has chosen -- ``topk`` entries regardless of how
    long the prompt is -- so as a fraction of dense it falls away like
    ``topk / context``. *Indexing* is what choosing costs: every head scores
    every token in the pool, on the layers that carry an indexer, so it grows
    with context exactly as dense attention does and its fraction is flat.
    Past a few times the window the second term is the whole cost, and it is
    the one a top-k scale cannot express.

    That is not a small correction on this workload. GLM-5.2 served the
    agentic corpus between 136k and 365k tokens, where the floored top-k
    charges a constant 0.15 of dense: nine to twenty-seven times the
    selection it stands for, while the indexer it is standing in for is
    charged nothing. Pricing the terms apart puts GLM at 0.032 of dense at
    131k falling to 0.021 at 365k -- and, unlike the floor, it moves with the
    prompt, which is what a ladder whose context swings by 2.7x needs.

    ``indexer_cost_scale`` prices the kernel rather than the arithmetic. The
    indexer's top-k is fused on some stacks and not others -- SGLang runs it
    through aiter's one-block kernel on gfx950 but falls back to an unfused
    Torch path on gfx942 -- and the selection is parallelism-starved at low
    concurrency (batch 4 with 4 draft tokens is 16 workgroups on a 256-CU
    MI355X), so the same arithmetic costs several times more on the fallback.
    1.0 is the fused path; raise it to charge a stack that does not have one.

    Returns ``None`` when the model is not a uniform top-k sparse model, so
    the caller can fall through to whatever it did before.
    """
    ctx = int(context_len or 0)
    topk = int(topk or 0)
    if ctx <= 0 or topk <= 0:
        return None
    layers = int(getattr(model_config, "num_layers", 0) or 0)
    idx_width = int(getattr(model_config, "sparse_index_head_dim", 0) or 0)
    idx_heads = int(getattr(model_config, "sparse_index_n_heads", 0) or 0)
    if layers <= 0 or idx_width <= 0 or idx_heads <= 0:
        return None

    heads = int(getattr(model_config, "num_attention_heads", 0) or 0)
    if heads <= 0:
        return None
    if getattr(model_config, "multi_latent_attention", False):
        # Absorbed MLA reads the latent plus the positional part for the
        # scores and the latent again for the values, per KV entry.
        latent = int(getattr(model_config, "kv_lora_rank", 0) or 0) or int(
            getattr(model_config, "kv_channels", 0) or 0
        )
        rope = int(getattr(model_config, "qk_pos_emb_head_dim", 0) or 0)
        main_per_token = heads * ((latent + rope) + latent)
    else:
        # GQA reads a head-width key and a head-width value per query head.
        width = int(getattr(model_config, "kv_channels", 0) or 0)
        main_per_token = heads * 2 * width
    if main_per_token <= 0:
        return None

    # ``sparse_index_layers`` is 0 for "every layer"; models that leave the
    # first few dense, or that share one layer's index across the layers
    # after it, run the indexer on fewer than they have.
    indexed = int(getattr(model_config, "sparse_index_layers", 0) or 0) or layers
    indexed = min(indexed, layers)

    selection = min(topk, ctx) / ctx
    indexing = (indexed / layers) * (idx_heads * idx_width) / main_per_token
    return selection + indexing * max(0.0, float(indexer_cost_scale))


def sparse_indexer_decode_overhead(
    model_config, topk: int, indexer_cost_scale: float = 1.0
) -> float:
    """Extra decode attention a stack pays for an unfused indexer selection.

    Decode is charged dense, and that charge is calibrated: withdrawing the
    top-k discount is what moved DeepSeek-V4 from 0.53x of measured TPOT to
    0.83-0.94x. So the fused path must stay exactly where that calibration
    left it, and only the excess over it is added here -- 0.0 at a cost scale
    of 1.0, by construction.

    What the excess is proportional to is the indexer's share of the layer,
    not the whole step, because the selection is the only part a different
    top-k kernel changes. Bounded by construction too: GLM-5.2's indexer is
    1.6% of its attention arithmetic, so even an eight-fold slower kernel is
    a ninth of the step rather than a multiple of it. That agrees with the
    only end-to-end number available -- routing the ROCm decode top-k through
    aiter's one-block kernel is 3.3x on the kernel and 5.6% on the trace --
    and it is worth stating plainly that a term this size cannot be what
    separates a 4x throughput miss from a correct one.
    """
    over = max(0.0, float(indexer_cost_scale) - 1.0)
    if over <= 0.0:
        return 0.0
    # Reuse the geometry by asking for the scale at a context long enough
    # that selection has fallen away and only the indexing term is left.
    ctx = max(1, int(topk or 0)) * 4096
    fused = uniform_sparse_attention_scale(model_config, ctx, topk, 1.0)
    if fused is None:
        return 0.0
    return max(0.0, fused - min(int(topk or 0), ctx) / ctx) * over


# Representative expert grouped-GEMM compute multipliers by expert dtype.
_MOE_EXPERT_DTYPE_SPEEDUP = {
    "bf16": 1.0,
    "fp8": 0.55,
    "fp8_e4m3": 0.55,
    "mxfp4": 0.35,
    "fp4": 0.35,
}

# Fused elementwise kernels cut per-step launch overhead by this factor.
_FUSED_KERNEL_OVERHEAD_FACTOR = 0.7


# CUDA-graph presets → (decode_step_overhead_us, mixed_batch_penalty).
# Representative, ROCm-order-of-magnitude values; override with the explicit
# low-level knobs for a measured number.
_CUDAGRAPH_PRESETS = {
    "none": (40.0, 0.0),
    "piecewise": (8.0, 0.15),
    "full": (3.0, 0.0),
}


@dataclass
class InferenceCollectiveConfig:
    """Knobs for the explicit inference communication model (feature B).

    When :attr:`enabled` the inference performance projector replaces the
    layer profiler's *implicit* TP-AllReduce / EP-AllToAll cost with an
    explicit, reportable communication model.  At default values it
    reproduces the implicit cost; the knobs below let a user model
    **custom collective ops** — forcing a specific algorithm, hiding comm
    behind compute (overlap), or applying a fused-op speedup (e.g.
    AllReduce+RMSNorm fusion, DeepEP-style overlapped dispatch/combine).
    """

    enabled: bool = True
    # Algorithm override for the TP AllReduce / EP AllToAll. ``auto`` lets the
    # collective model pick the fastest; otherwise force a specific algorithm.
    tp_allreduce_algo: str = "auto"  # auto | ring | one_shot | two_shot | hierarchical
    ep_a2a_algo: str = "auto"  # auto | direct | single_shot | hierarchical
    # Fraction of communication hidden behind compute (0 = none, fully
    # exposed; 1 = fully overlapped). Set per phase.
    prefill_overlap: float = 0.0
    decode_overlap: float = 0.0
    # Custom fused-op efficiency multipliers applied to comm time
    # (<1.0 = faster, models kernel fusion / better algorithms). 1.0 = none.
    tp_allreduce_efficiency: float = 1.0
    ep_a2a_efficiency: float = 1.0
    # ROCm "quick reduce": low-latency quantized all-reduce for small messages.
    # When set, applies an extra speedup multiplier to the TP AllReduce time
    # (models the small-message latency win). ``False`` = standard all-reduce.
    quick_reduce: bool = False
    # Fused RMSNorm + AllReduce: communication–computation fusion that hides
    # part of the TP all-reduce latency behind the norm. When set, applies an
    # extra speedup multiplier to the TP AllReduce time. ``False`` = unfused.
    fuse_rmsnorm_allreduce: bool = False
    # Whether to charge pipeline-stage P2P (send/recv) latency. Only nonzero
    # when pipeline_model_parallel_size > 1.
    include_pp_p2p: bool = True
    # Engine time per pipeline hop per forward, beyond the transfer: the next
    # stage's scheduling and synchronisation on the host. A PP-n forward makes
    # n hops, the n-1 activation boundaries and the sampled tokens' return to
    # the first stage. SGLang on MI355X at one client measured 920-1130 us per
    # hop over PP 2/4/8 on Llama-3.1-8B, Qwen3-14B-FP8 and Qwen3.6-35B-A3B
    # (TP1), about 55 us of it the send/recv.
    pp_stage_overhead_us: float = 970.0
    # Scheduler host time per iteration that a stage pays in series with its
    # forward once the pipeline is full: with micro-batches queued upstream a
    # stage never waits on its neighbour, so the batch preparation it hides in
    # that wait at one client lands on every stage. SGLang forces the overlap
    # schedule off under PP; its TP1 overlap-off minus overlap-on step on
    # MI355X read 329 us + 6.3 us per running request, within 0.08 ms across
    # Llama-3.1-8B, Qwen3-14B-FP8 and Qwen3.6-35B-A3B at 1-64 requests.
    pp_host_us: float = 329.0
    pp_host_per_req_us: float = 6.3
    # Optional hardware overrides forwarded to ``get_default_args`` (node_bw,
    # pod_bw, bw_eff, latencies, ...). ``None`` uses the model defaults.
    hardware_config: dict | None = None
    # Datasheet interconnect for this GPU, from ``INTERCONNECT_PROFILES``.
    # ``None`` resolves from the GPU architecture, falling back to the
    # collective model's own defaults (one 8-GPU server).
    interconnect: dict[str, float] | None = None


# Published interconnect specs by GPU architecture: per-GPU link bandwidth
# (GB/s, bidirectional), how many GPUs that link reaches through the switch
# fabric, and the per-GPU NIC leaving it. Datasheet figures only -- bandwidth
# efficiencies and latencies stay at the collective model's own defaults rather
# than being set per vendor, so nothing here is fitted to a target number.
#
# The small-message intra-node fits in ``collectives`` still apply on top: they
# describe vLLM's own all-reduce kernel, which is the same algorithm everywhere,
# and their achieved bandwidths were measured on mi355x. Replacing them with the
# analytical model here priced a 25 KB tensor-parallel all-reduce at the 10 us
# floor, which over 78 layers is more than half of a whole measured gb300 decode
# step -- so the floor, not the fit, is what does not transfer.
INTERCONNECT_PROFILES: dict[str, dict[str, float]] = {
    # These racks switch 1.8 TB/s per GPU across all 72 GPUs in the domain, so
    # even a wide tensor-parallel or expert group stays on the fabric instead of
    # crossing a NIC. The link off the rack carries 800 Gb/s per GPU.
    "gb200": {"domain_gpus": 72, "node_bw": 1800.0, "pod_bw": 100.0},
    "gb300": {"domain_gpus": 72, "node_bw": 1800.0, "pod_bw": 100.0},
}


# Per-kernel decode occupancy by GPU architecture (microseconds), the constant
# documented at ``InferenceRequestConfig.decode_kernel_occupancy_us``. The two
# entries do not have the same standing and should not be read as if they did.
#
# The 4.98 us figure is measured: solving ``step(tp) = floor + compute(1)/tp``
# over real mi355x decode steps at TP=1,2,4,8 gives a 2.72 ms fixed cost, which
# over the 546 kernels gpt-oss issues is 4.98 us each. Two other models then land
# within 13% of it without being refitted.
#
# The 2.00 us figure is calibrated, not measured: no equivalent TP sweep has been
# run on that architecture, so the value is the one that best fits 14 measured
# GLM-5.2 deployments on it. Fitting on half of them and scoring the other half
# is what makes it more than a curve fit -- see the held-out check in
# bench_scratch -- but a fleet number still carries whatever else was wrong in
# the deployments it was fitted to, and cannot be separated from them after
# the fact.
#
# Every entry here should be a measurement, and one of them is not. The sweep
# behind the measured figure is the whole procedure and it transfers anywhere:
# time a single decode step per tensor-parallel rung on the target GPU with real
# weights, solve ``step(tp) = floor + compute(1)/tp`` for the intercept, and
# divide by the kernels that model issues. It needs a node of the architecture
# being measured and nothing else, and it retires a fitted constant for good --
# so it is worth running for every architecture this table serves, not only for
# the ones whose fleets happen to disagree with the default.
#
# Architectures nobody has timed are deliberately absent rather than assigned a
# neighbour's number: sharing a maker is not evidence of sharing a floor, which
# is the very thing this table exists to record. They take the measured default.
DEFAULT_DECODE_OCCUPANCY_US: float = 4.98

DECODE_OCCUPANCY_PROFILES: dict[str, float] = {
    "mi300x": 4.98,
    "mi325x": 4.98,
    "mi355x": 4.98,
    "gfx942": 4.98,
    "gfx950": 4.98,
    "gb200": 2.00,
    "gb300": 2.00,
    "b200": 2.00,
}


def resolve_decode_occupancy_us(gpu_arch: str | None) -> float:
    """Per-kernel decode occupancy (us) for a named GPU architecture."""
    if not gpu_arch:
        return DEFAULT_DECODE_OCCUPANCY_US
    return DECODE_OCCUPANCY_PROFILES.get(str(gpu_arch).lower().strip(), DEFAULT_DECODE_OCCUPANCY_US)


@dataclass
class DisaggregationConfig:
    """Prefill/decode disaggregation (feature A).

    Models separate prefill and decode worker pools, each with its own
    parallelism, plus the KV-cache transfer cost incurred when a request
    migrates from a prefill worker to a decode worker.  When disabled the
    projector runs the standard colocated two-phase model.
    """

    enabled: bool = False
    # Per-pool parallelism overrides. ``None`` falls back to the shared
    # ``model_parallel_config`` values.
    prefill_tp: int | None = None
    prefill_pp: int | None = None
    prefill_ep: int | None = None
    decode_tp: int | None = None
    decode_pp: int | None = None
    decode_ep: int | None = None
    # Per-pool attention-DP degree. ``None`` falls back to the shared
    # ``attention_data_parallel_size``. Real disaggregated deployments routinely
    # differ here -- the measured GLM-5.2 deployments run DP attention on
    # prefill and plain TP attention on decode -- and a single global degree
    # cannot express that, nor a TP4 prefill beside a TP16 decode that each
    # want the full width. Each degree must divide its own pool's TP.
    prefill_attention_dp: int | None = None
    decode_attention_dp: int | None = None
    # Number of replicas in each pool (for aggregate-throughput / GPU split).
    prefill_replicas: int = 1
    decode_replicas: int = 1
    # Running-request cap per replica of each pool (SGLang's
    # --max-running-requests, vLLM's --max-num-seqs). ``None`` falls back to
    # the shared ``max_num_seqs``. The pools are separate servers and are
    # launched with separate caps: InferenceX's SGLang split recipes cap a
    # plain-TP decode server at 128 while its attention-DP one runs 1024.
    prefill_max_running: int | None = None
    decode_max_running: int | None = None
    # KV-cache transfer link. ``None`` bw uses the inter-node (pod) bandwidth
    # from the collective model; latency is a fixed per-transfer overhead (us).
    kv_transfer_bw_gbps: float | None = None
    kv_transfer_latency_us: float = 0.0
    # Friendly preset over the two link knobs above, naming the KV-transfer
    # engine: "nixl", "mooncake", or "mori".  ``None`` leaves the explicit link
    # values untouched.  An explicit non-zero/non-None link knob overrides the
    # preset value for that field.
    transfer_backend: str | None = None

    def resolved_kv_transfer_bw_gbps(self) -> float | None:
        if self.kv_transfer_bw_gbps:
            return float(self.kv_transfer_bw_gbps)
        return _TRANSFER_BACKEND_PRESETS.get(self.transfer_backend, (None, 0.0))[0]

    def resolved_kv_transfer_latency_us(self) -> float:
        if self.kv_transfer_latency_us:
            return float(self.kv_transfer_latency_us)
        return _TRANSFER_BACKEND_PRESETS.get(self.transfer_backend, (None, 0.0))[1]

    def prefill_parallel(self, mp: ModelParallelConfig) -> "ModelParallelConfig":
        return _override_parallel(
            mp,
            self.prefill_tp,
            self.prefill_pp,
            self.prefill_ep,
            self.prefill_attention_dp,
            "prefill",
        )

    def decode_parallel(self, mp: ModelParallelConfig) -> "ModelParallelConfig":
        return _override_parallel(
            mp, self.decode_tp, self.decode_pp, self.decode_ep, self.decode_attention_dp, "decode"
        )


# KV-transfer engine presets → (kv_transfer_bw_gbps, kv_transfer_latency_us).
# Representative effective point-to-point KV link numbers; override with the
# explicit link knobs for a measured fabric.
_TRANSFER_BACKEND_PRESETS = {
    "nixl": (400.0, 5.0),
    "mooncake": (200.0, 10.0),
    "mori": (300.0, 7.0),
}


def _override_parallel(
    mp: ModelParallelConfig,
    tp: int | None,
    pp: int | None,
    ep: int | None,
    attn_dp: int | None = None,
    pool: str = "pool",
) -> ModelParallelConfig:
    """Return a copy of ``mp`` with TP/PP/EP/attention-DP optionally overridden."""
    from copy import copy

    out = copy(mp)
    if tp is not None:
        out.tensor_model_parallel_size = int(tp)
    if pp is not None:
        out.pipeline_model_parallel_size = int(pp)
    if ep is not None:
        out.expert_model_parallel_size = int(ep)
    if attn_dp is not None:
        dp = max(1, int(attn_dp))
        pool_tp = max(1, out.tensor_model_parallel_size)
        if pool_tp % dp:
            raise ValueError(f"{pool}_attention_dp={dp} must divide {pool}_tp={pool_tp}")
        out.attention_data_parallel_size = dp
    return out


@dataclass
class InferenceConfig:
    """Configuration for inference / serving projection.

    Reuses the same :class:`ModelConfig` / :class:`ModelParallelConfig` as
    training (so the existing profiler tree can estimate forward compute and
    parameter counts) but swaps the training :class:`RuntimeConfig` for an
    :class:`InferenceRequestConfig`.
    """

    model_config: ModelConfig
    request_config: InferenceRequestConfig
    model_parallel_config: ModelParallelConfig
    collective_config: InferenceCollectiveConfig = field(default_factory=InferenceCollectiveConfig)
    disaggregation_config: DisaggregationConfig = field(default_factory=DisaggregationConfig)

    def __post_init__(self) -> None:
        mp = self.model_parallel_config
        dp = max(1, int(getattr(mp, "attention_data_parallel_size", 1) or 1))
        tp = max(1, int(mp.tensor_model_parallel_size))
        # Attention DP subdivides the tensor-parallel group rather than adding
        # GPUs: each of the dp groups runs attention at tp/dp, so the split has
        # to be even and cannot be wider than the group it splits.
        if dp > 1 and (dp > tp or tp % dp):
            raise ValueError(
                f"attention_data_parallel_size={dp} must divide tensor_model_parallel_size={tp}"
            )

    def as_training_config(self, *, batch_size: int, seq_len: int) -> TrainingConfig:
        """Build a throwaway :class:`TrainingConfig` view for a given
        (batch, seq_len) so the existing profiler tree can be reused for
        forward-only compute estimation.
        """
        runtime = RuntimeConfig(
            global_batch_size=batch_size,
            micro_batch_size=batch_size,
            sequence_length=seq_len,
            data_parallel_size=1,
        )
        return TrainingConfig(
            model_config=self.model_config,
            runtime_config=runtime,
            model_parallel_config=self.model_parallel_config,
        )


def update_config_from_args(config, args):
    for f in fields(config):
        if hasattr(args, f.name):
            setattr(config, f.name, getattr(args, f.name))
    return config


def megatron_derive_default_args(args):
    world_size = int(os.getenv("NNODES", "1")) * int(os.getenv("GPUS_PER_NODE", "8"))
    if args.kv_channels is None:
        args.kv_channels = args.hidden_size // args.num_attention_heads

    if not args.group_query_attention:
        # A model that declares fewer KV heads than query heads is doing
        # grouped-query attention whether or not it also set the flag, so honour
        # the declaration instead of overwriting it. Every consumer -- the KV
        # cache sizing and all four attention roofline paths -- gates on the flag
        # and not on the head counts, so discarding the count here charged
        # DeepSeek-V4 all 128 of its query heads against the single KV head it
        # actually caches, and the model stopped fitting a context it serves.
        groups = int(args.num_query_groups or 0)
        if 0 < groups < int(args.num_attention_heads):
            args.group_query_attention = True
        else:
            args.num_query_groups = args.num_attention_heads

    if not hasattr(args, "context_parallel_size") or args.context_parallel_size is None:
        args.context_parallel_size = 1
    if not hasattr(args, "data_parallel_size") or args.data_parallel_size is None:
        args.data_parallel_size = world_size // (
            args.tensor_model_parallel_size
            * args.pipeline_model_parallel_size
            * args.context_parallel_size
        )
    if not hasattr(args, "virtual_pipeline_model_parallel_size"):
        args.virtual_pipeline_model_parallel_size = None
    if not hasattr(args, "num_layers_per_virtual_pipeline_stage"):
        args.num_layers_per_virtual_pipeline_stage = None
    if (
        args.num_layers_per_virtual_pipeline_stage is None
        and args.virtual_pipeline_model_parallel_size is None
    ):
        args.virtual_pipeline_model_parallel_size = 1
    elif args.num_layers_per_virtual_pipeline_stage is not None:
        args.virtual_pipeline_model_parallel_size = args.num_layers // (
            args.num_layers_per_virtual_pipeline_stage * args.pipeline_model_parallel_size
        )

    args.share_embeddings_and_output_weights = not args.untie_embeddings_and_output_weights

    if args.num_experts is None:
        args.moe_pattern = [0] * args.num_layers
    else:
        if isinstance(args.moe_layer_freq, int):
            args.moe_pattern = [
                1 if (i % args.moe_layer_freq == 0) else 0 for i in range(args.num_layers)
            ]
        elif isinstance(args.moe_layer_freq, list):
            args.moe_pattern = args.moe_layer_freq
        elif isinstance(args.moe_layer_freq, str):
            try:
                parsed = eval(args.moe_layer_freq)
            except Exception as e:
                raise ValueError(f"Invalid moe_layer_freq format: {args.moe_layer_freq}") from e

            # Handle case where eval returns an int (e.g., "1" -> 1 means all layers are MoE)
            if isinstance(parsed, int):
                if parsed == 1:
                    # All layers are MoE
                    args.moe_pattern = [1] * args.num_layers
                else:
                    # Every Nth layer is MoE
                    args.moe_pattern = [
                        1 if (i % parsed == 0) else 0 for i in range(args.num_layers)
                    ]
            elif isinstance(parsed, list):
                # Handle list-based moe_layer_freq pattern
                if len(parsed) > args.num_layers:
                    # Truncate to first num_layers elements (for proxy models with fewer layers)
                    # This is safe: we're using a subset of the pattern for faster profiling
                    args.moe_pattern = parsed[: args.num_layers]
                elif len(parsed) < args.num_layers:
                    # If the pattern is shorter than num_layers, this is likely an error
                    # (config specifies fewer layers than requested)
                    raise ValueError(
                        f"moe_layer_freq pattern has {len(parsed)} elements but num_layers={args.num_layers}. "
                        f"The pattern length must match or exceed num_layers. "
                        f"Pattern: {parsed}"
                    )
                else:
                    # Exact match - use as-is (normal case for full model)
                    args.moe_pattern = parsed
            else:
                raise ValueError(f"Invalid moe_layer_freq format after eval: {type(parsed)}")

    # naming conversion
    args.sequence_length = args.seq_length
    args.context_model_parallel_size = args.context_parallel_size

    # Use model's vocab size if set, otherwise default to 100352
    if not hasattr(args, "padded_vocab_size") or args.padded_vocab_size is None:
        args.padded_vocab_size = 100352

    return args


def convert_config_to_projection_config(config) -> TrainingConfig:
    args = config.get_module_config("pre_trainer")
    framework = getattr(args, "framework", "")
    if framework == "megatron":
        args = megatron_derive_default_args(args)
    else:
        raise NotImplementedError(f"Unsupported framework: {framework}")

    model_config = update_config_from_args(ModelConfig(), args)
    runtime_config = update_config_from_args(RuntimeConfig(), args)
    model_parallel_config = update_config_from_args(ModelParallelConfig(), args)

    training_config = TrainingConfig(
        model_config=model_config,
        runtime_config=runtime_config,
        model_parallel_config=model_parallel_config,
    )

    return training_config


def convert_config_to_inference_config(
    config,
    *,
    inference_overrides: dict | None = None,
) -> InferenceConfig:
    """Build an :class:`InferenceConfig` from an experiment config.

    Reuses :func:`convert_config_to_projection_config` for the model
    and parallelism config, then layers an :class:`InferenceRequestConfig`
    on top.  ``inference_overrides`` (typically parsed from CLI flags) takes
    precedence over any ``inference:`` block embedded in the YAML.
    """
    training_config = convert_config_to_projection_config(config)

    # Allow an optional ``inference:`` block in the pre_trainer module config
    # (so a single workload YAML can carry a default serving profile).
    args = config.get_module_config("pre_trainer")
    yaml_inf = getattr(args, "inference", None) or {}
    if not isinstance(yaml_inf, dict):
        yaml_inf = {}

    request = InferenceRequestConfig()
    # 1) seed from the training seq_length so a bare config still works.
    if getattr(training_config.runtime_config, "sequence_length", 0):
        request.input_seq_len = int(training_config.runtime_config.sequence_length)
    # 2) apply YAML inference block, then 3) CLI overrides.
    overrides = inference_overrides or {}
    for source in (yaml_inf, overrides):
        for f in fields(request):
            if f.name in source and source[f.name] is not None:
                setattr(request, f.name, source[f.name])

    # ---- Collective (feature B) + disaggregation (feature A) configs ----
    collective = InferenceCollectiveConfig()
    disagg = DisaggregationConfig()
    # YAML may carry nested ``collective:`` / ``disaggregation:`` blocks; CLI
    # overrides arrive flattened (e.g. ``collective_*`` / ``disagg_*`` keys).
    yaml_coll = yaml_inf.get("collective") if isinstance(yaml_inf.get("collective"), dict) else {}
    yaml_disagg = (
        yaml_inf.get("disaggregation") if isinstance(yaml_inf.get("disaggregation"), dict) else {}
    )
    _apply_fields(collective, yaml_coll)
    _apply_fields(disagg, yaml_disagg)
    _apply_prefixed(collective, overrides, prefix="collective_")
    _apply_prefixed(disagg, overrides, prefix="disagg_")

    # Attention data parallelism is a parallel axis that only exists in serving,
    # so it rides in with the inference block rather than the trainer's.
    mp = training_config.model_parallel_config
    attn_dp = overrides.get(
        "attention_data_parallel_size", yaml_inf.get("attention_data_parallel_size")
    )
    if attn_dp is not None:
        mp.attention_data_parallel_size = int(attn_dp)
    # Decode context parallelism arrives the same way, and for the same reason.
    dcp = overrides.get(
        "decode_context_parallel_size", yaml_inf.get("decode_context_parallel_size")
    )
    if dcp is not None:
        mp.decode_context_parallel_size = int(dcp)

    return InferenceConfig(
        model_config=training_config.model_config,
        request_config=request,
        model_parallel_config=mp,
        collective_config=collective,
        disaggregation_config=disagg,
    )


def _apply_fields(target, source: dict) -> None:
    """Set dataclass fields on ``target`` from matching keys in ``source``."""
    if not source:
        return
    valid = {f.name for f in fields(target)}
    for key, val in source.items():
        if key in valid and val is not None:
            setattr(target, key, val)


def _apply_prefixed(target, source: dict, *, prefix: str) -> None:
    """Set dataclass fields from ``source`` keys of the form ``<prefix><field>``."""
    if not source:
        return
    valid = {f.name for f in fields(target)}
    for key, val in source.items():
        if not key.startswith(prefix):
            continue
        name = key[len(prefix) :]
        if name in valid and val is not None:
            setattr(target, name, val)
