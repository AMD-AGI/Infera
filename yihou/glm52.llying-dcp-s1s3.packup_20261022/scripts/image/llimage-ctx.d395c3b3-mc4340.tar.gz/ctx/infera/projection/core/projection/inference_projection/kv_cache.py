###############################################################################
# Copyright (c) 2025, Advanced Micro Devices, Inc. All rights reserved.
#
# See LICENSE for license information.
###############################################################################
"""KV-cache memory model for inference projection.

The KV cache is the defining memory term of LLM serving: every resident
sequence stores per-layer Key/Value tensors that grow with context length.
This module sizes that cache analytically, accounting for:

  * GQA / MQA  — fewer KV heads than query heads.
  * MLA        — a single compressed latent KV per token (DeepSeek V2/V3).
  * Tensor parallelism — KV heads shard across TP ranks.
  * Data-parallel attention — requests, rather than heads, split across ranks.
  * Pipeline parallelism — only the layers on a rank store cache.
  * KV-cache quantization — fp8 / int8 halve (or quarter) the footprint.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from infera.projection.core.projection.training_config import (
    InferenceConfig,
    dtype_num_bytes,
    uses_latent_attention,
)


@dataclass
class KVCacheBreakdown:
    """Per-rank KV-cache sizing for a single sequence and for the batch."""

    bytes_per_token_per_layer: float
    layers_on_rank: int
    bytes_per_token: float  # across all layers on this rank
    bytes_per_sequence: float  # at max_context_len
    bytes_total: float  # across the sequences resident on this rank
    max_context_len: int
    concurrency: int  # resident sequences across the replica
    sequences_on_rank: int  # concurrency / attention-DP size
    kv_cache_dtype: str


def _num_kv_heads(model_config) -> int:
    if model_config.group_query_attention and model_config.num_query_groups:
        return int(model_config.num_query_groups)
    return int(model_config.num_attention_heads)


def attention_dp_size(inference_config: InferenceConfig) -> int:
    """Ranks the attention stage is data-parallel across (1 = tensor-parallel)."""
    mp = inference_config.model_parallel_config
    return max(1, int(getattr(mp, "attention_data_parallel_size", 1) or 1))


def decode_context_parallel_size(inference_config: InferenceConfig) -> int:
    """Ranks a single sequence's context is split across during decode.

    Decode context parallelism (vLLM ``--decode-context-parallel-size``, SGLang
    ``--dcp-size``) is the one axis that shrinks an MLA cache. Tensor
    parallelism cannot: the latent is shared across heads, so every rank keeps
    a whole copy. DCP instead gives each rank a slice of the *tokens*, so a
    rank stores ``context / dcp`` per sequence and the replica holds ``dcp``
    times as many tokens.

    This is not a small effect on the models that use it. The published Kimi-K3
    rows move from a 2.9M-token pool at ``dcp_size: 1`` to 30.3M at
    ``dcp_size: 8`` on the same eight GPUs.
    """
    mp = inference_config.model_parallel_config
    for name in ("decode_context_parallel_size", "context_parallel_size"):
        v = getattr(mp, name, None)
        if v:
            return max(1, int(v))
    return 1


def kv_bytes_per_token_per_layer(inference_config: InferenceConfig) -> float:
    """Bytes of KV cache stored per token, per transformer layer, *per rank*."""
    mc = inference_config.model_config
    mp = inference_config.model_parallel_config
    tp = max(1, mp.tensor_model_parallel_size)
    kv_bytes = dtype_num_bytes(inference_config.request_config.kv_cache_dtype)

    if mc.multi_latent_attention:
        # MLA caches a single compressed latent per token (kv_lora_rank) plus
        # the decoupled RoPE key (qk_pos_emb_head_dim).  This latent is shared
        # across heads, so it is *not* sharded by TP heads.
        latent = int(mc.kv_lora_rank or 0) + int(mc.qk_pos_emb_head_dim or 0)
        return latent * kv_bytes

    # DeepSeek-V4 keeps ``multi_latent_attention`` off so the trainer does not
    # take the V3 MLA builder (CSA/HCA/SWA need their own spec). The cache is
    # still one 576-byte latent per token -- 512-d shared K=V plus 64-d
    # decoupled RoPE -- which is what vLLM registers, not K and V of
    # ``kv_channels`` each. Charging 2×512 rejected the measured 12-prefill
    # / 1-decode GB300 winner at 4096 in-flight.
    rope = int(getattr(mc, "qk_pos_emb_head_dim", 0) or 0)
    if uses_latent_attention(mc):
        return (int(mc.kv_channels) + rope) * kv_bytes

    # Standard MHA / GQA: K and V each store (kv_heads_per_rank * head_dim).
    # Data-parallel attention holds whole heads instead: a rank owns a subset of
    # the requests rather than a slice of every request's heads. What it saves
    # is counted once, on the request count in estimate_kv_cache.
    kv_heads = _num_kv_heads(mc)
    kv_heads_per_rank = (
        kv_heads if attention_dp_size(inference_config) > 1 else max(1, kv_heads // tp)
    )
    head_dim = int(mc.kv_channels)
    return 2.0 * kv_heads_per_rank * head_dim * kv_bytes


def index_bytes_per_token_per_layer(inference_config: InferenceConfig) -> float:
    """Bytes the sparse-attention indexer stores per token, per indexed layer, per rank.

    Native sparse attention has to decide what to attend to before it can
    attend, and it decides by scoring the query against one small index key per
    past token. Those keys are a per-token cache in their own right, sitting
    beside the KV cache.

    One key per token per indexed layer, not one per head: the key is
    head-shared the way an MLA latent is, and for the same reason it is not
    divided by tensor parallelism either -- every rank scoring its own query
    heads needs the whole key. The dtype is the stack's, not
    ``kv_cache_dtype``, which is what makes the term separable in a memory log.
    """
    mc = inference_config.model_config
    if not mc.sparse_index_layer_count():
        return 0.0
    return int(mc.sparse_index_head_dim) * dtype_num_bytes(mc.sparse_index_dtype or "bf16")


def linear_state_bytes_per_layer(inference_config: InferenceConfig) -> float:
    """Bytes of recurrent state one linear-attention layer stores, per rank, per sequence.

    A KDA / gated-delta layer's state is a d×d matrix per head. Heads shard
    the same way GQA does: tensor-parallel splits them, data-parallel
    attention keeps them whole and splits the requests instead. The state is
    an activation (bf16), not the quantized KV cache -- it is updated every
    token and is not a stored key.
    """
    mc = inference_config.model_config
    if not mc.linear_attention_layer_count() or int(mc.num_attention_heads or 0) <= 0:
        return 0.0
    # One dk×dv state per value head; the short convolution keeps a window of
    # ``kernel - 1`` rows over the q, k and v channels.
    hk, hv, dk, dv = mc.linear_attention_geometry()
    mp = inference_config.model_parallel_config
    tp = 1 if attention_dp_size(inference_config) > 1 else max(1, mp.tensor_model_parallel_size)
    hk, hv = max(1, hk // tp), max(1, hv // tp)
    elem = dtype_num_bytes("bf16")
    state = hv * dk * dv * elem
    kernel = int(getattr(mc, "linear_attention_conv_kernel", 0) or 0)
    if kernel > 1:
        state += (2 * hk * dk + hv * dv) * (kernel - 1) * elem
    return state


def estimate_kv_cache(
    inference_config: InferenceConfig,
    layers_on_rank: int,
    *,
    concurrency: int | None = None,
    context_len: int | None = None,
) -> KVCacheBreakdown:
    """Size the KV cache on one rank.

    Args:
        inference_config: The serving configuration.
        layers_on_rank: Number of transformer layers hosted by this rank
            (``num_layers / pp`` for an even split).
        concurrency: Number of resident sequences.  Defaults to the request
            config's ``max_concurrency`` (which itself defaults to
            ``batch_size``).
        context_len: Context length to size each sequence at.  Defaults to
            ``max_context_len``.
    """
    req = inference_config.request_config
    if concurrency is None:
        concurrency = req.resolved_max_concurrency()
    if context_len is None:
        context_len = req.resolved_max_context_len()

    # Paged KV: a sequence's context is allocated in whole blocks (pages), so
    # round the per-sequence length UP to the next multiple of the block size.
    # The last partially-filled block still reserves a full block — this is the
    # internal fragmentation real serving engines (vLLM, SGLang) pay.  ``0``
    # disables paging (contiguous allocation, legacy behaviour).
    block = int(req.kv_block_size or 0)

    def _alloc(ctx: int) -> int:
        if block > 0:
            return math.ceil(ctx / block) * block
        return int(ctx)

    alloc_context_len = _alloc(context_len)

    # Sliding-window / local attention caps a sequence's resident KV at the
    # window (steady state), not the full context. Interleaved models keep some
    # layers full-attention, so blend the per-sequence context by the windowed-
    # layer fraction. Full attention (window 0 or context <= window) is a no-op.
    mc = inference_config.model_config
    window = req.resolved_sliding_window(getattr(mc, "sink_sliding_window", 0))
    if window > 0 and window < context_len:
        frac = req.resolved_sliding_window_fraction(
            getattr(mc, "sink_window_even_layers_only", False)
        )
        effective_context = frac * _alloc(window) + (1.0 - frac) * alloc_context_len
    else:
        effective_context = alloc_context_len

    per_token_per_layer = kv_bytes_per_token_per_layer(inference_config)
    # Hybrid linear attention (KDA / GDN): only the full-attention layers
    # store a per-token cache. The linear layers keep a fixed-size recurrent
    # state per request, charged below, so shrinking the token cache without
    # adding that state would let search fit batches the HBM cannot hold.
    full_frac = mc.full_attention_layer_fraction()
    per_token = per_token_per_layer * max(1, layers_on_rank) * full_frac
    # Native sparse attention's index keys are a second per-token cache, on
    # however many layers carry an indexer. They are not scaled by
    # ``full_frac``: a model is either hybrid-linear or sparse, and where a
    # layer has an indexer it also has the KV cache the indexer selects from.
    n_index = mc.sparse_index_layer_count()
    if n_index:
        index_frac = n_index / max(1, int(mc.num_layers or 0) or n_index)
        per_token += (
            index_bytes_per_token_per_layer(inference_config) * max(1, layers_on_rank) * index_frac
        )
    # Decode context parallelism splits the tokens of one sequence across
    # ranks, so a rank holds its slice of the context rather than all of it.
    per_sequence = per_token * effective_context / decode_context_parallel_size(inference_config)
    lin_frac = 1.0 - full_frac
    if lin_frac > 0.0:
        per_sequence += (
            linear_state_bytes_per_layer(inference_config) * max(1, layers_on_rank) * lin_frac
        )

    # Data-parallel attention splits the running requests across ranks, so a
    # rank stores whole sequences for its own share rather than a slice of every
    # sequence. For MLA that is the only way the cache shrinks at all, since its
    # latent is replicated by tensor parallelism.
    on_rank = math.ceil(concurrency / attention_dp_size(inference_config))
    total = per_sequence * on_rank

    return KVCacheBreakdown(
        bytes_per_token_per_layer=per_token_per_layer,
        layers_on_rank=int(layers_on_rank),
        bytes_per_token=per_token,
        bytes_per_sequence=per_sequence,
        bytes_total=total,
        max_context_len=int(context_len),
        concurrency=int(concurrency),
        sequences_on_rank=int(on_rank),
        kv_cache_dtype=req.kv_cache_dtype,
    )


def max_concurrent_sequences(
    inference_config: InferenceConfig,
    layers_on_rank: int,
    free_bytes_for_kv: float,
    *,
    context_len: int | None = None,
) -> int:
    """How many sequences fit in ``free_bytes_for_kv`` at ``context_len``.

    Useful for answering "how many concurrent requests can this config
    serve?" given HBM left over after weights + activation working set.
    """
    one = estimate_kv_cache(
        inference_config, layers_on_rank, concurrency=1, context_len=context_len
    )
    if one.bytes_per_sequence <= 0:
        return 0
    on_rank = int(max(0, free_bytes_for_kv) // one.bytes_per_sequence)
    # Every attention-DP rank fills its own cache with its own requests, so the
    # replica serves that many sequences per rank.
    return on_rank * attention_dp_size(inference_config)
