###############################################################################
# Copyright (c) 2026, Advanced Micro Devices, Inc. All rights reserved.
#
# SPDX-License-Identifier: MIT
###############################################################################
"""inferasim inference/serving projection CLI.

Analytical + GPU-calibrated projection of TTFT / ITL / throughput / KV-cache
for a serving recipe, plus discrete-event serving simulation. This is the
``inferasim`` product surface over the first-class ``infera.projection.*``
modules.

Examples
--------
Project a recipe from a saved 1-GPU anchor (no GPU needed)::

    python -m infera.projection inference --config <model.yaml> \
        --input-len 1024 --output-len 1024 --inference-batch-size 32 \
        --gpu-arch mi355x --load-benchmark anchor.json

Harvest a GPU-calibrated anchor (needs a ROCm GPU + vLLM), then project::

    python -m infera.projection anchor --model <hf-or-model-name> \
        --benchmark-gpus 1 --save anchor.json
"""

import argparse
import argparse as _argparse  # noqa: F401  (used by arg helpers)
import sys

from infera.projection.core.launcher.parser import add_pretrain_parser
from infera.projection.core.projection.inference_projection import (
    launch_projection_from_cli,
)


def _add_pipeline_schedule_algorithm_arg(parser):
    parser.add_argument(
        "--pipeline-schedule-algorithm",
        type=str,
        required=False,
        default="auto",
        choices=[
            "auto",
            "zerobubble",
            "zerobubble-heuristic",
            "zbv-formatted",
            "zbv-greedy-half",
            "zbv-greedy-min",
            "seaailab-ilp",
            "all",
        ],
        help=(
            "Pipeline schedule for validation and (perf) simulation. "
            "Must not be combined with activation recompute — split-wgrad "
            "schedules pin inputs that recompute cannot free."
        ),
    )


def _add_save_benchmark_arg(parser):
    """``--save-benchmark`` (with deprecated ``--save-profiling`` alias).

    The bench artifact (timing + memory) is shared between perf and
    memory projections; both subparsers accept the same save flag.
    """
    parser.add_argument(
        "--save-benchmark",
        type=str,
        required=False,
        default=None,
        help=(
            "Path to write the bench artifact JSON (timing + memory). "
            "The artifact is shareable: a single bench run can feed both "
            "perf and memory projections via --load-benchmark."
        ),
    )
    parser.add_argument(
        "--save-profiling",
        type=str,
        required=False,
        default=None,
        help=_argparse.SUPPRESS,  # deprecated alias for --save-benchmark
    )


def _add_load_benchmark_arg(parser, *, include_compute_baseline_alias: bool):
    """``--load-benchmark`` (skip bench, project from saved artifact).

    Memory subparser: accept ``--compute-baseline`` as a deprecated alias
    (same semantic — "load a saved bench artifact").

    Perf subparser: do NOT alias ``--compute-baseline`` — that flag has a
    different meaning on the perf side (the bg=1 hybrid baseline), and
    it is registered separately.
    """
    parser.add_argument(
        "--load-benchmark",
        type=str,
        required=False,
        default=None,
        help=(
            "Path to a previously saved bench artifact JSON. When provided, "
            "the bench is skipped and the projection runs directly from the "
            "loaded measurements."
        ),
    )
    for _pool in ("prefill", "decode"):
        parser.add_argument(
            f"--{_pool}-benchmark",
            type=str,
            required=False,
            default=None,
            metavar="PATH",
            help=(
                f"Path to a bench artifact measured on the {_pool} pool, used "
                f"only when --disaggregation is on. A disaggregated deployment "
                f"runs its two pools at different parallelism, attention layout "
                f"and batch composition, so one colocated anchor describes "
                f"neither pool exactly; these let each pool be calibrated "
                f"against its own measurement. Falls back to --load-benchmark "
                f"for whichever pool is not given."
            ),
        )
    parser.add_argument(
        "--load-benchmark-scaling",
        type=str,
        action="append",
        required=False,
        default=None,
        metavar="PATH[,PATH...]",
        help=(
            "Extra bench artifacts for the same model captured at other "
            "--benchmark-gpus values, used to fit how the step scales with TP "
            "instead of assuming TP^-1. Repeatable or comma-separated; only "
            "matters when the benchmark parallelism differs from the target."
        ),
    )
    parser.add_argument(
        "--decode-floor-benchmark",
        type=str,
        required=False,
        default=None,
        metavar="PATH",
        help=(
            "Path to a sharded (e.g. 2-GPU EP-sharded) bench artifact whose "
            "measured decode step defines the hardware latency floor. The "
            "restored decode step is capped from below at this floor per batch "
            "(decode = max(restored, floor)). Above the roofline knee, decode "
            "latency is fixed by per-step launch/dispatch overhead and is "
            "parallelism-invariant, so a single sharded probe supplies the "
            "floor for all more-sharded targets. No-op below the floor."
        ),
    )
    if include_compute_baseline_alias:
        parser.add_argument(
            "--compute-baseline",
            type=str,
            required=False,
            default=None,
            help=_argparse.SUPPRESS,  # deprecated memory-side alias for --load-benchmark
        )


def _add_perf_compute_baseline_arg(parser):
    """Perf-side ``--compute-baseline`` (bg=1 hybrid baseline).

    Distinct semantic from ``--load-benchmark``: this is a *secondary*
    artifact used to source clean compute timings during EP-reduced
    benches.  Kept hidden from --help (internal/subprocess use).
    """
    parser.add_argument(
        "--compute-baseline",
        type=str,
        required=False,
        default=None,
        help=_argparse.SUPPRESS,
    )


def _add_topology_args(parser):
    """``--target-nodes`` / ``--benchmark-gpus`` — shared between memory and perf."""
    parser.add_argument(
        "--target-nodes",
        type=int,
        required=False,
        default=None,
        help=(
            "Target number of nodes for projection. "
            "If not specified, defaults to the minimum nodes required by "
            "the parallelism config (TP × PP × CP / GPUs_per_node)."
        ),
    )
    parser.add_argument(
        "--benchmark-gpus",
        type=int,
        required=False,
        default=None,
        help=(
            "Number of GPUs to use for the underlying bench. When set lower "
            "than GPUS_PER_NODE, enables sub-node benchmarking with "
            "analytical upscaling. Defaults to GPUS_PER_NODE."
        ),
    )


def _add_performance_args(parser):
    """All the perf-specific knobs (profiling-mode, gpu-arch, schedules, etc.)."""
    parser.add_argument(
        "--hardware-config",
        type=str,
        required=False,
        default=None,
        help=(
            "Path to YAML file with hardware configuration for collective communication modeling. "
            "If not provided, uses default cluster parameters.\n\n"
        ),
    )
    parser.add_argument(
        "--profiling-mode",
        type=str,
        required=False,
        default="benchmark",
        choices=["benchmark", "simulate", "both"],
        help=(
            "Profiling mode for layer timing:\n"
            "  benchmark  - Measure on real GPUs (needs GPUs, a serving engine\n"
            "               and --bench-model), then calibrate to what was measured\n"
            "  simulate   - Use simulation backends (origami for GEMM,\n"
            "               analytical model for SDPA). No GPU required.\n"
            "  both       - Run both benchmark and simulation, report side-by-side\n"
            "Default 'benchmark', because a calibrated kernel is the only one\n"
            "whose correlation against real serving has been established. An\n"
            "anchor already in --anchor-store satisfies it without a GPU; with\n"
            "neither an anchor nor a GPU the run stops rather than downgrading,\n"
            "and '--profiling-mode simulate' is how you ask for the uncalibrated\n"
            "analytical path on purpose. 'anchor' always measures.\n"
        ),
    )
    parser.add_argument(
        "--bench-model",
        type=str,
        required=False,
        default=None,
        help=(
            "Checkpoint to serve while measuring (HF id or local path), for\n"
            "--profiling-mode benchmark. Required there because a structural\n"
            "config describes an architecture, not a checkpoint. Weights are\n"
            "served random, so the id only has to name the right shape.\n"
            "Env: INFERASIM_BENCH_MODEL.\n"
        ),
    )
    parser.add_argument(
        "--bench-serving-backend",
        type=str,
        default=None,
        choices=("vllm", "sglang", "atom"),
        help=(
            "Engine to launch while measuring, for --profiling-mode benchmark.\n"
            "The anchor harness drives all three through the same adapters the\n"
            "platform serves with, so this picks which engine's kernels the\n"
            "anchor describes. It is not cosmetic: an architecture its vLLM\n"
            "build cannot load is measurable under an engine that can, and two\n"
            "engines serving one config are two different measurements, which\n"
            "is why they never share an anchor cache entry.\n"
            "Env: INFERASIM_BENCH_SERVING_BACKEND. Default vllm.\n"
        ),
    )
    parser.add_argument(
        "--gemm-backend",
        type=str,
        required=False,
        default=None,
        choices=["origami"],
        help=(
            "GEMM simulation backend (only used when --profiling-mode is 'simulate' or 'both').\n"
            "  origami  - Open-source GEMM performance model (default)\n"
        ),
    )
    parser.add_argument(
        "--gpu-arch",
        type=str,
        required=False,
        default=None,
        help=(
            "Target GPU architecture for simulation (e.g. 'mi300x', 'gfx942', 'mi355x', 'gfx950').\n"
            "If not specified, auto-detected or uses INFERASIM_GPU_ARCH env var.\n"
        ),
    )
    parser.add_argument(
        "--gpu-clock-mhz",
        type=int,
        required=False,
        default=None,
        help=(
            "Override the GPU compute clock frequency in MHz for simulation.\n"
            "If not specified, uses the default from the hardware profile for the\n"
            "given --gpu-arch (e.g. 2100 MHz for MI300X/MI325X).\n"
            "Can also be set via the INFERASIM_GPU_CLOCK_MHZ env var.\n"
            "Example: --gpu-clock-mhz 1500\n"
        ),
    )
    _add_pipeline_schedule_algorithm_arg(parser)
    # Projection-specific overrides.
    parser.add_argument(
        "--target-num-nodes",
        type=int,
        required=False,
        default=None,
        help="Target number of nodes for multinode projection (alias for --target-nodes).",
    )
    parser.add_argument(
        "--target-ep-size",
        type=int,
        required=False,
        default=None,
        help="Override expert_model_parallel_size for projection target.",
    )
    parser.add_argument(
        "--enable-zero-bubble",
        action="store_true",
        default=False,
        help="Enable zero-bubble pipeline scheduling.",
    )
    parser.add_argument(
        "--enable-deepep",
        action="store_true",
        default=False,
        help="Enable DeepEP (async All-to-All overlap with compute).",
    )
    parser.add_argument(
        "--sync-free-stage",
        type=int,
        required=False,
        default=0,
        help="SyncFree MoE stage (0=off, 1=fused router, 2=+DeepEP+grouped, 3=+fused act). Auto-enables DeepEP.",
    )
    parser.add_argument(
        "--num-virtual-stages-per-pipeline-rank",
        type=int,
        required=False,
        default=None,
        help="Override virtual_pipeline_model_parallel_size (VPP) for projection.",
    )
    parser.add_argument(
        "--micro-batch-size",
        type=int,
        required=False,
        default=None,
        help="Override micro_batch_size for projection.",
    )
    parser.add_argument(
        "--global-batch-size",
        type=int,
        required=False,
        default=None,
        help="Override global_batch_size for projection.",
    )
    parser.add_argument(
        "--profile-only",
        action="store_true",
        default=False,
        help=_argparse.SUPPRESS,
    )


def _add_inference_args(parser):
    """Inference / serving projection knobs.

    Reuses ``--gpu-arch`` / ``--gpu-clock-mhz`` / ``--gemm-backend`` from the
    perf arg group (added separately) for the simulation backends.
    """
    parser.add_argument(
        "--inference-mode",
        type=str,
        required=False,
        default="both",
        choices=["performance", "memory", "both"],
        help="Which inference projection to run (default: both).",
    )
    # ---- Request / serving workload ----
    parser.add_argument(
        "--input-len",
        type=int,
        default=None,
        help="Prompt length in tokens (prefill). Defaults to the config seq_length.",
    )
    parser.add_argument(
        "--output-len",
        type=int,
        default=None,
        help="Number of tokens to generate (decode steps).",
    )
    parser.add_argument(
        "--inference-batch-size",
        type=int,
        default=None,
        help="Number of sequences processed together per decode forward.",
    )
    parser.add_argument(
        "--max-concurrency",
        type=int,
        default=None,
        help="Max resident sequences for KV-cache sizing (default: batch size).",
    )
    parser.add_argument(
        "--max-context-len",
        type=int,
        default=None,
        help="Largest context (prompt+generated) for KV sizing (default: input+output).",
    )
    # ---- Precision ----
    parser.add_argument(
        "--weight-dtype",
        type=str,
        default=None,
        help="Resident weight precision (bf16 | fp8 | ...). Default: bf16.",
    )
    parser.add_argument(
        "--kv-cache-dtype",
        type=str,
        default=None,
        help="KV-cache precision (bf16 | fp8 | int8 | ...). Default: bf16.",
    )
    # ---- Serving features ----
    parser.add_argument(
        "--chunked-prefill-size",
        type=int,
        default=None,
        help="Chunked-prefill chunk size in tokens (0 disables).",
    )
    parser.add_argument(
        "--prefix-cache-hit-rate",
        "--prefix-hit-fraction",
        dest="prefix_cache_hit_rate",
        type=float,
        default=None,
        help="Prefix-cache hit rate in [0,1): fraction of each prompt already "
        "resident in the KV cache (automatic prefix caching / shared prefix "
        "reuse). Cached tokens skip prefill, so TTFT scales with (1 - rate). "
        "Default: 0 (cold cache).",
    )
    parser.add_argument(
        "--speculative-num-tokens",
        type=int,
        default=None,
        help="Draft tokens proposed per speculative verify step (0 disables).",
    )
    parser.add_argument(
        "--speculative-acceptance-rate",
        type=float,
        default=None,
        help="A flat per-draft acceptance rate [0,1] at --speculative-num-tokens. "
        "Rescales the measured acceptance curve through the length it implies; "
        "unset, acceptance is read from the curve alone.",
    )
    parser.add_argument(
        "--speculative-acceptance-length",
        type=float,
        default=None,
        help="Tokens one verify step commits (including the verified token) at "
        "--speculative-num-tokens. Rescales the measured acceptance curve "
        "through that point; takes precedence over --speculative-acceptance-rate.",
    )
    parser.add_argument(
        "--speculative-acceptance-curve",
        default=None,
        help="Acceptance-length file to read instead of the model's own: a path, "
        "or a name in INFERASIM_GOLDEN_AL_DIR, configs/speculative/defaults or "
        "InferenceX's golden_al_distribution on GitHub (e.g. glm5.2_mtp.yaml, mtp).",
    )
    parser.add_argument(
        "--speculative-thinking",
        default=None,
        choices=["on", "off"],
        help="Which sweep of the acceptance curve to read: thinking_on (default) "
        "or thinking_off. A curve measured in one mode only is read in that mode.",
    )
    parser.add_argument(
        "--speculative-method",
        default=None,
        help="Drafter family (mtp, eagle3, dspark, ngram, draft_model). Default: "
        "the model YAML's speculative.default, else its MTP head if it ships "
        "one, else eagle3. Sets the drafter whose layers price the draft and "
        "whose measured acceptance curve is read.",
    )
    parser.add_argument(
        "--speculative-entropy",
        default=None,
        help="Move acceptance from coding, where the curves were measured, to a "
        "SPEED-Bench entropy class: low (code, math), mixed (STEM, QA), high "
        "(creative writing, roleplay), or a number on -1..1 between them. "
        "Default: the curve as measured.",
    )
    parser.add_argument(
        "--speculative-max-num-tokens",
        type=int,
        default=None,
        help="Simulate mode: choose the draft depth in 1..N that emits the most "
        "tokens per unit of step time at the projected batch, instead of "
        "--speculative-num-tokens.",
    )
    parser.add_argument(
        "--speculative-draft-layers",
        type=int,
        default=None,
        help="Draft layers per pass, overriding the model YAML's drafter "
        "(mtp_num_layers for MTP) and the method's published one.",
    )
    parser.add_argument(
        "--speculative-draft-vocab",
        type=int,
        default=None,
        help="Draft LM-head vocabulary (EAGLE3 defaults to a pruned 32000).",
    )
    parser.add_argument(
        "--speculative-draft-window",
        type=int,
        default=None,
        help="Attention window of the draft layers (0 = full context).",
    )
    # ---- Token sampling / logits post-processing ----
    parser.add_argument(
        "--no-sampling",
        dest="no_sampling",
        action="store_true",
        help="Drop the token-sampling / logits post-processing cost from each "
        "step (compare against a logits-free forward). Default: sampling modelled.",
    )
    parser.add_argument(
        "--sampling-top-k",
        type=int,
        default=None,
        help="Top-k sampling width (adds a partial-sort pass over the logits). "
        "0 = greedy/argmax (cheapest). Default: 0.",
    )
    parser.add_argument(
        "--sampling-top-p",
        type=float,
        default=None,
        help="Top-p (nucleus) sampling threshold in (0,1]. <1 adds a "
        "threshold+renormalize pass over the logits. Default: 1.0 (off).",
    )
    parser.add_argument(
        "--sampling-temperature",
        type=float,
        default=None,
        help="Sampling temperature. !=1 adds a fused logits-scale pass. Default: 1.0.",
    )
    # ---- Runtime activation quantization / cast ----
    parser.add_argument(
        "--act-quant-dtype",
        choices=["none", "bf16", "fp8", "mxfp4"],
        default=None,
        help="Precision the runtime casts activations to before each "
        "low-precision GEMM (memory-bound cast overhead). Default: auto-detect "
        "from --weight-dtype / model fp8; 'none'/'bf16' drops the cast.",
    )
    # ---- Capacity ----
    parser.add_argument(
        "--hbm-capacity-gb",
        type=float,
        default=None,
        help="Per-GPU HBM capacity (GB). When set, reports fit + max concurrency.",
    )
    parser.add_argument(
        "--kv-cache-memory-fraction",
        type=float,
        default=None,
        help="Fraction of HBM the engine may use (vLLM gpu_memory_utilization / "
        "SGLang mem_fraction_static). Bounds usable HBM + max concurrency. Default: full HBM.",
    )
    parser.add_argument(
        "--kv-block-size",
        type=int,
        default=None,
        help="Paged-KV block (page) size in tokens (vLLM block_size, e.g. 16). "
        "Per-sequence context is rounded up to whole blocks, inflating KV bytes "
        "and lowering max concurrency. Default: 0 (no paging / contiguous).",
    )
    parser.add_argument(
        "--kv-offload-gb-per-gpu",
        type=float,
        default=None,
        help="Host DRAM per GPU used as a second KV tier (TRT-LLM native / "
        "SGLang HiCache 'dram' offload). Holds KV for idle sessions and prefix "
        "blocks evicted from HBM, raising sustainable concurrency; a prefix hit "
        "it holds is fetched over the host link instead of recomputed. "
        "Default: 0 (offload disabled).",
    )
    parser.add_argument(
        "--kv-offload-bw-gbps",
        type=float,
        default=None,
        help="Host<->device bandwidth for the KV offload tier in GB/s. "
        "PCIe 5 x16 is ~64; a cache-coherent host link is ~900. Default: 64.",
    )
    parser.add_argument(
        "--kv-tier",
        action="append",
        default=None,
        metavar="NAME:GB[:GBPS[:LAT_US]]",
        help="A KV storage tier below HBM, per GPU, fastest first; repeat for "
        "a hierarchy (e.g. --kv-tier dram:512 --kv-tier ssd:4000). HBM's "
        "evicted prefix blocks spill one tier down instead of being dropped, "
        "and a later hit on them waits for its blocks to load over that "
        "tier's link before it can prefill. Bandwidth and per-block latency "
        "default by name: dram/host 64 GB/s 2 us, cxl 48 GB/s 4 us, ssd/nvme "
        "12 GB/s 80 us, remote 25 GB/s 20 us. Applies to the DES's block "
        "cache (traces, shared-prefix pools, fleets). Without it, "
        "--kv-offload-gb-per-gpu is used as a single dram tier.",
    )
    parser.add_argument(
        "--des-kv-pool-from-memory",
        action="store_true",
        default=False,
        help="DES: size the KV pool (admission) and the HBM block tier from "
        "the memory projection -- HBM left after weights and activations -- "
        "when --des-kv-cache-tokens / --des-kv-blocks are not given. Implied "
        "by --kv-tier, since a tier below HBM only matters once HBM can fill.",
    )
    parser.add_argument(
        "--workload-resident-tokens",
        type=int,
        default=None,
        help="Mean KV tokens one request of the target workload holds while "
        "resident, which sets how many requests the pool can admit at once and "
        "so where TTFT stops being a service time. For a spread of lengths pass "
        "E[L^2]/E[L], not the mean: a request holds the pool for a time "
        "proportional to its length, so the resident set is length-biased. Do "
        "not discount it by the prefix-cache hit rate -- a cache hit skips "
        "prefill compute, it does not free the blocks. Default: the configured "
        "context (input + output/2), exact for a fixed-length workpoint.",
    )
    parser.add_argument(
        "--kv-pool-tokens",
        type=int,
        default=None,
        help="Size of the KV pool the engine allocated, in tokens, as it "
        'reports at startup (vLLM\'s "GPU KV cache size", SGLang\'s "KV Cache '
        'is allocated. #tokens"). The admission bound is evaluated against '
        "this instead of against the memory model's estimate, which is what "
        "you want when validating against a deployment that is already "
        "running. Default: unset, and the pool is predicted.",
    )
    # ---- Feature B: custom collective ops ----
    coll = parser.add_argument_group("inference collectives (feature B)")
    coll.add_argument(
        "--comm-model",
        type=str,
        default=None,
        choices=["explicit", "builtin"],
        help="Communication model: 'explicit' (knob-driven breakdown, default) "
        "or 'builtin' (folded into layer time, no breakdown).",
    )
    coll.add_argument(
        "--tp-allreduce-algo",
        type=str,
        default=None,
        choices=["auto", "ring", "one_shot", "two_shot", "hierarchical"],
        help="Force the TP AllReduce algorithm (default: auto = fastest).",
    )
    coll.add_argument(
        "--ep-a2a-algo",
        type=str,
        default=None,
        choices=["auto", "direct", "single_shot", "hierarchical"],
        help="Force the EP AllToAll algorithm (default: auto = fastest).",
    )
    coll.add_argument(
        "--prefill-comm-overlap",
        type=float,
        default=None,
        help="Fraction of prefill comm hidden behind compute [0,1] (default 0).",
    )
    coll.add_argument(
        "--decode-comm-overlap",
        type=float,
        default=None,
        help="Fraction of decode comm hidden behind compute [0,1] (default 0).",
    )
    coll.add_argument(
        "--tp-allreduce-efficiency",
        type=float,
        default=None,
        help="TP AllReduce time multiplier (<1 = fused-op speedup, default 1.0).",
    )
    coll.add_argument(
        "--ep-a2a-efficiency",
        type=float,
        default=None,
        help="EP AllToAll time multiplier (<1 = fused/overlapped speedup, default 1.0).",
    )
    coll.add_argument(
        "--quick-reduce",
        action="store_true",
        default=False,
        help="ROCm 'quick reduce': low-latency quantized all-reduce for small "
        "messages (extra TP AllReduce speedup).",
    )
    coll.add_argument(
        "--fuse-rmsnorm-allreduce",
        action="store_true",
        default=False,
        help="Fused RMSNorm + AllReduce: hides part of the TP all-reduce latency "
        "behind the norm (extra TP AllReduce speedup).",
    )
    coll.add_argument(
        "--ep-load-balance",
        type=float,
        default=None,
        help="MoE expert routing imbalance: hottest-rank / mean token-load ratio "
        "(1.0 = perfectly balanced). Inflates MoE expert-compute time on EP>1. Default 1.0.",
    )
    coll.add_argument(
        "--redundant-experts",
        type=int,
        default=None,
        help="Extra replicated expert slots (EPLB) that reduce realized MoE routing "
        "imbalance. Default 0.",
    )
    par = parser.add_argument_group("inference parallelism")
    par.add_argument(
        "--attention-dp-size",
        type=int,
        default=None,
        help="Run attention data-parallel across this many ranks, splitting the "
        "running requests between them while the MLP/MoE stay tensor/expert "
        "parallel. Must divide the tensor-parallel size, which it subdivides "
        "rather than adds to. This is how MLA models are served: tensor "
        "parallelism replicates their compressed KV latent instead of sharding "
        "it, so only splitting by request shrinks the cache a rank holds.",
    )
    par.add_argument(
        "--decode-context-parallel-size",
        type=int,
        default=None,
        help="Split each sequence's context across this many ranks during "
        "decode (vLLM --decode-context-parallel-size, SGLang --dcp-size). The "
        "other way to shrink an MLA cache: a rank stores context/N of every "
        "request rather than all of it, so the replica holds N times as many "
        "tokens. Unlike --attention-dp-size it shrinks a single request's "
        "footprint, so it raises the concurrency ceiling even at batch 1.",
    )
    # ---- Feature A: prefill/decode disaggregation ----
    dis = parser.add_argument_group("inference disaggregation (feature A)")
    dis.add_argument(
        "--disaggregate",
        action="store_true",
        help="Enable prefill/decode disaggregation (separate worker pools).",
    )
    dis.add_argument(
        "--prefill-tp", type=int, default=None, help="Prefill-pool tensor parallelism."
    )
    dis.add_argument(
        "--prefill-pp", type=int, default=None, help="Prefill-pool pipeline parallelism."
    )
    dis.add_argument(
        "--prefill-ep", type=int, default=None, help="Prefill-pool expert parallelism."
    )
    dis.add_argument("--decode-tp", type=int, default=None, help="Decode-pool tensor parallelism.")
    dis.add_argument(
        "--decode-pp", type=int, default=None, help="Decode-pool pipeline parallelism."
    )
    dis.add_argument("--decode-ep", type=int, default=None, help="Decode-pool expert parallelism.")
    dis.add_argument(
        "--prefill-attention-dp",
        type=int,
        default=None,
        help="Prefill-pool attention-DP degree, overriding --attention-dp-size for "
        "that pool. Must divide --prefill-tp.",
    )
    dis.add_argument(
        "--decode-attention-dp",
        type=int,
        default=None,
        help="Decode-pool attention-DP degree, overriding --attention-dp-size for "
        "that pool. Must divide --decode-tp. Deployments commonly run DP attention "
        "on one pool only, which a single global degree cannot express.",
    )
    dis.add_argument(
        "--prefill-replicas", type=int, default=None, help="Number of prefill-pool replicas."
    )
    dis.add_argument(
        "--decode-replicas", type=int, default=None, help="Number of decode-pool replicas."
    )
    dis.add_argument(
        "--prefill-max-running",
        type=int,
        default=None,
        help="Running-request cap per prefill replica (default: --max-num-seqs).",
    )
    dis.add_argument(
        "--decode-max-running",
        type=int,
        default=None,
        help="Running-request cap per decode replica (default: --max-num-seqs).",
    )
    dis.add_argument(
        "--kv-transfer-bw-gbps",
        type=float,
        default=None,
        help="KV-cache transfer bandwidth GB/s (default: inter-node pod BW).",
    )
    dis.add_argument(
        "--kv-transfer-latency-us",
        type=float,
        default=None,
        help="Fixed KV-cache transfer latency overhead (us).",
    )
    dis.add_argument(
        "--transfer-backend",
        type=str,
        default=None,
        choices=["nixl", "mooncake", "mori"],
        help="KV-transfer engine preset (sets link BW + latency unless overridden "
        "by --kv-transfer-bw-gbps / --kv-transfer-latency-us).",
    )
    # ---- Serving / continuous-batching dynamics ----
    serv = parser.add_argument_group("inference serving dynamics")
    serv.add_argument(
        "--gpu-cost-per-hour",
        type=float,
        default=None,
        help="Price of one GPU-hour. Given it, the report prices the projected "
        "throughput as cost per million tokens -- the unit a serving budget is "
        "quoted in. Costs the whole replica, so a recipe that needs more GPUs "
        "for the same tokens is charged for them.",
    )
    serv.add_argument(
        "--serving-model",
        type=str,
        default=None,
        choices=["continuous", "static"],
        help=(
            "Decode latency model: 'continuous' (continuous batching with mixed "
            "prefill+decode steps → models TPOT pollution; default) or 'static' "
            "(idealized pure-decode batch; prefill charged once as TTFT)."
        ),
    )
    serv.add_argument(
        "--decode-step-overhead-us",
        type=float,
        default=None,
        help="Fixed per-decode-step host/launch overhead (us). CUDA graphs reduce this. Default 0.",
    )
    serv.add_argument(
        "--kernel-launch-latency-us",
        type=float,
        default=None,
        help="Per-kernel launch latency (us) for the small-tensor launch-bound "
        "decode floor in pure-simulate mode: step = max(step, n_kernels*lat). "
        "Disabled by CUDA-graph capture. Default 0 (off).",
    )
    serv.add_argument(
        "--kernels-per-layer",
        type=int,
        default=None,
        help="Representative kernel launches per transformer layer, used only "
        "by the launch-latency floor. Default 12.",
    )
    serv.add_argument(
        "--decode-kernel-occupancy-us",
        type=float,
        default=None,
        help="Per-kernel GPU occupancy (us): the minimum time a kernel holds "
        "the device regardless of how little data it touches. Added to the "
        "decode step (not a max) and not cancelled by CUDA-graph capture, "
        "which removes host dispatch but not kernel execution. Default 4.35 "
        "from the MI355X TP ladder; 0 disables.",
    )
    serv.add_argument(
        "--anchor-store",
        type=str,
        default=None,
        metavar="DIR",
        help="Directory of warmup measurements to reuse. When set and no "
        "explicit --load-benchmark is given, the closest anchor measured in the "
        "same regime (model, dtypes, attention backend, cudagraph, speculation) "
        "calibrates this projection. An anchor from a different regime is "
        "reported and NOT used, because it describes different kernels. "
        "Defaults to $INFERASIM_ANCHOR_STORE.",
    )
    serv.add_argument(
        "--moe-router-coverage",
        type=str,
        default=None,
        metavar="FILE",
        help="JSON of measured router coverage: how many distinct experts the "
        "real router reaches per step, as a fraction of what independent "
        "per-token routing predicts, keyed by batch. Produced from the "
        "checkpoint's router weights (CPU only). Without it, routing is "
        "assumed independent, which over-counts experts at mid batch.",
    )
    serv.add_argument(
        "--moe-rank-load",
        type=str,
        default=None,
        metavar="FILE",
        help="JSON of the busiest expert-parallel rank's load over the mean, "
        "{ep: [[tokens, rows, experts], ...]}, replayed from the checkpoint's "
        "recorded routing. Without it, a top-k router is sampled.",
    )
    serv.add_argument(
        "--moe-routing-skew",
        type=float,
        default=None,
        help="Zipf exponent of the MoE router's popularity law (0 = uniform). "
        "Sets how many distinct experts a decode step touches, which is what a "
        "weight-bandwidth-bound MoE step costs. Converts from a measured "
        "max/mean expert load by I(s) = N / H_N(s).",
    )
    serv.add_argument(
        "--detokenize-overhead-us",
        type=float,
        default=None,
        help="Per-output-token host detokenization + streaming cost (us/token). Added to "
        "ITL/TPOT and end-to-end latency only (not throughput), matching client-side "
        "serving-harness ITL. Default 0.",
    )
    serv.add_argument(
        "--tokenize-overhead-us",
        type=float,
        default=None,
        help="Per-prompt-token host tokenization cost (us/token). The prompt is sent as text "
        "and tokenized server-side after the TTFT clock starts, so it is added to TTFT "
        "and end-to-end latency only (not throughput). Default 0.",
    )
    serv.add_argument(
        "--request-overhead-ms",
        type=float,
        default=None,
        help="Fixed per-request host cost on the TTFT path (ms): accept, parse, admit, "
        "prefix-cache lookup, KV allocation, stream open. Constant in prompt length, "
        "which is how it is measured -- difference TTFT across two prompt lengths at "
        "concurrency 1 and take the intercept. Added to TTFT and end-to-end latency "
        "only (not throughput). A property of the serving stack, so it has no default "
        "worth guessing. Default 0.",
    )
    serv.add_argument(
        "--uncached-prompt-latency-us",
        type=float,
        default=None,
        help="TTFT latency per prompt token the prefix cache did not serve (us/token). "
        "Added to TTFT and end-to-end latency only (not throughput). Default 0.",
    )
    serv.add_argument(
        "--uncached-prompt-latency-max-tokens",
        type=int,
        default=None,
        help="Uncached tokens past which --uncached-prompt-latency-us stops growing. "
        "Default 0 (no cap).",
    )
    serv.add_argument(
        "--prefill-rate-us-per-token",
        type=float,
        default=None,
        help="Measured prefill rate (us of TTFT per prompt token): the per-token slope from "
        "the same concurrency-1 differencing that yields --request-overhead-ms. Used as a "
        "level anchor, not as the cost -- the projector takes its own slope over the same "
        "two lengths and scales modelled prefill compute by the ratio, so prefill keeps "
        "its superlinear growth in context. Requires --prefill-rate-lo-tokens and "
        "--prefill-rate-hi-tokens. Ignored in benchmark mode, which already prices "
        "prefill from measured kernels. Default 0 (unanchored).",
    )
    serv.add_argument(
        "--prefill-rate-lo-tokens",
        type=int,
        default=None,
        help="Shorter of the two prompt lengths --prefill-rate-us-per-token was fit over. "
        "A rate is meaningless without the span it was measured on.",
    )
    serv.add_argument(
        "--prefill-rate-hi-tokens",
        type=int,
        default=None,
        help="Longer of the two prompt lengths --prefill-rate-us-per-token was fit over.",
    )
    serv.add_argument(
        "--stream-interval",
        type=int,
        default=None,
        help="Output tokens buffered per streaming flush (vLLM/SGLang --stream-interval). "
        "The client's first token, and so the measured TTFT, arrives only after this "
        "many tokens are decoded. Default 1 (flush every token).",
    )
    serv.add_argument(
        "--decode-admission-steps",
        type=int,
        default=None,
        help="Decode-scheduler admission granularity in decode steps, i.e. "
        "--num-continuous-decode-steps x --scheduler-recv-interval. A prefilled request "
        "waits part of this window before joining the running batch; TTFT-only. Default 0.",
    )
    serv.add_argument(
        "--mixed-batch-penalty",
        type=float,
        default=None,
        help="Extra cost fraction for mixed prefill+decode steps (PIECEWISE vs FULL CUDA graph). Default 0.",
    )
    serv.add_argument(
        "--cudagraph-mode",
        type=str,
        default=None,
        choices=["none", "piecewise", "full"],
        help="CUDA-graph capture preset: 'none' (eager), 'piecewise', or 'full'. "
        "Sets per-step overhead + mixed-batch penalty unless those are given explicitly.",
    )
    serv.add_argument(
        "--max-num-batched-tokens",
        type=int,
        default=None,
        help="Scheduler per-step token budget (vLLM --max-num-batched-tokens). Caps "
        "prefill-chunk + concurrent-decode tokens per step; oversized steps split, "
        "raising TPOT. Default: 0 (unlimited).",
    )
    serv.add_argument(
        "--max-num-seqs",
        type=int,
        default=None,
        help="Engine cap on running sequences (vLLM --max-num-seqs, SGLang "
        "--max-running-requests). Clients beyond it queue at the server. "
        "Default: 0 (bounded by client concurrency only).",
    )
    # ---- Offered load / request rate (open-loop arrivals) ----
    serv.add_argument(
        "--request-rate",
        type=float,
        default=None,
        help="Offered load in requests/sec (open-loop). Adds a first-order queueing "
        "delay to TTFT as load approaches the engine's max sustainable rate. "
        "Default: 0 (closed-loop, no queue).",
    )
    serv.add_argument(
        "--arrival-model",
        type=str,
        default=None,
        choices=["closed", "none", "poisson", "deterministic"],
        help="Arrival process for --request-rate. 'closed'/'none' (default): no "
        "queue, steady-state only. 'poisson'/'deterministic': run the "
        "discrete-event simulator (DES) for TTFT/TPOT/ITL percentiles. Both also "
        "still report the analytical M/M/1 / D/M/1 mean.",
    )
    serv.add_argument(
        "--des-closed-loop",
        action="store_true",
        default=False,
        help="DES: simulate a fixed-concurrency benchmark harness instead of an "
        "arrival stream -- --max-concurrency clients each resubmit the moment "
        "their request completes. Makes TTFT an observed timestamp difference, "
        "so a prefill chunk is charged the scheduler step it actually rides "
        "(dilated by the resident decode batch) rather than standalone prefill "
        "time. Set --chunked-prefill-size to the engine's per-request per-step "
        "prefill allowance; without it a prompt prefills in one step.",
    )
    serv.add_argument(
        "--des-exclusive-prefill",
        action="store_true",
        default=False,
        help="DES: the engine does not co-schedule prefill with decode -- a "
        "prefill batch carries one request and the whole token budget while "
        "the resident decodes wait. Read this off the engine, not off the "
        "errors: Atom logs 'Scheduled prefill batch: 1 reqs, 8192 new tokens' "
        "against a 8192-token budget, vLLM's chunked prefill instead packs a "
        "chunk in beside the decodes. It is not a small distinction. Blocking "
        "decode re-synchronises a closed-loop population every round -- no one "
        "advances while a request prefills, so all C clients start decoding "
        "together, finish together and resubmit together -- which turns the "
        "prefill queue from an opening transient into a standing one and makes "
        "measured TTFT uniform on [0, 2*median]. Left off against such an "
        "engine, TTFT reads an order of magnitude early at high concurrency.",
    )
    serv.add_argument(
        "--des-num-requests",
        type=int,
        default=400,
        help="DES: number of requests to simulate at the configured offered load "
        "(--arrival-model poisson/deterministic) or, with --des-closed-loop, in "
        "total across all clients. Default: 400.",
    )
    serv.add_argument(
        "--des-max-prefill-seqs",
        "--des-new-seqs-per-step",
        dest="des_new_seqs_per_step",
        type=int,
        default=0,
        help="DES: cap on how many *new* sequences may enter one prefill step "
        "(0 = only the token budget limits admission). The per-step token "
        "budget is a ceiling on a prefill batch, not a target -- admitting a "
        "request reserves KV for its whole prompt, so engines stay well under "
        "it. Measured over 5.4M prefill batches from vLLM and SGLang on "
        "MI355X, the median batch takes 1 new sequence with an empty queue and "
        "2 with a backlog, against the 16 a 16384-token budget would hold at "
        "ISL 1024. Leaving this unset makes a wave of C requests clear in "
        "C*ISL/budget steps at the efficient large-batch token rate, which "
        "reads TTFT an order of magnitude early at high concurrency.",
    )
    serv.add_argument(
        "--des-warmup-frac",
        type=float,
        default=0.1,
        help="DES: fraction of requests, in completion order, to exclude from "
        "the reported latency distribution. This is a reporting convention, not "
        "a property of the engine: it has to match what the harness being "
        "compared against averaged over. Serving harnesses generally send a "
        "separate warmup burst and then report over every measured request, in "
        "which case this is 0 -- and it is not a small correction, because a "
        "fixed-concurrency run is only a few waves long and the opening burst "
        "carries the highest TTFT of any request in it. Default: 0.1.",
    )
    serv.add_argument(
        "--des-client-think-ms",
        type=float,
        default=0.0,
        help="DES: how long a closed-loop client waits after its last token "
        "before issuing its next request. Zero re-issues immediately, which "
        "is a load generator saturating the server and not what an agentic "
        "harness does: a turn ends, the agent runs a tool, and the next turn "
        "is sent when that returns. It is a property of the workload, like "
        "the prompt lengths and the prefix reuse, and leaving it out does not "
        "leave the replay neutral -- it holds every client permanently "
        "resident. On the AgentX ladders the hardware's clients are idle for "
        "50-74% of each turn's cycle below saturation and ~0% above it, so "
        "omitting it overstates throughput several-fold at the low rungs and "
        "not at all at the high ones, which bends the curve rather than "
        "shifting it. A Mooncake trace's per-request ``think_ms`` overrides "
        "it request by request.",
    )
    serv.add_argument(
        "--des-client-idle-cap-ms",
        type=float,
        default=0.0,
        help="DES: longest the engine may sit with no request in flight before "
        "pending client timers are pulled forward (0 = no cap). Mirrors a "
        "replay harness's system-idle guard (AIPerf AgentX: 10 s), which "
        "shortens a single client's idle time far below the trace's gaps.",
    )
    serv.add_argument(
        "--des-admit-backlog-only",
        action="store_true",
        help="DES: measure the longest-prefix admission window against the "
        "backlog rather than the client count, so that below what the KV pool "
        "holds -- where nothing is queued and there is no choice for a policy "
        "to make -- admission is the order the lanes arrived in. This is the "
        "correct account of what a scheduler can reorder, and it is the band "
        "where measured reuse collapses (kimik3 at C=14 thrashed to 0.67 "
        "against 0.93 modelled), but on the AgentX corpus it improves ITL "
        "ordering by one model-engine pair and costs one on throughput, so it "
        "is off by default.",
    )
    serv.add_argument(
        "--des-warmup-requests",
        type=int,
        default=0,
        help="DES: exclude this many requests, in the order the clients issued "
        "them, from the reported latency distribution. Prefer this to "
        "--des-warmup-frac for a closed loop: all C clients fire at once, so "
        "the first C requests queue against each other and wait far longer "
        "than anything after them, and dropping the earliest *completions* "
        "keeps every one of them -- a request that waited 40s for a slot is "
        "among the last to finish. The harness excludes the same transient by "
        "advancing each lane AIPERF_WARMUP_REQUESTS_PER_LANE requests and "
        "draining before it starts profiling, so the matching value is that "
        "many per client. Default: 0 (use --des-warmup-frac).",
    )
    serv.add_argument(
        "--des-duration-s",
        type=float,
        default=0.0,
        help="DES: stop the run after this many seconds of simulated time and "
        "report over whatever completed, instead of running to "
        "--des-num-requests. This is how a fixed-concurrency harness is "
        "actually bounded, and under a closed loop the two are not "
        "interchangeable: a request budget divided among C lanes fixes how "
        "far each lane walks into its conversation, and an agentic turn's "
        "prompt grows with its position, so a budget-bounded run offers "
        "different prompt lengths at each concurrency than the measured run "
        "it is compared against. Default: 0 (run to the request count).",
    )
    serv.add_argument(
        "--des-seed",
        type=int,
        default=0,
        help="DES: RNG seed for arrival/acceptance sampling (reproducible). Default: 0.",
    )
    serv.add_argument(
        "--des-sweep",
        action="store_true",
        default=False,
        help="DES: also sweep offered load (fractions of max-sustainable rate) and "
        "emit a throughput-vs-latency curve (p50/p99 TTFT & TPOT per load).",
    )
    serv.add_argument(
        "--des-burstiness",
        type=float,
        default=None,
        help="DES: gamma-arrival shape for --arrival-model poisson. 1.0 = Poisson "
        "(default), <1 = burstier, >1 = smoother/more regular.",
    )
    serv.add_argument(
        "--des-range-ratio",
        type=float,
        default=None,
        help="DES: per-request length heterogeneity. Actual ISL/OSL sampled "
        "uniformly from [ratio*len, len]. 1.0 = homogeneous (default), e.g. 0.5 "
        "= lengths vary down to half of --input-len/--output-len.",
    )
    serv.add_argument(
        "--des-kv-cache-tokens",
        type=int,
        default=None,
        help="DES: total KV token-slot pool. Admission reserves full ISL+OSL per "
        "request (head-of-line blocks on shortage). Default: 0 (unlimited; "
        "concurrency-bound only).",
    )
    serv.add_argument(
        "--des-workload-file",
        type=str,
        default=None,
        help="DES: replay a workload from JSON (list of dicts) or CSV with columns "
        "arrival(ms),isl,osl instead of synthetic sampling. Enables the DES even "
        "without --request-rate.",
    )
    serv.add_argument(
        "--des-dump-steps",
        type=str,
        default=None,
        help="DES: write per-step batch-composition records (query/KV shapes per "
        "request per step) + packing summary to this JSON path.",
    )
    # ---- DES multi-instance routing + shared prefix pool ----
    serv.add_argument(
        "--des-instances",
        type=int,
        default=None,
        help="DES: number of engine replicas behind a router (data-parallel "
        "copies of this recipe). >1 enables the multi-instance fleet model. "
        "Default: 1 (single engine).",
    )
    serv.add_argument(
        "--des-routing",
        type=str,
        default=None,
        choices=["round_robin", "random", "prefix_aware", "kv"],
        help="DES: request routing policy across instances. 'kv' is the serving "
        "router's KV-aware policy, trading cache overlap against load by the same "
        "cost function (see --des-overlap-weight); 'prefix_aware' consistently "
        "hashes the leading block so same-prefix requests co-locate; "
        "'round_robin'/'random' ignore locality (each instance re-warms). "
        "Default: round_robin.",
    )
    serv.add_argument(
        "--des-overlap-weight",
        type=float,
        default=None,
        help="DES: how much a cached KV block is worth against a block of load "
        "in 'kv' routing, matching the serving router's overlap weight. 0 routes "
        "purely by load; high values pin prefixes to whichever instance holds "
        "them. Default: 1.0.",
    )
    serv.add_argument(
        "--des-num-prefixes",
        type=int,
        default=None,
        help="DES: number of distinct shared prefixes in the workload (e.g. "
        "system-prompt / template variants). Requests sharing a prefix reuse its "
        "KV on a cache hit. 0 = no shared prefixes (every request unique).",
    )
    serv.add_argument(
        "--des-prefix-len",
        type=int,
        default=None,
        help="DES: shared-prefix length in tokens (the cached span on a hit). "
        "0 (with --des-num-prefixes>0) defaults to half the prompt.",
    )
    serv.add_argument(
        "--des-prefix-zipf",
        type=float,
        default=None,
        help="DES: prefix popularity skew. 0 = uniform; >0 = power-law (a few hot "
        "prefixes dominate, as with shared system prompts). Default: uniform.",
    )
    serv.add_argument(
        "--des-cache-slots",
        type=int,
        default=None,
        help="DES: legacy alias for --des-kv-blocks (per-instance block-cache "
        "capacity). 0 = unbounded within the run. Default: 0.",
    )
    serv.add_argument(
        "--des-block-size",
        type=int,
        default=None,
        help="DES: KV paged-block size in tokens for the content-addressed prefix "
        "cache. A cache hit reuses whole leading blocks. Default: 512 (Mooncake "
        "convention).",
    )
    serv.add_argument(
        "--des-kv-blocks",
        type=int,
        default=None,
        help="DES: per-instance KV block-cache capacity (blocks kept resident, "
        "LRU-evicted under pressure). 0 = unbounded within the run. Default: 0.",
    )
    serv.add_argument(
        "--des-whole-context-residency",
        action="store_true",
        help="DES: charge a running request the whole context it attends to, "
        "not just the part of it that was not already cached. The discount is "
        "an account of one physical copy, and it is only that where the "
        "sharers are running at the same time. Under a closed loop on "
        "conversational traffic they are not: each client has one turn in "
        "flight, reuse is a conversation hitting its own previous turn, and "
        "the turns running together belong to different conversations whose "
        "histories do not overlap. Discounted anyway, a pool holding five of "
        "these conversations reports room for hundreds, never fills, and so "
        "never shows reuse falling away or the queue that follows it.",
    )
    serv.add_argument(
        "--des-cache-shares-pool",
        action="store_true",
        help="DES: size the prefix cache to what the running requests leave "
        "free, instead of to the whole pool. A request is already not charged "
        "for the blocks it hit on, because something else is holding them; "
        "that something is this cache, and giving it the pool as well books "
        "the same memory twice. Where the pool is roomy the correction is "
        "nothing, and where it is not it is the whole behaviour: a pool with "
        "space for five of these conversations cannot also hold their history, "
        "so reuse falls away as concurrency climbs and TTFT leaves the scale "
        "the low rungs were on. Double-booked, the replay reports reuse near "
        "its ceiling and a flat TTFT straight through that.",
    )
    serv.add_argument(
        "--des-mooncake-trace",
        type=str,
        default=None,
        help="DES: replay a Mooncake-format trace (JSONL/JSON with timestamp, "
        "input_length, output_length, hash_ids). The hash_ids drive real "
        "content-addressed prefix-cache matching. Enables the DES without "
        "--request-rate; combine with --des-instances/--des-routing to study a "
        "fleet.",
    )
    serv.add_argument(
        "--des-gemm-shapes",
        type=str,
        default=None,
        metavar="PATH",
        help="DES: write every linear-layer GEMM shape the replay runs, with how "
        "many times it runs, to PATH (.csv, or .json for a per-weight summary of "
        "the M distribution as well). M is each executed step's token count, so "
        "this is the shape mix a trace actually produces under continuous "
        "batching. Shapes follow the engine's weight sharding and fusion on one "
        "TP rank; a per-shape time estimate is included when the Origami GEMM "
        "simulator is installed.",
    )
    # ---- Kernel backend + fused ops + sparse attention + expert precision ----
    kern = parser.add_argument_group("inference kernel backend & ops")
    kern.add_argument(
        "--attention-backend",
        type=str,
        default=None,
        choices=["aiter", "triton", "ck", "hip"],
        help="Attention kernel library (ROCm). Representative compute multiplier "
        "vs the Triton baseline. Default: engine default (1.0).",
    )
    kern.add_argument(
        "--serving-engine",
        type=str,
        default=None,
        help="Engine this projection is about (vllm, sglang, atom, or a build "
        "such as mori-sglang). Simulate mode is unaffected -- it is analytical "
        "and returns the same number whichever engine is named. This is a "
        "regime axis, so it decides which measured anchor benchmark mode may "
        "calibrate from: an anchor harvested on another engine is refused "
        "rather than substituted. Default: unset (matches as before).",
    )
    kern.add_argument(
        "--sparse-attention-topk",
        type=int,
        default=None,
        help="Native sparse attention (DeepSeek V3.2/V4 NSA) top-k KV tokens per "
        "query. Attention scales toward topk/context for long contexts. "
        "Default: 0 (dense).",
    )
    kern.add_argument(
        "--sparse-indexer-cost-scale",
        type=float,
        default=None,
        help="What the sparse indexer's top-k selection costs on this stack "
        "relative to a fused kernel. The arithmetic is the model's, the kernel "
        "is the serving stack's: the same selection runs fused through aiter "
        "on gfx950 and unfused through Torch on gfx942. 1.0 prices the fused "
        "path; raise it to charge a stack serving without one. Only reaches "
        "models priced from an indexer geometry (GLM-5.2, MiniMax-M3), not "
        "ones carrying a per-layer compression schedule. Default: 1.0.",
    )
    kern.add_argument(
        "--sliding-window",
        type=int,
        default=None,
        help="Sliding-window (local) attention size in KV tokens each query "
        "attends to (0 = force full attention). Default: follow the model's "
        "sink_sliding_window. Bounds decode attention compute and KV-cache "
        "footprint at long context.",
    )
    kern.add_argument(
        "--sliding-window-layer-fraction",
        type=float,
        default=None,
        help="Fraction of attention layers that are windowed for models that "
        "interleave local/global layers. Default: 0.5 when the model is "
        "even-layers-only, else 1.0 (every layer windowed).",
    )
    kern.add_argument(
        "--moe-expert-dtype",
        type=str,
        default=None,
        choices=["bf16", "fp8", "mxfp4"],
        help="Expert grouped-GEMM compute precision (separate from --weight-dtype). "
        "Models the expert-MLP speedup of low-precision expert kernels.",
    )
    kern.add_argument(
        "--linear-weight-dtype",
        type=str,
        default=None,
        choices=["bf16", "fp8", "mxfp4", "fp4"],
        help="Precision of the non-expert linears -- attention's projections and "
        "the dense MLP. Separate from --weight-dtype, which sizes the whole "
        "checkpoint, and from --moe-expert-dtype: quantized checkpoints differ on "
        "this. gpt-oss ships mxfp4 experts behind bf16 attention, while an NVFP4 "
        "checkpoint quantizes the attention projections too. Defaults to the "
        "model's own fp8 flag.",
    )
    kern.add_argument(
        "--fused-kernels",
        action="store_true",
        default=False,
        help="Fused elementwise kernels (RMSNorm / RoPE / quant / KV-store+quant) "
        "that cut per-decode-step launch overhead.",
    )
    kern.add_argument(
        "--speculative-draft-cost-factor",
        type=float,
        default=None,
        help="Flat draft cost per proposed draft token, as a fraction of one "
        "target decode step. Used with --speculative-draft-cost-model flat, "
        "or when the drafter cannot be priced from its layers. Default: the "
        "method's flat guess (speculative.FLAT_DRAFT_COST).",
    )
    parser.add_argument(
        "--speculative-draft-cost-model",
        default=None,
        choices=["analytic", "flat"],
        help="How the draft is priced: analytic (default) as the drafter's own "
        "forward, or flat from --speculative-draft-cost-factor.",
    )
    parser.add_argument(
        "--inference-bench-layers",
        type=int,
        default=None,
        help=(
            "Benchmark mode: number of same-type transformer layers to build and "
            "time as a chained stack per phase (per-layer time = stack time / N). "
            "Larger N averages out per-layer jitter and captures inter-layer "
            "effects. Default: 4."
        ),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="infera.projection",
        description="Infera inference/serving projection (TTFT, ITL, throughput, KV cache).",
    )
    sub = parser.add_subparsers(dest="suite", required=True)

    inference = sub.add_parser(
        "inference",
        help="Inference / serving projection (analytical or anchor-calibrated).",
    )
    add_pretrain_parser(inference)
    _add_topology_args(inference)
    _add_performance_args(inference)
    _add_save_benchmark_arg(inference)
    _add_load_benchmark_arg(inference, include_compute_baseline_alias=False)
    _add_inference_args(inference)
    # No profiling_mode override here: the flag's own default ("benchmark")
    # stands. Calibrated latency is the only kind with an established
    # correlation against real serving, so the uncalibrated analytical path is
    # opt-in rather than what you get for saying nothing. A matching anchor in
    # --anchor-store satisfies the default without touching a GPU.
    inference.set_defaults(func="inference")

    # anchor-harvest is a thin shim over the vLLM harness
    # Registered only so it appears in `--help`. Its flags are parsed by the
    # harness itself (see the dispatch in main()), so none are declared here.
    sub.add_parser(
        "anchor",
        help="Harvest a GPU-calibrated anchor via the vLLM benchmark harness "
        "(`inferasim anchor --help` lists its flags).",
        add_help=False,
    )
    sub.add_parser(
        "pareto",
        help="Throughput-vs-interactivity Pareto frontier for one workload across "
        "models, engines, precisions, parallelism and concurrency "
        "(`inferasim pareto --help` lists its flags).",
        add_help=False,
    )
    return parser


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)

    # `anchor` forwards its flags verbatim to the vLLM harness, and several of
    # them (--model, --input-len, --tp) also exist on the projection parser.
    # Split it off before argparse sees it: sharing the tokens leaves the
    # harness with an argv the two parsers have already torn in half.
    if argv and argv[0] == "anchor":
        from infera.projection.core.projection.inference_projection import (
            benchmark_vllm,
        )

        return benchmark_vllm.main(argv[1:])
    if argv and argv[0] == "pareto":
        from infera.projection.core.projection.inference_projection import pareto

        return pareto.main(argv[1:])

    parser = build_parser()
    args, overrides = parser.parse_known_args(argv)

    # inference projection (simulate by default; --load-benchmark uses an anchor)
    launch_projection_from_cli(args, overrides)


if __name__ == "__main__":
    main()
