"""Evaluator — runs `projection memory` + `projection performance --profiling-mode
{simulate,benchmark}` against a per-trial workload YAML and parses the stdout
for the metrics the agent needs.

The interface is uniform regardless of mode:

    EvalResult = {
      legal: bool, reason: str|None,
      memory_per_gpu_gb: float|None,
      param_optimizer_gb: float|None,
      activation_gb: float|None,
      iteration_ms: float|None,
      tokens_per_s_per_gpu: float|None,
      source: "memory_only"|"simulate"|"benchmark",
      stdout_tail: str, returncode: int,
      duration_s: float,
      cmd: list[str],
    }
"""

from __future__ import annotations

import os
import re
import subprocess
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .config import AgentConfig
from .legality import TrialConfig, derived_dp, validate
from .workload import ArchitectureRecord

# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass
class EvalResult:
    legal: bool = True
    reason: str | None = None
    memory_per_gpu_gb: float | None = None
    memory_per_gpu_gb_adjusted: float | None = None
    memory_per_gpu_gb_upper: float | None = None  # bench-mode 5%-margin upper bound
    memory_source: str | None = None  # "benchmark_point" | "simulate" | …
    memory_warning: str | None = None
    param_optimizer_gb: float | None = None
    activation_gb: float | None = None
    iteration_ms: float | None = None
    tokens_per_s_per_gpu: float | None = None
    tflops_per_s_per_gpu: float | None = None
    mfu: float | None = None
    # ---- inference / serving metrics (mode == "inference") ----
    ttft_ms: float | None = None
    itl_ms: float | None = None
    request_latency_ms: float | None = None
    decode_throughput_tps: float | None = None
    decode_throughput_tps_per_gpu: float | None = None
    prefill_throughput_tps: float | None = None
    kv_cache_gb: float | None = None
    max_concurrent_sequences: int | None = None
    # Serving metrics the projector reports that the tuner could not previously
    # rank on, including the total-tokens-per-GPU figure InferenceX leads with.
    total_throughput_tps_per_gpu: float | None = None
    total_throughput_tps: float | None = None
    prefill_throughput_tps_per_gpu: float | None = None
    interactivity_tok_s_per_user: float | None = None
    per_request_decode_tps: float | None = None
    decode_step_ms_pure: float | None = None
    decode_step_ms_mixed: float | None = None
    weights_gb: float | None = None
    prefill_comm_ms: float | None = None
    decode_comm_ms: float | None = None
    # Parsed all along but never declared, so ``asdict`` dropped them and any
    # objective naming one scored None and looked like an infeasible search.
    max_sustainable_concurrency: int | None = None
    concurrency_used: int | None = None
    mixed_step_fraction_pct: float | None = None
    tpot_pollution_pct: float | None = None
    replica_gpus: int | None = None
    source: str = "memory_only"
    stdout_tail: str = ""
    returncode: int = 0
    duration_s: float = 0.0
    cmd: list[str] = field(default_factory=list)
    config: dict = field(default_factory=dict)
    derived_dp: int = 0

    def as_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------------------
# Per-trial YAML generation
# ---------------------------------------------------------------------------


def _build_pipeline_layout(num_layers: int, pp: int, vpp: int) -> str | None:
    """Build a ``pipeline_model_parallel_layout`` string for the
    given (pp, vpp) split of ``num_layers``.

    Output format matches the published DeepSeek V3 reference:
    ``Et*N0|t*N1|...|t*Nlast,L`` where:
      * The first stage carries the embedding (``E`` prefix).
      * The last stage carries the output / loss head (``,L`` suffix).
      * ``N0..Nlast`` sums to ``num_layers`` and lengths are as balanced as
        possible, with extras allocated to *middle* stages so the first and
        last stages (which already host embedding + output/loss) stay light.

    Returns None if PP*VPP > num_layers (would force empty stages).
    """
    if num_layers <= 0 or pp <= 0 or vpp <= 0:
        return None
    n_stages = pp * vpp
    if n_stages > num_layers:
        return None

    base = num_layers // n_stages
    extra = num_layers - base * n_stages
    counts = [base] * n_stages

    # Distribute extras to *middle* stages first (skipping stage 0 and the
    # last stage), wrapping around if there's more extra than middles. This
    # mirrors the load-balancing pattern the published DSv3 reference uses
    # (Et*3 | t*4 × 13 | t*3 | t*3,L for 61 layers / 16 stages).
    if n_stages >= 3:
        middles = list(range(1, n_stages - 1))
    else:
        middles = list(range(n_stages))
    for i in range(extra):
        counts[middles[i % len(middles)]] += 1

    parts: list[str] = []
    for i, c in enumerate(counts):
        prefix = "E" if i == 0 else ""
        parts.append(f"{prefix}t*{c}")
    return "|".join(parts) + ",L"


def write_trial_yaml(arch: ArchitectureRecord, cfg: TrialConfig, out_dir: Path, tag: str) -> Path:
    """Write a copy of the workload YAML with cfg's overrides applied.

    Knobs are applied in roughly the priority order from the Projection
    skill's Optimization Exploration Guidelines (Step 1 → Step 6):
      1. Parallelism (TP/PP/EP/CP/VPP)
      2. Pipeline schedule (zero-bubble + algorithm)
      3. MoE comm (DeepEP, SyncFree)
      4. Precision (FP8)
      5. Memory (recompute, loss-fusion, FSDP2/distributed-optimizer)
      6. Batch (MBS, GBS, overlap-grad-reduce)

    We deliberately do NOT mutate the original YAML — we copy & overlay so
    multiple trials can run concurrently and so the user's source is
    untouched.
    """
    src = Path(arch.workload_path)
    raw = yaml.safe_load(src.read_text())

    pre_trainer = (raw.get("modules") or {}).get("pre_trainer") or {}
    overrides = dict(pre_trainer.get("overrides") or {})

    # 1) parallelism ------------------------------------------------------
    workload_pp = arch.pipeline_model_parallel_size or 1
    workload_vpp = arch.virtual_pipeline_model_parallel_size or 1
    overrides["tensor_model_parallel_size"] = cfg.tp
    overrides["pipeline_model_parallel_size"] = cfg.pp
    overrides["expert_model_parallel_size"] = cfg.ep
    overrides["context_parallel_size"] = cfg.cp
    if cfg.vpp is not None:
        # The projection reads ``virtual_pipeline_model_parallel_size``
        # (Megatron-LM core API), while the runtime trainer reads
        # ``num_virtual_stages_per_pipeline_rank`` (its own override).
        # Set both to keep them coherent across projection + benchmark.
        overrides["num_virtual_stages_per_pipeline_rank"] = cfg.vpp
        overrides["virtual_pipeline_model_parallel_size"] = cfg.vpp
    # When the trial overrides PP or VPP, the workload's published per-stage
    # layout no longer matches PP×VPP. For models with a *non-divisor* layer
    # count (DeepSeek V3 = 61, prime; Kimi-K2 patterns) we regenerate a
    # balanced layout for the new (PP, VPP) — distributing num_layers across
    # PP×VPP stages as evenly as possible, with extras going to *middle*
    # stages so the embedding (first stage) and output/loss (last stages)
    # stay light. Without this the agent could never reach the published
    # ``PP=8 / VPP=2`` reference for DSv3, which encodes 16 stages of 3-4
    # layers via ``Et*3|t*4|...|t*3|t*3,L'``.
    trial_vpp = cfg.vpp if cfg.vpp is not None else workload_vpp
    workload_layout = arch.pipeline_model_parallel_layout
    if cfg.pp != workload_pp or trial_vpp != workload_vpp:
        # Always remove the workload's stage-count helpers; they're tied to
        # the original PP and would conflict with the regenerated layout.
        for layout_key in (
            "decoder_first_pipeline_num_layers",
            "decoder_last_pipeline_num_layers",
            "num_layers_in_first_pipeline_stage",
            "num_layers_in_last_pipeline_stage",
        ):
            overrides.pop(layout_key, None)
            pre_trainer.pop(layout_key, None)

        if workload_layout and arch.num_layers:
            # Regenerate a layout for the new (PP, VPP).
            new_vpp = trial_vpp or 1
            new_layout = _build_pipeline_layout(arch.num_layers, cfg.pp, new_vpp)
            if new_layout is not None:
                overrides["pipeline_model_parallel_layout"] = new_layout
            else:
                # Trial is too sliced (PP*VPP > num_layers) — let validate()
                # have caught this; fall back to clearing the layout.
                overrides.pop("pipeline_model_parallel_layout", None)
                pre_trainer.pop("pipeline_model_parallel_layout", None)
        else:
            overrides.pop("pipeline_model_parallel_layout", None)
            pre_trainer.pop("pipeline_model_parallel_layout", None)

    # 2) pipeline schedule ------------------------------------------------
    if cfg.enable_zero_bubble is not None:
        overrides["enable_zero_bubble"] = cfg.enable_zero_bubble
    if cfg.pp_schedule and cfg.pp_schedule != "auto":
        from infera.projection.core.projection.config_validation import (
            PP_SCHEDULE_TO_RUNTIME_ALGORITHM,
        )

        overrides["pp_algorithm"] = PP_SCHEDULE_TO_RUNTIME_ALGORITHM.get(
            cfg.pp_schedule, cfg.pp_schedule
        )

    # 3) MoE communication (Tier-A — biggest single MoE win per skill) ----
    # Required-by-runtime couplings for the Primus Turbo MoE stack:
    #   * DeepEP / SyncFree stages 2-3 require ``moe_router_dtype=fp32`` —
    #     otherwise:
    #       AssertionError: DeepEP only supports float32 probs, please set
    #       `moe_router_dtype=fp32`
    #   * SyncFree stages 2-3 require ``moe_use_legacy_grouped_gemm=True`` —
    #     otherwise:
    #       ValueError: Sync-Free MoE stage 2 or 3 require PrimusTurboGroupedMLP,
    #       please set `moe_use_legacy_grouped_gemm=True`
    # We force these couplings here so the planner doesn't have to know about them.
    if cfg.use_turbo_deepep is not None:
        overrides["use_turbo_deepep"] = cfg.use_turbo_deepep
    if cfg.sync_free_stage is not None:
        overrides["sync_free_stage"] = cfg.sync_free_stage
    sync_free_high = cfg.sync_free_stage is not None and cfg.sync_free_stage >= 2
    deepep_active = bool(cfg.use_turbo_deepep) or sync_free_high
    if deepep_active:
        overrides["moe_router_dtype"] = "fp32"
    if sync_free_high:
        overrides["moe_use_legacy_grouped_gemm"] = True

    # 4) precision (Tier-A — ~2× compute for linear layers when "hybrid")  -
    if cfg.fp8 is not None:
        overrides["fp8"] = cfg.fp8

    # Multi-Latent-Attention models (DeepSeek V2/V3, Kimi-K2, Qwen-V2) auto-
    # enable ``use_turbo_parallel_linear`` inside the projection. Two
    # things go wrong on the v26.2 container ``primus_turbo==0.2.0``:
    #   * The default ``fp8_recipe: delayed`` is incompatible with that path
    #     (``primus/modules/trainer/megatron/utils.py:464`` asserts).
    #   * The dense FP8 GEMM op (``primus_turbo.pytorch.ops.gemm_fp8``) on
    #     this version raises ``ValueError: Unsupported FP8 format: HYBRID``
    #     for ``fp8: hybrid`` (a common DSv3 / Kimi-K2 configuration).
    # We disable the MLA-specific turbo dense linear path while keeping
    # ``use_turbo_grouped_mlp`` (which DOES support HYBRID) so MoE grouped
    # GEMMs still benefit from FP8. This costs a few % of dense-linear FP8
    # speedup vs. a fully turbo'd path, but lets the agent actually
    # benchmark MLA + FP8 workloads on v26.2.
    fp8_active = (overrides.get("fp8") or arch.fp8) is not None
    if fp8_active and getattr(arch, "attention_type", "standard") == "mla":
        overrides.setdefault("fp8_recipe", "tensorwise")
        # v26.2's ``PrimusTurboGroupedMLP.forward`` references
        # ``self.bias_act_func`` which is set by the parent class only when
        # an older Megatron-LM lifecycle is honored. On v26.2 it is missing,
        # so route through the fused activation+probs kernel instead — which
        # is the recommended path anyway for SiLU/GeLU GLU models (= every
        # model we tune here).
        overrides.setdefault("use_turbo_fused_act_with_probs", True)

    # 5) memory levers ----------------------------------------------------
    if cfg.recompute_granularity in ("selective", "full"):
        overrides["recompute_granularity"] = cfg.recompute_granularity
        overrides["recompute_method"] = overrides.get("recompute_method", "block")
        overrides["recompute_num_layers"] = cfg.recompute_num_layers or 1
        # Some workload yamls (DeepSeek V3) ship a more granular
        # ``recompute_layer_ids`` (a comma-separated string of layer
        # indices) which the arg parser then asserts must be a real
        # YAML list. The agent's recompute_num_layers replaces that
        # finer-grained list, so drop it when we're driving the recompute
        # strategy.
        overrides.pop("recompute_layer_ids", None)
        pre_trainer.pop("recompute_layer_ids", None)
    elif cfg.recompute_granularity == "none":
        overrides["recompute_granularity"] = None
        overrides["recompute_num_layers"] = 0
        overrides.pop("recompute_layer_ids", None)
        pre_trainer.pop("recompute_layer_ids", None)
    if cfg.cross_entropy_loss_fusion is not None:
        overrides["cross_entropy_loss_fusion"] = cfg.cross_entropy_loss_fusion
    if cfg.use_torch_fsdp2 is not None:
        overrides["use_torch_fsdp2"] = cfg.use_torch_fsdp2
    if cfg.use_distributed_optimizer is not None:
        overrides["use_distributed_optimizer"] = cfg.use_distributed_optimizer

    # 6) batch ------------------------------------------------------------
    overrides["micro_batch_size"] = cfg.mbs
    overrides["global_batch_size"] = cfg.gbs
    overrides["overlap_grad_reduce"] = cfg.overlap_grad_reduce

    pre_trainer["overrides"] = overrides
    raw.setdefault("modules", {})["pre_trainer"] = pre_trainer

    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"trial_{tag}.yaml"
    out_path.write_text(yaml.safe_dump(raw, sort_keys=False))
    return out_path


# ---------------------------------------------------------------------------
# Subprocess invocation
# ---------------------------------------------------------------------------

_FLOAT = r"([\-+]?\d+(?:[\.,]\d+)*(?:\.\d+)?)"

_RE_PARAM_OPT = re.compile(rf"Param\+Optimizer Memory:\s*{_FLOAT}\s*GB", re.IGNORECASE)
_RE_ACT = re.compile(rf"Activation Memory[^:]*:\s*{_FLOAT}\s*GB", re.IGNORECASE)
_RE_TOTAL_MEM = re.compile(rf"Projected Total Memory:\s*{_FLOAT}\s*GB", re.IGNORECASE)
# Bench-anchored memory projection (memory_projection.benchmark) prints:
#   "Point estimate (per rank): X GB"   ← OOM-accurate per-rank peak
#   "Upper bound    (per rank): Y GB"   ← point + safety_margin × residual_reserved
# Prefer these over the simulate-mode "Projected Total Memory" when both
# are present (e.g. in --memory-mode both output).
_RE_BENCH_POINT = re.compile(rf"Point estimate \(per rank\):\s*{_FLOAT}\s*GB", re.IGNORECASE)
_RE_BENCH_UPPER = re.compile(rf"Upper bound\s*\(per rank\):\s*{_FLOAT}\s*GB", re.IGNORECASE)
_RE_ITER_MS = re.compile(rf"Iteration Time:\s*{_FLOAT}\s*ms", re.IGNORECASE)
_RE_TPS = re.compile(rf"Tokens/s/GPU:\s*{_FLOAT}", re.IGNORECASE)
# The projection prints both "TFLOPs/s/GPU" and "TFLOP/s/GPU" depending
# on version and output source.
_RE_TFLOPS = re.compile(rf"TFLOPs?/s/GPU:\s*{_FLOAT}", re.IGNORECASE)
_RE_MFU = re.compile(rf"\bMFU(?:\s*\(.*?\))?:\s*{_FLOAT}", re.IGNORECASE)


def _to_float(s: str) -> float | None:
    if s is None:
        return None
    try:
        return float(s.replace(",", ""))
    except (TypeError, ValueError):
        return None


def _parse_metrics(stdout: str) -> dict:
    out: dict[str, Any] = {}
    if m := _RE_PARAM_OPT.search(stdout):
        out["param_optimizer_gb"] = _to_float(m.group(1))
    if m := _RE_ACT.search(stdout):
        out["activation_gb"] = _to_float(m.group(1))
    # Prefer the bench-anchored point estimate when present — it is
    # OOM-accurate (real per-rank peak measured + analytical extrapolation
    # to target).  Fall back to simulate-mode "Projected Total Memory" or
    # the param+act sum when the bench section isn't in this output.
    if m := _RE_BENCH_POINT.search(stdout):
        out["memory_per_gpu_gb"] = _to_float(m.group(1))
        out["memory_source"] = "benchmark_point"
        if mu := _RE_BENCH_UPPER.search(stdout):
            out["memory_per_gpu_gb_upper"] = _to_float(mu.group(1))
    elif m := _RE_TOTAL_MEM.search(stdout):
        out["memory_per_gpu_gb"] = _to_float(m.group(1))
        out["memory_source"] = "simulate"
    elif "param_optimizer_gb" in out and "activation_gb" in out:
        out["memory_per_gpu_gb"] = out["param_optimizer_gb"] + out["activation_gb"]
        out["memory_source"] = "simulate_summed"
    if m := _RE_ITER_MS.search(stdout):
        out["iteration_ms"] = _to_float(m.group(1))
    if m := _RE_TPS.search(stdout):
        out["tokens_per_s_per_gpu"] = _to_float(m.group(1))
    if m := _RE_TFLOPS.search(stdout):
        out["tflops_per_s_per_gpu"] = _to_float(m.group(1))
    if m := _RE_MFU.search(stdout):
        out["mfu"] = _to_float(m.group(1))
    return out


def _python_invoker(
    config_root: Path, profiling_mode: str | None = None, nproc_per_node: int | None = None
) -> list[str]:
    """Pick how to invoke the projector CLI (the ``cli/main.py`` shim).

    For ``simulate`` (and ``memory``) we use ``sys.executable`` directly so
    Origami / memory analytics run in a single process. For ``benchmark``
    we route through ``python -m torch.distributed.run --standalone
    --nproc-per-node=N`` because the projection's micro-train step expects
    the Megatron launcher env (NODE_RANK / RANK / WORLD_SIZE / MASTER_*).
    """
    import sys as _sys

    main_py = str(config_root / "_tuning_shim" / "main.py")
    if profiling_mode == "benchmark" and nproc_per_node and nproc_per_node > 0:
        return [
            _sys.executable,
            "-m",
            "torch.distributed.run",
            "--standalone",
            "--nnodes=1",
            f"--nproc-per-node={nproc_per_node}",
            main_py,
        ]
    return [_sys.executable, main_py]


def _build_perf_cmd(
    yaml_path: Path,
    cfg: TrialConfig,
    agent_cfg: AgentConfig,
    profiling_mode: str,
    config_root: Path,
    *,
    save_benchmark: Path | None = None,
) -> list[str]:
    bench_gpus = (
        agent_cfg.benchmark_host.benchmark_gpus
        if agent_cfg.benchmark_host.has_gpu and agent_cfg.benchmark_host.benchmark_gpus > 0
        else agent_cfg.target_cluster.gpus_per_node
    )
    cmd: list[str] = [
        *_python_invoker(config_root, profiling_mode=profiling_mode, nproc_per_node=bench_gpus),
        "projection",
        "performance",
        "--config",
        str(yaml_path),
        "--target-nodes",
        str(agent_cfg.target_cluster.num_nodes),
        "--profiling-mode",
        profiling_mode,
        "--gpu-arch",
        agent_cfg.target_cluster.gpu_arch,
    ]
    if profiling_mode == "benchmark":
        cmd += ["--benchmark-gpus", str(bench_gpus)]
        if save_benchmark is not None:
            # Persist the bench artifact so the memory projection can
            # consume it via --load-benchmark (one bench, two projections).
            cmd += ["--save-benchmark", str(save_benchmark)]
    if agent_cfg.target_cluster.hardware_config:
        cmd += ["--hardware-config", agent_cfg.target_cluster.hardware_config]
    if agent_cfg.target_cluster.gpu_clock_mhz:
        cmd += ["--gpu-clock-mhz", str(agent_cfg.target_cluster.gpu_clock_mhz)]
    if cfg.pp_schedule and cfg.pp_schedule != "auto":
        cmd += ["--pipeline-schedule-algorithm", cfg.pp_schedule]
    if cfg.vpp is not None:
        cmd += ["--num-virtual-stages-per-pipeline-rank", str(cfg.vpp)]
    cmd += ["--micro-batch-size", str(cfg.mbs)]
    cmd += ["--global-batch-size", str(cfg.gbs)]

    # Tier-A optimisations from the projection guidelines — these have
    # CLI flags on `projection performance` that take precedence over yaml
    # overrides (so we pass them explicitly even when the yaml carries the
    # corresponding key, to make the agent's signature self-describing).
    if cfg.use_turbo_deepep:
        cmd += ["--enable-deepep"]
    if cfg.sync_free_stage and cfg.sync_free_stage > 0:
        cmd += ["--sync-free-stage", str(cfg.sync_free_stage)]
    if cfg.enable_zero_bubble:
        cmd += ["--enable-zero-bubble"]
    if cfg.target_ep_size is not None:
        cmd += ["--target-ep-size", str(cfg.target_ep_size)]
    return cmd


def _build_memory_cmd(
    yaml_path: Path,
    cfg: TrialConfig,
    agent_cfg: AgentConfig,
    config_root: Path,
    *,
    memory_mode: str = "simulate",
    load_benchmark: Path | None = None,
    safety_margin: float | None = None,
) -> list[str]:
    """Build the ``projection memory`` argv.

    When ``memory_mode='benchmark'`` is paired with ``load_benchmark=<path>``,
    the call skips its own bench step and projects from the artifact saved
    by an earlier ``projection performance --save-benchmark`` (this is how
    the agent gets *bench-anchored* memory without paying for two benches).
    """
    cmd: list[str] = [
        *_python_invoker(config_root),
        "projection",
        "memory",
        "--config",
        str(yaml_path),
    ]
    if memory_mode:
        # Pass the memory mode explicitly so the agent does not rely on the
        # CLI's default (which is ``benchmark`` and would launch a GPU
        # sub-node layer benchmark for the simulate/memory-only path).
        cmd += ["--memory-mode", memory_mode]
    if load_benchmark is not None:
        cmd += ["--load-benchmark", str(load_benchmark)]
    if safety_margin is not None:
        cmd += ["--memory-safety-margin", f"{float(safety_margin):.4f}"]
    # Project to the real target cluster so the bench-anchored
    # extrapolator scales params/comm/DeepEP buffers correctly.
    cmd += ["--target-nodes", str(agent_cfg.target_cluster.num_nodes)]
    if cfg.pp_schedule and cfg.pp_schedule != "auto":
        cmd += ["--pipeline-schedule-algorithm", cfg.pp_schedule]
    if cfg.mbs is not None:
        cmd += ["--micro-batch-size", str(cfg.mbs)]
    if cfg.gbs is not None:
        cmd += ["--global-batch-size", str(cfg.gbs)]
    if cfg.vpp is not None:
        cmd += ["--num-virtual-stages-per-pipeline-rank", str(cfg.vpp)]
    return cmd


def write_inference_trial_yaml(arch: ArchitectureRecord, cfg, out_dir: Path, tag: str) -> Path:
    """Write a workload YAML overlay for an inference trial.

    Only the serving *parallelism* is overlaid into the YAML; the request
    profile (input/output len, batch, dtypes, features) is passed to
    ``projection inference`` via CLI flags by :func:`_build_inference_cmd`.
    """
    src = Path(arch.workload_path)
    raw = yaml.safe_load(src.read_text())
    pre_trainer = (raw.get("modules") or {}).get("pre_trainer") or {}
    overrides = dict(pre_trainer.get("overrides") or {})
    overrides["tensor_model_parallel_size"] = cfg.tp
    overrides["pipeline_model_parallel_size"] = cfg.pp
    overrides["expert_model_parallel_size"] = cfg.ep
    overrides["context_parallel_size"] = cfg.cp
    # Inference sweeps its own PP; a fixed *training* pipeline layout (stage
    # string / VPP) conflicts with the serving parallelism and is meaningless
    # for a forward-only projection, so drop both.
    overrides["virtual_pipeline_model_parallel_size"] = None
    overrides["pipeline_model_parallel_layout"] = None
    pre_trainer["overrides"] = overrides
    raw.setdefault("modules", {})["pre_trainer"] = pre_trainer
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"inf_trial_{tag}.yaml"
    out_path.write_text(yaml.safe_dump(raw, sort_keys=False))
    return out_path


def _build_inference_cmd(
    yaml_path: Path,
    cfg,
    agent_cfg: AgentConfig,
    config_root: Path,
    load_benchmark: Path | None = None,
    profiling_mode: str | None = None,
    bench_gpus: int | None = None,
    decode_floor: Path | None = None,
    pool_benchmarks: dict[str, Path] | None = None,
) -> list[str]:
    # The inference projector runs single-process and (in --profiling-mode
    # benchmark) drives its OWN serving engine, which shards itself, so the
    # parent must NOT be wrapped in torchrun. A cached --load-benchmark artifact
    # (one measurement per parallelism, reused across all serving-knob trials)
    # skips the measurement and just calibrates.
    cmd: list[str] = [
        *_python_invoker(config_root),
        "projection",
        "inference",
        "--config",
        str(yaml_path),
        "--inference-mode",
        "both",
        "--gpu-arch",
        agent_cfg.target_cluster.gpu_arch,
        "--input-len",
        str(cfg.input_len),
        "--output-len",
        str(cfg.output_len),
        "--inference-batch-size",
        str(cfg.batch_size),
        "--weight-dtype",
        cfg.weight_dtype,
        "--kv-cache-dtype",
        cfg.kv_cache_dtype,
        "--hbm-capacity-gb",
        str(agent_cfg.optimization.hbm_capacity_gb),
    ]
    # Resident sequences. Left unset the projector admits its own default rather
    # than the batch being tuned, which prices every trial against a queue it
    # was never configured for -- TPOT came back 4.5x high and the whole search
    # read as SLO-infeasible. The documented default is the batch size, so say
    # so explicitly instead of relying on the flag's absence to mean it.
    concurrency = cfg.max_concurrency if cfg.max_concurrency is not None else cfg.batch_size
    cmd += ["--max-concurrency", str(concurrency)]
    # Attention data parallelism subdivides the TP group. Emitted only when on,
    # so a trial that leaves it at 1 produces the same command it always did.
    if getattr(cfg, "attention_dp", 1) > 1:
        cmd += ["--attention-dp-size", str(cfg.attention_dp)]
    # Share of each prompt already resident from an earlier turn. Omitting it
    # prices an agentic trace as if every turn reprefilled its whole transcript.
    if getattr(cfg, "prefix_cache_hit_rate", 0.0):
        cmd += ["--prefix-cache-hit-rate", str(cfg.prefix_cache_hit_rate)]
    # Precision of the attention projections and dense MLP. Without it a 4-bit
    # checkpoint is sized at 4 bits but streamed at 8.
    if getattr(cfg, "linear_weight_dtype", None):
        cmd += ["--linear-weight-dtype", str(cfg.linear_weight_dtype)]
    if cfg.chunked_prefill_size:
        cmd += ["--chunked-prefill-size", str(cfg.chunked_prefill_size)]
    if cfg.speculative_num_tokens:
        cmd += ["--speculative-num-tokens", str(cfg.speculative_num_tokens)]
        cmd += ["--speculative-acceptance-rate", str(cfg.speculative_acceptance_rate)]
    # Feature B: custom collective ops.
    if getattr(cfg, "tp_allreduce_algo", "auto") not in (None, "auto"):
        cmd += ["--tp-allreduce-algo", str(cfg.tp_allreduce_algo)]
    if getattr(cfg, "ep_a2a_algo", "auto") not in (None, "auto"):
        cmd += ["--ep-a2a-algo", str(cfg.ep_a2a_algo)]
    if getattr(cfg, "use_turbo_deepep", False):
        cmd += ["--enable-deepep"]
    # Preset-style serving knobs (CUDA-graph capture, KV-cache memory fraction).
    if getattr(cfg, "cudagraph_mode", None):
        cmd += ["--cudagraph-mode", str(cfg.cudagraph_mode)]
    if getattr(cfg, "kv_cache_memory_fraction", None):
        cmd += ["--kv-cache-memory-fraction", str(cfg.kv_cache_memory_fraction)]
    # Serving dynamics: paged-KV fragmentation + scheduler token budget.
    if getattr(cfg, "kv_block_size", 0):
        cmd += ["--kv-block-size", str(cfg.kv_block_size)]
    if getattr(cfg, "max_num_batched_tokens", 0):
        cmd += ["--max-num-batched-tokens", str(cfg.max_num_batched_tokens)]
    # MoE expert-routing imbalance (only emitted for non-default / MoE values).
    if getattr(cfg, "ep_load_balance", 1.0) and cfg.ep_load_balance != 1.0:
        cmd += ["--ep-load-balance", str(cfg.ep_load_balance)]
    if getattr(cfg, "redundant_experts", 0):
        cmd += ["--redundant-experts", str(cfg.redundant_experts)]
    # Offered load (open-loop arrivals) — only when a non-closed rate is set.
    if getattr(cfg, "request_rate", 0.0) and getattr(cfg, "arrival_model", "closed") != "closed":
        cmd += ["--request-rate", str(cfg.request_rate)]
        cmd += ["--arrival-model", str(cfg.arrival_model)]
    # Per-request length heterogeneity. The search priced every trial at a single
    # ISL/OSL point, which is not what any measured trace looks like -- the
    # agentic ones span 103k-248k input -- and a point estimate cannot show long
    # requests holding KV while short ones cycle through. These reach the DES,
    # so they only bite alongside an offered rate or a replayed workload.
    if getattr(cfg, "des_workload_file", None):
        cmd += ["--des-workload-file", str(cfg.des_workload_file)]
    if getattr(cfg, "des_range_ratio", 1.0) != 1.0:
        cmd += ["--des-range-ratio", str(cfg.des_range_ratio)]
    if getattr(cfg, "des_num_requests", 0):
        cmd += ["--des-num-requests", str(cfg.des_num_requests)]
    # Kernel backend + native sparse attention + expert precision + fused ops.
    if getattr(cfg, "attention_backend", None):
        cmd += ["--attention-backend", str(cfg.attention_backend)]
    if getattr(cfg, "sparse_attention_topk", 0):
        cmd += ["--sparse-attention-topk", str(cfg.sparse_attention_topk)]
    if getattr(cfg, "moe_expert_dtype", None):
        cmd += ["--moe-expert-dtype", str(cfg.moe_expert_dtype)]
    if getattr(cfg, "fused_kernels", False):
        cmd += ["--fused-kernels"]
    if getattr(cfg, "speculative_draft_cost_factor", 0.0):
        # The tuner searches acceptance and draft cost as a pair held to
        # ``min_draft_cost``, so its factor has to be the cost charged.
        cmd += [
            "--speculative-draft-cost-factor",
            str(cfg.speculative_draft_cost_factor),
            "--speculative-draft-cost-model",
            "flat",
        ]
    # Custom collective ops (extra TP-AllReduce speedups).
    if getattr(cfg, "quick_reduce", False):
        cmd += ["--quick-reduce"]
    if getattr(cfg, "fuse_rmsnorm_allreduce", False):
        cmd += ["--fuse-rmsnorm-allreduce"]
    # Feature A: prefill/decode disaggregation.
    if getattr(cfg, "disaggregate", False):
        cmd += ["--disaggregate"]
        if getattr(cfg, "prefill_tp", None):
            cmd += ["--prefill-tp", str(cfg.prefill_tp)]
        if getattr(cfg, "decode_tp", None):
            cmd += ["--decode-tp", str(cfg.decode_tp)]
        if getattr(cfg, "prefill_ep", None):
            cmd += ["--prefill-ep", str(cfg.prefill_ep)]
        if getattr(cfg, "decode_ep", None):
            cmd += ["--decode-ep", str(cfg.decode_ep)]
        # Per-pool attention layout. A single global --attention-dp-size applies
        # the same degree to both pools, which cannot describe the asymmetric
        # layouts these models are served in.
        if getattr(cfg, "prefill_attention_dp", None):
            cmd += ["--prefill-attention-dp", str(cfg.prefill_attention_dp)]
        if getattr(cfg, "decode_attention_dp", None):
            cmd += ["--decode-attention-dp", str(cfg.decode_attention_dp)]
        if getattr(cfg, "prefill_replicas", 1) and cfg.prefill_replicas > 1:
            cmd += ["--prefill-replicas", str(cfg.prefill_replicas)]
        if getattr(cfg, "decode_replicas", 1) and cfg.decode_replicas > 1:
            cmd += ["--decode-replicas", str(cfg.decode_replicas)]
        if getattr(cfg, "transfer_backend", None):
            cmd += ["--transfer-backend", str(cfg.transfer_backend)]
        # Each pool calibrated against a measurement taken at its own shape,
        # when one exists. The pools run at different parallelism and attention
        # layout, so the shared anchor is a compromise that describes neither.
        for pool, path in (pool_benchmarks or {}).items():
            cmd += [f"--{pool}-benchmark", str(path)]
    if agent_cfg.target_cluster.gpu_clock_mhz:
        cmd += ["--gpu-clock-mhz", str(agent_cfg.target_cluster.gpu_clock_mhz)]
    if load_benchmark is not None:
        cmd += ["--load-benchmark", str(load_benchmark)]
    elif profiling_mode == "benchmark" and bench_gpus:
        cmd += ["--profiling-mode", "benchmark"]
    else:
        # Say "simulate" out loud. The projection CLI defaults to measuring, so
        # omitting the flag here would have the search spawn a serving engine
        # per candidate -- the opposite of a search that scores thousands of
        # them on the cost model. Measuring is requested explicitly, by the two
        # branches above.
        cmd += ["--profiling-mode", "simulate"]
    if decode_floor is not None:
        cmd += ["--decode-floor-benchmark", str(decode_floor)]
    return cmd


def _build_env(
    agent_cfg: AgentConfig, config_root: Path, profiling_mode: str | None = None
) -> dict:
    env = os.environ.copy()
    # For memory + simulate: pass the real target-cluster shape so
    # `projection memory`'s ``get_dp_size`` doesn't enter the "recompute min
    # nodes" branch where ``TP*CP*PP*EP // GPUS_PER_NODE`` underflows to zero
    # (=> ZeroDivisionError) when ``NNODES==1``.
    #
    # For benchmark: we are physically launching on this single host (via
    # torch.distributed.run --nnodes=1), so NNODES=1 / NODE_RANK=0; the CLI
    # carries ``--target-nodes`` for the projection target.
    if profiling_mode == "benchmark":
        env["NNODES"] = "1"
        env["NODE_RANK"] = "0"
    else:
        env["NNODES"] = str(agent_cfg.target_cluster.num_nodes)
    env["GPUS_PER_NODE"] = str(agent_cfg.target_cluster.gpus_per_node)
    env.setdefault("HSA_NO_SCRATCH_RECLAIM", "1")
    env["INFERASIM_GPU_ARCH"] = agent_cfg.target_cluster.gpu_arch

    # PYTHONPATH discipline: the subprocess runs the ``cli/main.py`` shim and
    # only needs ``config_root`` on the path.  When the agent is launched with
    # the tuning-agent subtree on PYTHONPATH (so it can import its own modules),
    # a stale nested copy of the package there could shadow the outer one and
    # make the subprocess import stale CLI modules (e.g. one that doesn't know
    # ``--save-benchmark``).  Fix: always put config_root first; drop any path
    # under the tuning-agent subtree.
    sep = os.pathsep
    py_path = env.get("PYTHONPATH", "")
    parts = [p for p in py_path.split(sep) if p]
    inner_marker = str(Path("agents") / "tuning_agent")
    parts = [p for p in parts if inner_marker not in p]
    parts = [p for p in parts if Path(p) != Path(config_root)]
    parts.insert(0, str(config_root))
    # The spawned projector runs the ``_tuning_shim/main.py`` shim, which imports
    # ``infera.projection.cli``. Ensure the Infera repo root (the dir that
    # contains the ``infera`` package) is importable. config_root is
    # <repo>/infera/projection, so parents[1] is <repo>.
    try:
        infera_root = Path(config_root).resolve().parents[1]
        if (infera_root / "infera" / "__init__.py").exists():
            parts.append(str(infera_root))
    except IndexError:
        pass
    env["PYTHONPATH"] = sep.join(parts)
    return env


def _run(cmd: list[str], cwd: Path, env: dict, timeout: int) -> tuple[int, str, float]:
    started = time.time()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd),
            env=env,
            timeout=timeout,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            text=True,
        )
        return proc.returncode, proc.stdout or "", time.time() - started
    except subprocess.TimeoutExpired as e:
        return (
            124,
            (
                e.stdout.decode("utf-8", "replace")
                if isinstance(e.stdout, bytes)
                else (e.stdout or "")
            ),
            time.time() - started,
        )


# ---------------------------------------------------------------------------
# Public evaluator class
# ---------------------------------------------------------------------------


class Evaluator:
    """Stateful evaluator. Tracks call counts so the agent stays within budget.

    ``mode`` selects how candidates are scored:

    * ``"dry"`` — never call the projector CLI; both memory and tps are
      synthesised. Useful for testing the agent loop on hosts without a
      projector install.
    * ``"memory-real"`` — call ``projection memory`` for real (no GPU
      required), then synthesise a tokens/s/GPU heuristic from the measured
      memory + parallelism axes. Useful when ``projection performance``
      cannot run because Origami / FAv3 simulator deps are missing.
    * ``"full"`` — call ``projection memory`` and ``projection performance``
      (``--profiling-mode {simulate,benchmark}``). Default. Requires Origami
      for simulate and a GPU for benchmark.
    """

    def __init__(
        self,
        agent_cfg: AgentConfig,
        arch: ArchitectureRecord,
        config_root: Path,
        dry_run: bool = False,
        mode: str = "full",
    ):
        self.cfg = agent_cfg
        self.arch = arch
        self.config_root = config_root
        # ``dry_run`` is kept for back-compat with earlier callers.
        if dry_run:
            mode = "dry"
        if mode not in ("dry", "memory-real", "full"):
            raise ValueError(f"unknown evaluator mode: {mode!r}")
        self.mode = mode
        self.dry_run = mode == "dry"
        self.trials_dir = agent_cfg.out_dir / "trials"
        self.trials_dir.mkdir(parents=True, exist_ok=True)
        self.n_memory_calls = 0
        self.n_simulate_calls = 0
        self.n_benchmark_calls = 0

    # ── public API ────────────────────────────────────────────────────────

    def evaluate_memory_only(self, cfg: TrialConfig, tag: str) -> EvalResult:
        return self._evaluate(cfg, tag, mode="memory_only")

    def evaluate_simulate(self, cfg: TrialConfig, tag: str) -> EvalResult:
        return self._evaluate(cfg, tag, mode="simulate")

    def evaluate_benchmark(self, cfg: TrialConfig, tag: str) -> EvalResult:
        if not self.cfg.benchmark_host.has_gpu:
            return EvalResult(
                legal=False,
                reason="benchmark requested but has_gpu=false",
                source="benchmark",
                config=cfg.as_dict(),
            )
        return self._evaluate(cfg, tag, mode="benchmark")

    def _resolve_inference_bench_artifact(self, cfg) -> Path | None:
        """Locate a cached vLLM benchmark artifact matching this trial's
        parallelism, for benchmark-calibrated serving projection.

        A single artifact per (TP, PP, EP) serves every serving-knob trial at
        that parallelism. Looks in ``$INFERASIM_INFER_BENCH_CACHE`` for a file
        named ``<model>_tp{tp}_pp{pp}_ep{ep}.json`` (EP forced to 1 for dense
        models); otherwise honours a single forced ``$INFERASIM_INFER_BENCH_ARTIFACT``.
        Returns ``None`` when no artifact is available."""
        forced = os.environ.get("INFERASIM_INFER_BENCH_ARTIFACT")
        if forced and Path(forced).exists():
            return Path(forced)
        cache = os.environ.get("INFERASIM_INFER_BENCH_CACHE")
        if not cache:
            return None
        ep = cfg.ep if getattr(self.arch, "is_moe", False) else 1
        cand = Path(cache) / f"{self.arch.model_name}_tp{cfg.tp}_pp{cfg.pp}_ep{ep}.json"
        if cand.exists():
            return cand
        # No exact-parallelism artifact: fall back to a base anchor and let the
        # projector restore.
        return self._select_regime_base_anchor(cfg, Path(cache), ep)

    def _select_regime_base_anchor(self, cfg, cache: Path, ep: int) -> Path | None:
        """The cached anchor closest to the target from below.

        Anchors are measured at ``min(tp, 4)`` and everything above is projected,
        so there is no ladder to climb -- the nearest rung is the anchor. Family
        rule: the single-GPU base is always eligible; above it an EP-sharded
        target draws only EP-sharded rungs and a pure-TP target only pure-TP
        ones, so the restore compares like with like.
        """
        import json as _json

        want_ep_sharded = bool(getattr(self.arch, "is_moe", False)) and cfg.ep > 1
        target_gpus = cfg.tp * cfg.pp
        best: tuple[int, Path] | None = None
        for path in sorted(cache.glob(f"{self.arch.model_name}_tp*_pp*_ep*.json")):
            try:
                meta = (_json.load(open(path)) or {}).get("meta", {}) or {}
            except Exception:
                continue
            gpus = int(meta.get("tp", 1) or 1) * int(meta.get("pp", 1) or 1)
            if gpus > target_gpus:
                continue
            if gpus > 1 and (int(meta.get("ep", 1) or 1) > 1) != want_ep_sharded:
                continue
            if best is None or gpus > best[0]:
                best = (gpus, path)
        return best[1] if best else None

    def _resolve_pool_bench_artifacts(self, cfg) -> dict[str, Path] | None:
        """Cached anchors measured at each disaggregated pool's own shape.

        A pool is only calibrated separately when the cache actually holds a
        measurement for its shape *and* that shape differs from the trial's --
        otherwise the shared ``--load-benchmark`` already describes it and a
        redundant per-pool flag would only obscure which artifact was used.
        """
        cache = os.environ.get("INFERASIM_INFER_BENCH_CACHE")
        if not cache or os.environ.get("INFERASIM_INFER_BENCH_ARTIFACT"):
            return None
        is_moe = bool(getattr(self.arch, "is_moe", False))
        out: dict[str, Path] = {}
        for pool in ("prefill", "decode"):
            pool_tp = getattr(cfg, f"{pool}_tp", None)
            if not pool_tp or pool_tp == cfg.tp:
                continue
            pool_ep = getattr(cfg, f"{pool}_ep", None) or (cfg.ep if is_moe else 1)
            cand = Path(cache) / f"{self.arch.model_name}_tp{pool_tp}_pp{cfg.pp}_ep{pool_ep}.json"
            if cand.exists():
                out[pool] = cand
        return out or None

    def _resolve_decode_floor(self, cfg) -> Path | None:
        """Decode latency floor probe for an EP-sharded MoE target.

        Above the roofline knee the decode step is set by fixed per-step
        launch/dispatch overhead (incl. resident comm) and is ~parallelism-
        invariant, so the 2-GPU EP-sharded probe's measured decode curve is the
        floor for any more-sharded EP=TP target. Applied as
        ``decode = max(restored, floor)`` (see performance.py). Only for
        EP-sharded MoE targets (``EP > 1``): pure-TP (``EP == 1``) MoE decode
        stays weight-bound and grows with batch — a different regime the
        EP-sharded floor does not describe — so it gets no floor. Returns the
        cached ``<model>_tp2_pp1_ep2.json`` probe, else ``None``."""
        if not getattr(self.arch, "is_moe", False) or int(getattr(cfg, "ep", 1)) <= 1:
            return None
        cache = os.environ.get("INFERASIM_INFER_BENCH_CACHE")
        if not cache:
            return None
        probe = Path(cache) / f"{self.arch.model_name}_tp2_pp1_ep2.json"
        return probe if probe.exists() else None

    def evaluate_inference(self, cfg, tag: str) -> EvalResult:
        """Score a serving config via ``projection inference`` (memory + perf).

        ``cfg`` is an :class:`inference_tuning.InferenceTrialConfig`.  Returns
        an :class:`EvalResult` populated with TTFT / ITL / throughput / KV /
        memory.  Enforces the HBM memory cap (illegal if it does not fit).
        """
        from .inference_tuning import (
            derive_inference_legality,
            parse_inference_metrics,
            validate_inference,
        )

        legality = derive_inference_legality(self.arch, self.cfg.target_cluster)
        ok, reason = validate_inference(cfg, self.arch, self.cfg.target_cluster, legality)
        result = EvalResult(legal=ok, reason=reason, source="inference", config=cfg.as_dict())
        if not ok:
            return result

        if self.mode == "dry":
            # Count the call so the perf-budget gate is enforced even in dry
            # loop-testing mode (otherwise the RLM could evaluate unbounded).
            self.n_simulate_calls += 1
            # Synthesise plausible serving metrics for loop testing.
            result.ttft_ms = 50.0 + cfg.input_len * 0.01
            result.itl_ms = 10.0 + cfg.tp * 2.0
            result.decode_throughput_tps = cfg.batch_size * 1000.0 / result.itl_ms
            result.decode_throughput_tps_per_gpu = result.decode_throughput_tps / max(
                1, cfg.tp * cfg.pp
            )
            result.memory_per_gpu_gb = 80.0
            return result

        yaml_path = write_inference_trial_yaml(self.arch, cfg, self.trials_dir, tag)

        # Benchmark mode: calibrate the serving projection against a real GPU
        # measurement instead of the analytical (origami) cost model. One
        # benchmark per parallelism (TP/PP/EP) is enough — every serving-knob
        # trial (batch, concurrency, kv-dtype, chunked-prefill, spec-decode) at
        # that parallelism reuses it via ``--load-benchmark``, since those knobs
        # are resolved by the DES on top of the measured step. Resolution order:
        #   1. cached artifact for this parallelism ($INFERASIM_INFER_BENCH_CACHE),
        #   2. a single forced artifact ($INFERASIM_INFER_BENCH_ARTIFACT), or
        #   3. spawn a live benchmark (--profiling-mode benchmark) on the host.
        load_bench = None
        profiling_mode = None
        bench_gpus = None
        is_bench = self.mode == "benchmark" or self.cfg.benchmark_host.has_gpu
        if is_bench:
            load_bench = self._resolve_inference_bench_artifact(cfg)
            if load_bench is None:
                if os.environ.get("INFERASIM_INFER_BENCH_CACHE_ONLY"):
                    result.legal = False
                    result.reason = (
                        f"benchmark mode: no cached benchmark artifact for "
                        f"TP={cfg.tp} PP={cfg.pp} EP={cfg.ep} "
                        f"(set INFERASIM_INFER_BENCH_CACHE or pre-benchmark this parallelism)"
                    )
                    return result
                profiling_mode = "benchmark"
                bench_gpus = self.cfg.benchmark_host.benchmark_gpus or None

        # Decode latency floor for EP-sharded MoE targets restored from a
        # smaller anchor: cap the restored decode step at the 2-GPU EP-sharded
        # probe's measured curve (no-op below the floor / for pure-TP).
        decode_floor = self._resolve_decode_floor(cfg) if is_bench else None

        # Per-pool anchors for a disaggregated trial. The pools run at different
        # parallelism, so an anchor measured at one pool's shape describes the
        # other only by coincidence; where the cache holds a measurement for a
        # pool's own shape, that pool is calibrated against it instead of the
        # shared one.
        pool_benchmarks = (
            self._resolve_pool_bench_artifacts(cfg)
            if is_bench and getattr(cfg, "disaggregate", False)
            else None
        )

        cmd = _build_inference_cmd(
            yaml_path,
            cfg,
            self.cfg,
            self.config_root,
            load_benchmark=load_bench,
            profiling_mode=profiling_mode,
            bench_gpus=bench_gpus,
            decode_floor=decode_floor,
            pool_benchmarks=pool_benchmarks,
        )
        rc, out, dur = _run(
            cmd,
            cwd=self.config_root,
            env=_build_env(
                self.cfg, self.config_root, profiling_mode=("benchmark" if profiling_mode else None)
            ),
            timeout=(3600 if profiling_mode == "benchmark" else 600),
        )
        if load_bench is not None or profiling_mode == "benchmark":
            self.n_benchmark_calls += 1
        else:
            self.n_simulate_calls += 1
        result.cmd = cmd
        result.returncode = rc
        result.duration_s = dur
        result.stdout_tail = _tail(out, 8000)
        for k, v in parse_inference_metrics(out).items():
            setattr(result, k, v)

        if rc != 0 or result.ttft_ms is None:
            result.legal = False
            result.reason = (
                f"projection inference failed (rc={rc}, ttft={result.ttft_ms}); see stdout_tail"
            )
            return result

        # Memory cap: serving weights + KV cache must fit the safety-margined HBM.
        cap = self.cfg.optimization.hbm_capacity_gb * (
            1 - self.cfg.optimization.memory_safety_margin
        )
        if result.memory_per_gpu_gb is not None and result.memory_per_gpu_gb > cap:
            result.legal = False
            result.reason = (
                f"inference memory {result.memory_per_gpu_gb:.1f} GB > cap {cap:.1f} GB "
                f"(HBM={self.cfg.optimization.hbm_capacity_gb} GB, "
                f"margin={self.cfg.optimization.memory_safety_margin})"
            )
            return result

        misses = _slo_violations(result, self.cfg.optimization.slo)
        if misses:
            result.legal = False
            result.reason = "misses latency SLO: " + ", ".join(misses)
        return result

    # ── internal ──────────────────────────────────────────────────────────

    def _evaluate(self, cfg: TrialConfig, tag: str, mode: str) -> EvalResult:
        from .legality import derive_legality

        legality = derive_legality(self.arch, self.cfg.target_cluster)
        ok, reason = validate(cfg, self.arch, self.cfg.target_cluster, legality)
        result = EvalResult(
            legal=ok,
            reason=reason,
            source=mode,
            config=cfg.as_dict(),
            derived_dp=derived_dp(cfg, self.arch, self.cfg.target_cluster),
        )
        if not ok:
            return result

        if self.mode == "dry":
            # synthesise a metric so the loop is testable without the projector CLI
            result.memory_per_gpu_gb = 100.0
            result.tokens_per_s_per_gpu = 1000.0 + (cfg.tp + cfg.pp + cfg.ep)
            result.iteration_ms = 1000.0
            return result

        yaml_path = write_trial_yaml(self.arch, cfg, self.trials_dir, tag)

        # In benchmark mode, defer memory until after perf so the bench
        # artifact is shared (one GPU bench feeds both projections).  The
        # simulate-mode memory call is skipped because its formula
        # disagrees with the bench-anchored one anyway, and we want OOM
        # decisions to use the measured peak.
        if mode == "benchmark":
            return self._evaluate_benchmark(cfg, tag, yaml_path, result)

        # 1. memory (cheap, always run for legality + headroom check)
        mem_cmd = _build_memory_cmd(yaml_path, cfg, self.cfg, self.config_root)
        rc, out, dur = _run(
            mem_cmd, cwd=self.config_root, env=_build_env(self.cfg, self.config_root), timeout=300
        )
        self.n_memory_calls += 1
        result.cmd = mem_cmd
        result.returncode = rc
        result.duration_s = dur
        result.stdout_tail = _tail(out, 4000)
        result_metrics = _parse_metrics(out)
        for k, v in result_metrics.items():
            setattr(result, k, v)

        # `projection memory` is non-deterministic in its failure mode: it can
        # crash mid-print and still leave some inner metrics parsed but no
        # final summary. Require BOTH a clean exit AND a parsed total to
        # accept the trial.
        if rc != 0 or result.memory_per_gpu_gb is None:
            result.legal = False
            result.reason = (
                f"projection memory failed (rc={rc}, "
                f"total_parsed={result.memory_per_gpu_gb}); see stdout_tail"
            )
            return result

        # memory cap enforcement
        #
        # Caveat for `recompute_granularity in {"selective", "none", None}`:
        # the analytic memory model only models ``full`` recompute
        # (see core/projection/module_profilers/language_model.py:504). For
        # ``selective`` and ``none`` it stores **all** per-layer activations,
        # which over-counts vs. real Megatron runs (selective saves ~50%
        # because attention activations are recomputed). To avoid falsely
        # pre-rejecting these in *benchmark* mode (where the actual GPU run
        # is the ground truth and will OOM if it can't fit), we apply a
        # heuristic correction:
        #   - "selective": multiply projection by 0.55  (saves attention)
        #   - "none"/None: leave as-is, trust the projection
        # When in benchmark mode, even a still-over-cap result is treated
        # as ADVISORY: log it but proceed to benchmark, because real OOM is
        # the only authoritative answer. In simulate / memory-only modes
        # the projection remains authoritative.
        cap = self.cfg.optimization.hbm_capacity_gb * (
            1 - self.cfg.optimization.memory_safety_margin
        )
        adjusted_mem = result.memory_per_gpu_gb
        if cfg.recompute_granularity == "selective" and adjusted_mem is not None:
            adjusted_mem = adjusted_mem * 0.55
        result.memory_per_gpu_gb_adjusted = adjusted_mem

        # Strict memory enforcement: any trial whose projected per-GPU
        # memory exceeds the safety-margined HBM cap is rejected up-front,
        # *regardless* of profiling mode. This enforces the user's rule:
        # "if solution memory is more than projected HBM capacity, that
        # solution should not be considered". Sub-node benchmark profiling
        # may have succeeded in earlier runs because the local 8-GPU
        # measurement avoided the projected bottleneck — but that's a
        # measurement artefact, not a green light to deploy the config to
        # the target N-node cluster.
        if adjusted_mem is not None and adjusted_mem > cap:
            result.legal = False
            result.reason = (
                f"memory {adjusted_mem:.1f} GB > cap {cap:.1f} GB "
                f"(HBM={self.cfg.optimization.hbm_capacity_gb} GB, margin="
                f"{self.cfg.optimization.memory_safety_margin})"
            )
            return result

        if mode == "memory_only":
            return result

        # If we are not allowed to call `projection performance` (e.g. Origami
        # not installed and no GPU on this host), synthesise a tps from the
        # measured memory + parallelism axes so the LLM still has a signal.
        if self.mode == "memory-real":
            result.tokens_per_s_per_gpu = _synth_tps_from_memory(cfg, result, self.arch)
            result.iteration_ms = 1000.0
            return result

        # 2. performance (simulate path only — benchmark goes through
        # ``_evaluate_benchmark`` via the early-return above).
        profiling_mode = "simulate"
        perf_cmd = _build_perf_cmd(yaml_path, cfg, self.cfg, profiling_mode, self.config_root)
        rc2, out2, dur2 = _run(
            perf_cmd,
            cwd=self.config_root,
            env=_build_env(self.cfg, self.config_root, profiling_mode=profiling_mode),
            timeout=600,
        )
        self.n_simulate_calls += 1
        result.cmd = perf_cmd
        result.returncode = rc2
        result.duration_s += dur2
        result.stdout_tail = (result.stdout_tail + "\n--- perf ---\n" + _tail(out2, 6000))[-12000:]
        for k, v in _parse_metrics(out2).items():
            setattr(result, k, v)
        if rc2 != 0 and result.tokens_per_s_per_gpu is None:
            result.legal = False
            result.reason = f"projection performance failed (rc={rc2}); see stdout_tail"
        return result

    def _evaluate_benchmark(
        self, cfg: TrialConfig, tag: str, yaml_path: Path, result: EvalResult
    ) -> EvalResult:
        """Benchmark-mode flow with shared perf↔memory artifact.

        Runs:

          1. ``projection performance --profiling-mode benchmark
             --save-benchmark <tmp>`` → writes the bench artifact and
             prints tokens/s/GPU + iter time.
          2. ``projection memory --memory-mode benchmark --load-benchmark
             <tmp> --target-nodes N --memory-safety-margin M`` → projects
             OOM-accurate per-rank peak (point + 5 % upper bound) without
             re-running the bench.

        Both projections see the same measured memory and timing.
        """
        import tempfile

        cap = self.cfg.optimization.hbm_capacity_gb * (
            1 - self.cfg.optimization.memory_safety_margin
        )

        fd, tmp_path = tempfile.mkstemp(prefix="tuning_agent_bench_", suffix=".json")
        os.close(fd)
        artifact = Path(tmp_path)
        try:
            # ---- 1. perf bench (writes artifact) -------------------------
            perf_cmd = _build_perf_cmd(
                yaml_path,
                cfg,
                self.cfg,
                "benchmark",
                self.config_root,
                save_benchmark=artifact,
            )
            rc1, out1, dur1 = _run(
                perf_cmd,
                cwd=self.config_root,
                env=_build_env(self.cfg, self.config_root, profiling_mode="benchmark"),
                timeout=3600,
            )
            self.n_benchmark_calls += 1
            result.cmd = perf_cmd
            result.returncode = rc1
            result.duration_s = dur1
            result.stdout_tail = _tail(out1, 6000)
            for k, v in _parse_metrics(out1).items():
                setattr(result, k, v)

            if rc1 != 0:
                result.legal = False
                result.reason = (
                    f"projection performance --benchmark failed (rc={rc1}); see stdout_tail"
                )
                return result

            if not artifact.exists() or artifact.stat().st_size == 0:
                result.legal = False
                result.reason = (
                    "perf bench did not produce a --save-benchmark artifact; "
                    "memory cannot be projected from it"
                )
                return result

            # ---- 2. memory in benchmark/load mode -----------------------
            mem_cmd = _build_memory_cmd(
                yaml_path,
                cfg,
                self.cfg,
                self.config_root,
                memory_mode="benchmark",
                load_benchmark=artifact,
                safety_margin=self.cfg.optimization.memory_safety_margin,
            )
            rc2, out2, dur2 = _run(
                mem_cmd,
                cwd=self.config_root,
                # Memory-from-artifact path doesn't need megatron; pass
                # default env (NNODES=target so projection sees the right
                # cluster shape for analytical extrapolation).
                env=_build_env(self.cfg, self.config_root),
                timeout=300,
            )
            self.n_memory_calls += 1
            result.duration_s += dur2
            result.stdout_tail = (
                result.stdout_tail + "\n--- mem (bench/load) ---\n" + _tail(out2, 6000)
            )[-14000:]
            mem_metrics = _parse_metrics(out2)
            for k, v in mem_metrics.items():
                setattr(result, k, v)

            if rc2 != 0 or result.memory_per_gpu_gb is None:
                result.legal = False
                result.reason = (
                    f"projection memory --benchmark/load failed "
                    f"(rc={rc2}, total_parsed={result.memory_per_gpu_gb}); "
                    f"see stdout_tail"
                )
                return result

            # OOM-fits decision uses the bench-anchored *upper bound*
            # (point + 5 % safety margin × residual_reserved) when present;
            # otherwise the point estimate.  This is the OOM-accurate
            # signal the memory benchmark mode was designed for.
            decision_mem = (
                result.memory_per_gpu_gb_upper
                if result.memory_per_gpu_gb_upper is not None
                else result.memory_per_gpu_gb
            )
            result.memory_per_gpu_gb_adjusted = decision_mem
            if decision_mem is not None and decision_mem > cap:
                result.legal = False
                result.reason = (
                    f"benchmark memory {decision_mem:.1f} GB > cap {cap:.1f} GB "
                    f"(HBM={self.cfg.optimization.hbm_capacity_gb} GB, "
                    f"margin={self.cfg.optimization.memory_safety_margin}, "
                    f"source={result.memory_source or 'benchmark'})"
                )
                return result

            return result
        finally:
            try:
                artifact.unlink(missing_ok=True)
            except OSError:
                pass


def _tail(s: str, n: int) -> str:
    if not s:
        return ""
    return s if len(s) <= n else s[-n:]


# Projected metric backing each SLO key, with the label to report it under.
_SLO_METRICS = {
    "ttft_ms": ("ttft_ms", "TTFT"),
    "tpot_ms": ("itl_ms", "TPOT"),
    "itl_ms": ("itl_ms", "TPOT"),
    "request_latency_ms": ("request_latency_ms", "end-to-end latency"),
}


def _slo_violations(result: EvalResult, slo: dict) -> list[str]:
    """Latency budgets this trial misses, phrased for the search log.

    The reason string is what the LLM planner reads back, so it names the
    budget and the overshoot rather than just failing the trial -- that is the
    signal telling it to trade concurrency away, not to try another dtype.
    """
    misses = []
    for key, budget in (slo or {}).items():
        spec = _SLO_METRICS.get(key)
        if spec is None or budget in (None, ""):
            continue
        attr, label = spec
        value = getattr(result, attr, None)
        if value is not None and float(value) > float(budget):
            misses.append(f"{label} {float(value):.1f} ms > {float(budget):.1f} ms")
    return misses


def _synth_tps_from_memory(cfg: TrialConfig, result: EvalResult, arch: ArchitectureRecord) -> float:
    """A *very* coarse heuristic so the agent has a relative signal in
    ``memory-real`` mode (no Origami, no GPU). Higher is better.

    Intentionally simple — the LLM is told this is a heuristic, not a real
    perf number, and is used only to rank candidates relative to each other.
    """
    base = 1000.0
    # Reward larger MBS (better GEMM utilisation) up to a saturating point.
    base += min(cfg.mbs, 8) * 25.0
    # Penalise TP and PP communication; EP is cheap *if* it stays intra-node.
    base -= (cfg.tp - 1) * 30.0
    base -= (cfg.pp - 1) * 20.0
    base -= max(cfg.ep - 8, 0) * 40.0  # EP > one node hurts (A2A across nodes)
    # Penalise CP > 1 lightly (extra ring comms).
    base -= (cfg.cp - 1) * 10.0
    # Penalise full recompute (extra forward) lightly.
    if cfg.recompute_granularity == "full":
        base -= 40.0
    elif cfg.recompute_granularity == "selective":
        base -= 10.0
    # Reward staying well within HBM headroom (less paging, more activations).
    if result.memory_per_gpu_gb is not None:
        base += max(0.0, 50.0 - result.memory_per_gpu_gb * 0.05)
    return round(max(100.0, base), 1)
